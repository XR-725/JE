package com.homestay.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class HomestayDto {
    @NotBlank(message = "民宿名称不能为空")
    private String name;

    private String province;
    private String city;
    private String district;
    private String address;
    private String description;
    private String coverImage;
    private String images;
    private String facilities;
    private String checkInTime;
    private String checkOutTime;
}
