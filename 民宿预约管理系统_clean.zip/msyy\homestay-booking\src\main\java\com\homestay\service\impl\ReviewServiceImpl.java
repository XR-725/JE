package com.homestay.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.common.BusinessException;
import com.homestay.dto.ReviewDto;
import com.homestay.entity.Homestay;
import com.homestay.entity.Orders;
import com.homestay.entity.Review;
import com.homestay.entity.Room;
import com.homestay.entity.User;
import com.homestay.mapper.HomestayMapper;
import com.homestay.mapper.OrdersMapper;
import com.homestay.mapper.ReviewMapper;
import com.homestay.mapper.RoomMapper;
import com.homestay.mapper.UserMapper;
import com.homestay.service.ReviewService;
import com.homestay.vo.ReviewStatsVO;
import com.homestay.vo.ReviewVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewMapper reviewMapper;
    private final OrdersMapper ordersMapper;
    private final HomestayMapper homestayMapper;
    private final RoomMapper roomMapper;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public void addReview(ReviewDto dto, Long userId) {
        // orderId 可选，如果有则校验归属
        if (dto.getOrderId() != null) {
            Orders order = ordersMapper.selectById(dto.getOrderId());
            if (order == null || !order.getUserId().equals(userId)) {
                throw new BusinessException("订单不存在");
            }

            Long count = reviewMapper.selectCount(
                    new LambdaQueryWrapper<Review>().eq(Review::getOrderId, dto.getOrderId()));
            if (count > 0) {
                throw new BusinessException("该订单已评价");
            }
        }

        Review review = new Review();
        review.setUserId(userId);
        review.setOrderId(dto.getOrderId());
        review.setHomestayId(dto.getHomestayId());
        review.setRoomId(dto.getRoomId());
        review.setRating(dto.getRating());
        review.setCleanliness(dto.getCleanliness());
        review.setLocation(dto.getLocation());
        review.setService(dto.getService());
        review.setFacilitiesScore(dto.getFacilitiesScore());
        review.setContent(dto.getContent());
        review.setImages(dto.getImages());
        review.setStatus(1);
        reviewMapper.insert(review);

        updateHomestayRating(dto.getHomestayId());
    }

    @Override
    public Page<ReviewVO> getReviewsByHomestayId(Long homestayId, Integer page, Integer size) {
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Review::getHomestayId, homestayId)
                .orderByDesc(Review::getCreateTime);
        Page<Review> reviewPage = reviewMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(reviewPage, page, size);
    }

    @Override
    public Page<ReviewVO> getMyReviews(Long userId, Integer page, Integer size) {
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Review::getUserId, userId).orderByDesc(Review::getCreateTime);
        Page<Review> reviewPage = reviewMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(reviewPage, page, size);
    }

    @Override
    public Page<ReviewVO> getAllReviews(Integer page, Integer size, String keyword) {
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        if (StrUtil.isNotBlank(keyword)) {
            wrapper.like(Review::getContent, keyword);
        }
        wrapper.orderByDesc(Review::getCreateTime);
        Page<Review> reviewPage = reviewMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(reviewPage, page, size);
    }

    @Override
    public void replyReview(Long reviewId, Long hostId, String reply) {
        Review review = reviewMapper.selectById(reviewId);
        if (review == null) throw new BusinessException("评价不存在");

        Homestay homestay = homestayMapper.selectById(review.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId)) {
            throw new BusinessException("无权回复该评价");
        }

        review.setReply(reply);
        review.setReplyTime(LocalDateTime.now());
        reviewMapper.updateById(review);
    }

    @Override
    public void deleteReview(Long reviewId, Long userId) {
        Review review = reviewMapper.selectById(reviewId);
        if (review == null) throw new BusinessException("评价不存在");
        if (!review.getUserId().equals(userId)) {
            throw new BusinessException("无权删除该评价");
        }
        reviewMapper.deleteById(reviewId);
        updateHomestayRating(review.getHomestayId());
    }

    @Override
    public void adminDeleteReview(Long reviewId) {
        Review review = reviewMapper.selectById(reviewId);
        if (review == null) throw new BusinessException("评价不存在");
        reviewMapper.deleteById(reviewId);
        updateHomestayRating(review.getHomestayId());
    }

    @Override
    public ReviewStatsVO getReviewStats(Long homestayId) {
        List<Review> reviews = reviewMapper.selectList(
                new LambdaQueryWrapper<Review>().eq(Review::getHomestayId, homestayId));

        return buildStatsVO(reviews);
    }

    @Override
    public Page<ReviewVO> getReviewsByRoomId(Long roomId, Integer page, Integer size) {
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Review::getRoomId, roomId)
                .orderByDesc(Review::getCreateTime);
        Page<Review> reviewPage = reviewMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(reviewPage, page, size);
    }

    @Override
    public ReviewStatsVO getRoomReviewStats(Long roomId) {
        List<Review> reviews = reviewMapper.selectList(
                new LambdaQueryWrapper<Review>().eq(Review::getRoomId, roomId));
        return buildStatsVO(reviews);
    }

    private ReviewStatsVO buildStatsVO(List<Review> reviews) {
        ReviewStatsVO vo = new ReviewStatsVO();
        vo.setTotalReviews(reviews.size());

        if (reviews.isEmpty()) {
            vo.setAverageRating(0.0);
            vo.setAverageCleanliness(0.0);
            vo.setAverageLocation(0.0);
            vo.setAverageService(0.0);
            vo.setAverageFacilities(0.0);
            vo.setStarDistribution(new HashMap<>());
            return vo;
        }

        vo.setAverageRating(reviews.stream().mapToInt(Review::getRating).average().orElse(0));
        vo.setAverageCleanliness(reviews.stream().filter(r -> r.getCleanliness() != null).mapToInt(Review::getCleanliness).average().orElse(0));
        vo.setAverageLocation(reviews.stream().filter(r -> r.getLocation() != null).mapToInt(Review::getLocation).average().orElse(0));
        vo.setAverageService(reviews.stream().filter(r -> r.getService() != null).mapToInt(Review::getService).average().orElse(0));
        vo.setAverageFacilities(reviews.stream().filter(r -> r.getFacilitiesScore() != null).mapToInt(Review::getFacilitiesScore).average().orElse(0));

        Map<Integer, Long> starDist = new HashMap<>();
        for (int i = 1; i <= 5; i++) {
            final int star = i;
            starDist.put(i, reviews.stream().filter(r -> r.getRating() == star).count());
        }
        vo.setStarDistribution(starDist);

        return vo;
    }

    private void updateHomestayRating(Long homestayId) {
        List<Review> reviews = reviewMapper.selectList(
                new LambdaQueryWrapper<Review>().eq(Review::getHomestayId, homestayId));
        Homestay homestay = homestayMapper.selectById(homestayId);
        if (homestay != null) {
            if (reviews.isEmpty()) {
                homestay.setRating(BigDecimal.valueOf(5.0));
                homestay.setReviewCount(0);
            } else {
                double avg = reviews.stream().mapToInt(Review::getRating).average().orElse(5.0);
                homestay.setRating(BigDecimal.valueOf(avg).setScale(1, RoundingMode.HALF_UP));
                homestay.setReviewCount(reviews.size());
            }
            homestayMapper.updateById(homestay);
        }
    }

    private ReviewVO convertToVO(Review review) {
        ReviewVO vo = new ReviewVO();
        BeanUtil.copyProperties(review, vo);
        if (StrUtil.isNotBlank(review.getImages())) {
            try {
                vo.setImages(JSONUtil.toList(review.getImages(), String.class));
            } catch (Exception e) {
                vo.setImages(new ArrayList<>());
            }
        } else {
            vo.setImages(new ArrayList<>());
        }

        User user = userMapper.selectById(review.getUserId());
        if (user != null) {
            vo.setUserName(user.getNickname());
            vo.setUserAvatar(user.getAvatar());
        }

        Homestay homestay = homestayMapper.selectById(review.getHomestayId());
        if (homestay != null) {
            vo.setHomestayName(homestay.getName());
        }

        if (review.getRoomId() != null) {
            Room room = roomMapper.selectById(review.getRoomId());
            if (room != null) {
                vo.setRoomName(room.getName());
            }
        }

        return vo;
    }

    private Page<ReviewVO> convertPage(Page<Review> reviewPage, int page, int size) {
        Page<ReviewVO> voPage = new Page<>(page, size, reviewPage.getTotal());
        voPage.setRecords(reviewPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList()));
        return voPage;
    }

    @Override
    public Map<String, Object> checkAllRoomReviews() {
        Map<String, Object> report = new LinkedHashMap<>();
        List<Map<String, Object>> noReviewRooms = new ArrayList<>();
        List<Map<String, Object>> hasReviewRooms = new ArrayList<>();

        List<Room> allRooms = roomMapper.selectList(new LambdaQueryWrapper<Room>().eq(Room::getStatus, 1));
        List<Review> allReviews = reviewMapper.selectList(
                new LambdaQueryWrapper<Review>().eq(Review::getStatus, 1).isNotNull(Review::getRoomId));

        for (Room room : allRooms) {
            Long count = allReviews.stream().filter(r -> room.getId().equals(r.getRoomId())).count();
            Map<String, Object> info = new LinkedHashMap<>();
            info.put("roomId", room.getId());
            info.put("roomName", room.getName());
            info.put("homestayId", room.getHomestayId());
            info.put("reviewCount", count);
            if (count == 0) {
                noReviewRooms.add(info);
            } else {
                hasReviewRooms.add(info);
            }
        }

        report.put("totalRooms", allRooms.size());
        report.put("roomsWithReviews", hasReviewRooms.size());
        report.put("roomsWithoutReviews", noReviewRooms.size());
        report.put("noReviewRooms", noReviewRooms);
        report.put("hasReviewRooms", hasReviewRooms);
        return report;
    }
}
