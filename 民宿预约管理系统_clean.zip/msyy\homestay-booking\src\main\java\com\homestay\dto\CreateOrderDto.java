package com.homestay.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
public class CreateOrderDto {
    @NotNull(message = "房型ID不能为空")
    private Long roomId;

    @NotNull(message = "民宿ID不能为空")
    private Long homestayId;

    private Integer roomCount;

    @NotBlank(message = "入住人姓名不能为空")
    private String guestName;

    @NotBlank(message = "入住人手机号不能为空")
    private String guestPhone;

    @NotNull(message = "入住日期不能为空")
    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate checkInDate;

    @NotNull(message = "退房日期不能为空")
    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate checkOutDate;

    private String remark;
}
