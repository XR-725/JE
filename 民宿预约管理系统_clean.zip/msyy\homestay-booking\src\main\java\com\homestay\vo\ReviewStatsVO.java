package com.homestay.vo;

import lombok.Data;

import java.util.Map;

@Data
public class ReviewStatsVO {
    private Double averageRating;
    private Double averageCleanliness;
    private Double averageLocation;
    private Double averageService;
    private Double averageFacilities;
    private Integer totalReviews;
    private Map<Integer, Long> starDistribution;
}
