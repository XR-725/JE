package com.homestay.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class RoomVO {
    private Long id;
    private Long homestayId;
    private String name;
    private String description;
    private String image;
    private BigDecimal price;
    private Integer totalCount;
    private BigDecimal area;
    private String bedType;
    private Integer maxGuests;
    private Integer hasWifi;
    private Integer hasTv;
    private Integer hasAirConditioner;
    private Integer hasPrivateBathroom;
    private Integer status;
    private Integer availableCount;
}
