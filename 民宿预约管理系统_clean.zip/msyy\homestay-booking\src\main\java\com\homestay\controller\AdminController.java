package com.homestay.controller;

import com.homestay.common.Result;
import com.homestay.entity.Banner;
import com.homestay.entity.Homestay;
import com.homestay.entity.Notice;
import com.homestay.entity.Orders;
import com.homestay.entity.SystemConfig;
import com.homestay.entity.OperationLog;
import com.homestay.entity.User;
import com.homestay.mapper.*;
import com.homestay.service.*;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserMapper userMapper;
    private final HomestayMapper homestayMapper;
    private final OrdersMapper ordersMapper;
    private final UserService userService;
    private final HomestayService homestayService;
    private final OrdersService ordersService;
    private final BannerService bannerService;
    private final NoticeService noticeService;
    private final ReviewService reviewService;
    private final SystemConfigMapper systemConfigMapper;
    private final OperationLogMapper operationLogMapper;

    @GetMapping("/dashboard")
    public Result<?> dashboard() {
        Map<String, Object> data = new HashMap<>();

        data.put("totalUsers", userMapper.selectCount(null));
        com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.homestay.entity.Homestay> hw = 
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
        data.put("totalHomestays", homestayMapper.selectCount(hw));
        data.put("totalOrders", ordersMapper.selectCount(null));

        com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.homestay.entity.Orders> todayW =
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
        todayW.apply("DATE(create_time) = CURDATE()");
        data.put("todayOrders", ordersMapper.selectCount(todayW));

        com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.homestay.entity.Orders> incomeW =
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
        incomeW.eq(com.homestay.entity.Orders::getStatus, "completed");
        List<com.homestay.entity.Orders> allCompleted = ordersMapper.selectList(incomeW);
        BigDecimal totalRevenue = allCompleted.stream()
                .map(com.homestay.entity.Orders::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        data.put("totalRevenue", totalRevenue);

        BigDecimal monthlyRevenue = allCompleted.stream()
                .filter(o -> o.getCreateTime() != null && o.getCreateTime().toLocalDate().getMonth() == LocalDate.now().getMonth())
                .map(com.homestay.entity.Orders::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        data.put("monthlyRevenue", monthlyRevenue);

        Map<String, Long> statusDist = new LinkedHashMap<>();
        String[] statuses = {"pending", "paid", "confirmed", "check_in", "completed", "canceled"};
        for (String s : statuses) {
            com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.homestay.entity.Orders> sw =
                    new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
            sw.eq(com.homestay.entity.Orders::getStatus, s);
            statusDist.put(s, ordersMapper.selectCount(sw));
        }
        data.put("orderStatusDistribution", statusDist);

        data.put("recentOrders", ordersService.getAdminOrders(1, 10, null, null, null, null).getRecords());

        return Result.success(data);
    }

    @GetMapping("/users")
    public Result<?> userList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String role) {
        return Result.success(userService.getUserList(page, size, keyword, role));
    }

    @PutMapping("/users/{id}/status")
    public Result<?> updateUserStatus(@PathVariable Long id, @RequestBody Map<String, Integer> body) {
        userService.updateUserStatus(id, body.get("status"));
        return Result.success();
    }

    @PutMapping("/users/{id}/role")
    public Result<?> updateUserRole(@PathVariable Long id, @RequestBody Map<String, String> body) {
        userService.updateUserRole(id, body.get("role"));
        return Result.success();
    }

    @GetMapping("/homestays")
    public Result<?> homestayList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) Integer status) {
        com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.homestay.entity.Homestay> wrapper =
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
        if (status != null) wrapper.eq(com.homestay.entity.Homestay::getStatus, status);
        wrapper.orderByDesc(com.homestay.entity.Homestay::getCreateTime);
        return Result.success(homestayMapper.selectPage(
                new com.baomidou.mybatisplus.extension.plugins.pagination.Page<>(page, size), wrapper));
    }

    @PutMapping("/homestays/{id}/audit")
    public Result<?> auditHomestay(@PathVariable Long id, @RequestBody Map<String, Integer> body) {
        homestayService.updateHomestayStatus(id, body.get("status"));
        return Result.success();
    }

    @GetMapping("/orders")
    public Result<?> orderList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        return Result.success(ordersService.getAdminOrders(page, size, keyword, status, startDate, endDate));
    }

    @PutMapping("/orders/{id}/cancel")
    public Result<?> cancelOrder(@PathVariable Long id) {
        ordersService.adminCancelOrder(id);
        return Result.success();
    }

    @GetMapping("/reviews")
    public Result<?> reviewList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword) {
        return Result.success(reviewService.getAllReviews(page, size, keyword));
    }

    @DeleteMapping("/reviews/{id}")
    public Result<?> deleteReview(@PathVariable Long id) {
        reviewService.adminDeleteReview(id);
        return Result.success();
    }

    @GetMapping("/banners")
    public Result<?> bannerList() {
        return Result.success(bannerService.getBannerList(null, null));
    }

    @PostMapping("/banners")
    public Result<?> addBanner(@RequestBody Banner banner) {
        bannerService.addBanner(banner);
        return Result.success();
    }

    @PutMapping("/banners/{id}")
    public Result<?> updateBanner(@PathVariable Long id, @RequestBody Banner banner) {
        banner.setId(id);
        bannerService.updateBanner(banner);
        return Result.success();
    }

    @DeleteMapping("/banners/{id}")
    public Result<?> deleteBanner(@PathVariable Long id) {
        bannerService.deleteBanner(id);
        return Result.success();
    }

    @GetMapping("/notices")
    public Result<?> noticeList() {
        return Result.success(noticeService.getAdminNotices(null, null));
    }

    @PostMapping("/notices")
    public Result<?> addNotice(@RequestBody Notice notice) {
        noticeService.addNotice(notice);
        return Result.success();
    }

    @PutMapping("/notices/{id}")
    public Result<?> updateNotice(@PathVariable Long id, @RequestBody Notice notice) {
        notice.setId(id);
        noticeService.updateNotice(notice);
        return Result.success();
    }

    @DeleteMapping("/notices/{id}")
    public Result<?> deleteNotice(@PathVariable Long id) {
        noticeService.deleteNotice(id);
        return Result.success();
    }

    // ── 系统配置 ──
    @GetMapping("/config")
    public Result<?> getConfigList(@RequestParam(required = false) String category) {
        LambdaQueryWrapper<SystemConfig> wrapper = new LambdaQueryWrapper<>();
        if (category != null && !category.isEmpty()) {
            wrapper.eq(SystemConfig::getCategory, category);
        }
        wrapper.orderByAsc(SystemConfig::getCategory, SystemConfig::getId);
        return Result.success(systemConfigMapper.selectList(wrapper));
    }

    @PutMapping("/config/{id}")
    public Result<?> updateConfig(@PathVariable Long id, @RequestBody Map<String, String> body) {
        SystemConfig config = systemConfigMapper.selectById(id);
        if (config == null) return Result.error("配置项不存在");
        config.setConfigValue(body.get("configValue"));
        systemConfigMapper.updateById(config);
        return Result.success();
    }

    // ── 操作日志 ──
    @GetMapping("/logs")
    public Result<?> operationLogs(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer size,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String operation) {
        LambdaQueryWrapper<OperationLog> wrapper = new LambdaQueryWrapper<>();
        if (username != null && !username.isEmpty()) {
            wrapper.like(OperationLog::getUsername, username);
        }
        if (operation != null && !operation.isEmpty()) {
            wrapper.like(OperationLog::getOperation, operation);
        }
        wrapper.orderByDesc(OperationLog::getCreateTime);
        return Result.success(operationLogMapper.selectPage(
                new com.baomidou.mybatisplus.extension.plugins.pagination.Page<>(page, size), wrapper));
    }

    // ── 数据统计 ──
    @GetMapping("/statistics")
    public Result<?> statistics() {
        Map<String, Object> data = new HashMap<>();

        // 月度营收趋势（最近6个月）
        List<Map<String, Object>> monthlyTrend = new ArrayList<>();
        for (int i = 5; i >= 0; i--) {
            LocalDate date = LocalDate.now().minusMonths(i);
            String monthStart = date.withDayOfMonth(1).toString();
            String monthEnd = date.withDayOfMonth(date.lengthOfMonth()).toString();

            LambdaQueryWrapper<Orders> w = new LambdaQueryWrapper<>();
            w.eq(Orders::getStatus, "completed")
             .between(Orders::getCreateTime, monthStart + " 00:00:00", monthEnd + " 23:59:59");
            List<Orders> monthOrders = ordersMapper.selectList(w);
            BigDecimal monthRevenue = monthOrders.stream()
                    .map(Orders::getTotalAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            Map<String, Object> item = new HashMap<>();
            item.put("month", date.getYear() + "." + String.format("%02d", date.getMonthValue()));
            item.put("revenue", monthRevenue);
            item.put("orderCount", monthOrders.size());
            monthlyTrend.add(item);
        }
        data.put("monthlyTrend", monthlyTrend);

        // 城市分布
        List<Map<String, Object>> cityDistribution = new ArrayList<>();
        List<Homestay> allHomestays = homestayMapper.selectList(
                new LambdaQueryWrapper<Homestay>().eq(Homestay::getStatus, 1));
        Map<String, Long> cityCount = allHomestays.stream()
                .collect(Collectors.groupingBy(Homestay::getCity, Collectors.counting()));
        cityCount.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(10)
                .forEach(e -> {
                    Map<String, Object> item = new HashMap<>();
                    item.put("city", e.getKey());
                    item.put("count", e.getValue());
                    cityDistribution.add(item);
                });
        data.put("cityDistribution", cityDistribution);

        // 房东排行（按收入）
        List<Map<String, Object>> hostRanking = new ArrayList<>();
        Map<Long, BigDecimal> hostRevenue = new HashMap<>();
        LambdaQueryWrapper<Orders> completedW = new LambdaQueryWrapper<>();
        completedW.eq(Orders::getStatus, "completed");
        List<Orders> completedOrders = ordersMapper.selectList(completedW);
        for (Orders o : completedOrders) {
            Homestay h = homestayMapper.selectById(o.getHomestayId());
            if (h != null) {
                hostRevenue.merge(h.getHostId(), o.getTotalAmount(), BigDecimal::add);
            }
        }
        hostRevenue.entrySet().stream()
                .sorted(Map.Entry.<Long, BigDecimal>comparingByValue().reversed())
                .limit(10)
                .forEach(e -> {
                    User host = userMapper.selectById(e.getKey());
                    if (host != null) {
                        Map<String, Object> item = new HashMap<>();
                        item.put("hostId", host.getId());
                        item.put("hostName", host.getNickname());
                        item.put("revenue", e.getValue());
                        hostRanking.add(item);
                    }
                });
        data.put("hostRanking", hostRanking);

        return Result.success(data);
    }
}
