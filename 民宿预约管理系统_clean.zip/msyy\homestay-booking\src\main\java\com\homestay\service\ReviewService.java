package com.homestay.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.dto.ReviewDto;
import com.homestay.vo.ReviewVO;
import com.homestay.vo.ReviewStatsVO;

import java.util.Map;

public interface ReviewService {
    void addReview(ReviewDto dto, Long userId);
    Page<ReviewVO> getReviewsByHomestayId(Long homestayId, Integer page, Integer size);
    Page<ReviewVO> getReviewsByRoomId(Long roomId, Integer page, Integer size);
    Page<ReviewVO> getMyReviews(Long userId, Integer page, Integer size);
    Page<ReviewVO> getAllReviews(Integer page, Integer size, String keyword);
    void replyReview(Long reviewId, Long hostId, String reply);
    void deleteReview(Long reviewId, Long userId);
    void adminDeleteReview(Long reviewId);
    ReviewStatsVO getReviewStats(Long homestayId);
    ReviewStatsVO getRoomReviewStats(Long roomId);
    Map<String, Object> checkAllRoomReviews();
}
