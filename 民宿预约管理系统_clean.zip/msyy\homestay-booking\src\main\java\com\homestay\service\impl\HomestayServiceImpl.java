package com.homestay.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.common.BusinessException;
import com.homestay.dto.HomestayDto;
import com.homestay.entity.Homestay;
import com.homestay.entity.Room;
import com.homestay.entity.User;
import com.homestay.mapper.HomestayMapper;
import com.homestay.mapper.RoomMapper;
import com.homestay.mapper.UserMapper;
import com.homestay.service.HomestayService;
import com.homestay.utils.SecurityUtils;
import com.homestay.vo.HomestayVO;
import com.homestay.vo.RoomVO;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HomestayServiceImpl implements HomestayService {

    private final HomestayMapper homestayMapper;
    private final RoomMapper roomMapper;
    private final UserMapper userMapper;

    @Override
    public Page<HomestayVO> getHomestayList(Integer page, Integer size, String keyword, String city,
                                             BigDecimal minPrice, BigDecimal maxPrice, Integer minRating, String sortBy) {
        LambdaQueryWrapper<Homestay> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Homestay::getStatus, 1);

        if (StrUtil.isNotBlank(keyword)) {
            wrapper.and(w -> w.like(Homestay::getName, keyword)
                    .or().like(Homestay::getAddress, keyword)
                    .or().like(Homestay::getDescription, keyword));
        }
        if (StrUtil.isNotBlank(city)) {
            wrapper.eq(Homestay::getCity, city);
        }
        if (minRating != null) {
            wrapper.ge(Homestay::getRating, BigDecimal.valueOf(minRating));
        }

        if ("price_asc".equals(sortBy)) {
            wrapper.last("ORDER BY (SELECT COALESCE(MIN(r.price), 9999999) FROM room r WHERE r.homestay_id = homestay.id AND r.status = 1) ASC");
        } else if ("price_desc".equals(sortBy)) {
            wrapper.last("ORDER BY (SELECT COALESCE(MIN(r.price), 0) FROM room r WHERE r.homestay_id = homestay.id AND r.status = 1) DESC");
        } else if ("rating".equals(sortBy)) {
            wrapper.orderByDesc(Homestay::getRating);
        } else {
            wrapper.orderByDesc(Homestay::getRating).orderByDesc(Homestay::getReviewCount);
        }

        Page<Homestay> homestayPage = homestayMapper.selectPage(new Page<>(page, size), wrapper);
        Page<HomestayVO> voPage = new Page<>(page, size, homestayPage.getTotal());
        voPage.setRecords(homestayPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList()));
        return voPage;
    }

    @Override
    public HomestayVO getHomestayDetail(Long id) {
        Homestay homestay = homestayMapper.selectById(id);
        if (homestay == null) {
            throw new BusinessException("民宿不存在");
        }
        // 非管理员只能查看已上架(status=1)的民宿
        if (homestay.getStatus() != 1 && !SecurityUtils.hasRole("admin")) {
            throw new BusinessException("民宿暂未上架或已下架");
        }
        HomestayVO vo = convertToVO(homestay);

        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getHomestayId, id).eq(Room::getStatus, 1));
        List<RoomVO> roomVOs = rooms.stream().map(room -> {
            RoomVO rvo = new RoomVO();
            BeanUtil.copyProperties(room, rvo);
            rvo.setAvailableCount(room.getTotalCount());
            return rvo;
        }).collect(Collectors.toList());
        vo.setRooms(roomVOs);

        return vo;
    }

    @Override
    @Transactional
    @CacheEvict(value = "hot_homestays", allEntries = true)
    public void addHomestay(HomestayDto dto, Long hostId) {
        Homestay homestay = new Homestay();
        BeanUtil.copyProperties(dto, homestay);
        homestay.setHostId(hostId);
        // 新民宿提交后进入"待审核"状态(status=0)，需管理员审核通过后才能在公共列表展示
        homestay.setStatus(0);
        homestay.setRating(BigDecimal.valueOf(5.0));
        homestay.setReviewCount(0);
        homestayMapper.insert(homestay);
    }

    @Override
    @CacheEvict(value = "hot_homestays", allEntries = true)
    public void updateHomestay(Long id, HomestayDto dto, Long currentUserId) {
        Homestay homestay = homestayMapper.selectById(id);
        if (homestay == null) {
            throw new BusinessException("民宿不存在");
        }
        boolean isAdmin = SecurityUtils.hasRole("admin");
        if (!homestay.getHostId().equals(currentUserId) && !isAdmin) {
            throw new BusinessException("无权修改该民宿");
        }
        BeanUtil.copyProperties(dto, homestay, "id", "hostId", "status", "rating", "reviewCount");
        homestayMapper.updateById(homestay);
    }

    @Override
    @CacheEvict(value = "hot_homestays", allEntries = true)
    public void updateHomestayStatus(Long id, Integer status) {
        Homestay homestay = homestayMapper.selectById(id);
        if (homestay == null) {
            throw new BusinessException("民宿不存在");
        }
        homestay.setStatus(status);
        homestayMapper.updateById(homestay);
    }

    @Override
    @CacheEvict(value = "hot_homestays", allEntries = true)
    public void deleteHomestay(Long id, Long currentUserId) {
        Homestay homestay = homestayMapper.selectById(id);
        if (homestay == null) {
            throw new BusinessException("民宿不存在");
        }
        boolean isAdmin = SecurityUtils.hasRole("admin");
        if (!homestay.getHostId().equals(currentUserId) && !isAdmin) {
            throw new BusinessException("无权删除该民宿");
        }
        homestayMapper.deleteById(id);
    }

    @Override
    public Page<HomestayVO> getMyHomestays(Long hostId, Integer page, Integer size) {
        LambdaQueryWrapper<Homestay> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Homestay::getHostId, hostId).orderByDesc(Homestay::getCreateTime);
        Page<Homestay> homestayPage = homestayMapper.selectPage(new Page<>(page, size), wrapper);
        Page<HomestayVO> voPage = new Page<>(page, size, homestayPage.getTotal());
        voPage.setRecords(homestayPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList()));
        return voPage;
    }

    @Override
    @Cacheable(value = "hot_homestays", key = "#limit")
    public List<HomestayVO> getHotHomestays(Integer limit) {
        LambdaQueryWrapper<Homestay> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Homestay::getStatus, 1)
                .orderByDesc(Homestay::getRating)
                .orderByDesc(Homestay::getReviewCount)
                .last("LIMIT " + limit);
        List<Homestay> list = homestayMapper.selectList(wrapper);
        return list.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    @Override
    public List<HomestayVO> getRecommendHomestays(Integer limit) {
        LambdaQueryWrapper<Homestay> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Homestay::getStatus, 1)
                .ge(Homestay::getRating, BigDecimal.valueOf(4.5))
                .last("ORDER BY RAND() LIMIT " + limit);
        List<Homestay> list = homestayMapper.selectList(wrapper);
        return list.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    private HomestayVO convertToVO(Homestay homestay) {
        HomestayVO vo = new HomestayVO();
        BeanUtil.copyProperties(homestay, vo);

        if (StrUtil.isNotBlank(homestay.getImages())) {
            try {
                vo.setImages(JSONUtil.toList(homestay.getImages(), String.class));
            } catch (Exception e) {
                vo.setImages(new ArrayList<>());
            }
        } else {
            vo.setImages(new ArrayList<>());
        }

        if (StrUtil.isNotBlank(homestay.getFacilities())) {
            vo.setFacilities(Arrays.asList(homestay.getFacilities().split(",")));
        } else {
            vo.setFacilities(new ArrayList<>());
        }

        User host = userMapper.selectById(homestay.getHostId());
        if (host != null) {
            vo.setHostName(host.getNickname());
            vo.setHostAvatar(host.getAvatar());
        }

        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getHomestayId, homestay.getId()).eq(Room::getStatus, 1));
        vo.setRoomCount(rooms.size());
        vo.setMinPrice(rooms.stream().map(Room::getPrice).min(BigDecimal::compareTo).orElse(BigDecimal.ZERO));

        return vo;
    }
}
