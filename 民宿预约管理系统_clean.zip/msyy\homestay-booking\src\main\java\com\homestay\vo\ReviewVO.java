package com.homestay.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class ReviewVO {
    private Long id;
    private Long userId;
    private String userName;
    private String userAvatar;
    private Long orderId;
    private Long homestayId;
    private String homestayName;
    private Long roomId;
    private String roomName;
    private Integer rating;
    private Integer cleanliness;
    private Integer location;
    private Integer service;
    private Integer facilitiesScore;
    private String content;
    private List<String> images;
    private String reply;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime replyTime;

    private Integer status;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;
}
