<template>
  <PageContainer title="管理后台" subtitle="系统运行状态概览">
    <!-- 统计卡片 -->
    <div class="stat-grid">
      <StatCard label="用户总数" :value="dashboard.totalUsers || 0" :icon="User" color="#3B82F6" />
      <StatCard label="民宿总数" :value="dashboard.totalHomestays || 0" :icon="OfficeBuilding" color="#22C55E" />
      <StatCard label="总订单" :value="dashboard.totalOrders || 0" :icon="Document" color="#F59E0B" />
      <StatCard label="今日订单" :value="dashboard.todayOrders || 0" :icon="Calendar" color="#8B5CF6" />
      <StatCard label="总收入" :value="'¥' + formatRevenue(dashboard.totalRevenue)" :icon="Money" color="#FF6B35" />
      <StatCard label="本月收入" :value="'¥' + formatRevenue(dashboard.monthlyRevenue)" :icon="TrendCharts" color="#10B981" />
    </div>

    <!-- 图表行 -->
    <div class="chart-row">
      <el-card class="chart-card">
        <template #header><span class="card-title">订单状态分布</span></template>
        <div v-if="dashboard.orderStatusDistribution" class="status-bars">
          <div v-for="(count, status) in dashboard.orderStatusDistribution" :key="status" class="status-bar">
            <div class="status-label">
              <span class="status-dot" :style="{ background: statusColors[status] }"></span>
              <span>{{ statusMap[status] || status }}</span>
            </div>
            <div class="status-progress">
              <div class="status-fill" :style="{ width: statusPercent(count) + '%', background: statusColors[status] }"></div>
            </div>
            <span class="status-count">{{ count }}</span>
          </div>
        </div>
        <el-empty v-else description="暂无数据" :image-size="60" />
      </el-card>

      <el-card class="chart-card">
        <template #header><span class="card-title">最近订单</span></template>
        <el-table :data="dashboard.recentOrders || []" size="small" style="width:100%" v-if="dashboard.recentOrders?.length">
          <el-table-column prop="orderNo" label="订单号" width="170" show-overflow-tooltip />
          <el-table-column prop="homestayName" label="民宿" show-overflow-tooltip />
          <el-table-column prop="totalAmount" label="金额" width="90">
            <template #default="{ row }"><span class="amount-cell">¥{{ row.totalAmount }}</span></template>
          </el-table-column>
          <el-table-column prop="status" label="状态" width="85">
            <template #default="{ row }">
              <el-tag :type="statusType(row.status)" size="small" effect="plain">{{ statusMap[row.status] }}</el-tag>
            </template>
          </el-table-column>
        </el-table>
        <el-empty v-else description="暂无订单" :image-size="60" />
      </el-card>
    </div>
  </PageContainer>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { getDashboard } from '@/api/admin'
import { User, OfficeBuilding, Document, Money, Calendar, TrendCharts } from '@element-plus/icons-vue'
import StatCard from '@/components/StatCard.vue'
import PageContainer from '@/components/PageContainer.vue'

const dashboard = ref({})

const statusMap = { pending: '待支付', paid: '已支付', confirmed: '已确认', check_in: '已入住', completed: '已完成', canceled: '已取消' }
const statusColors = { pending: '#F59E0B', paid: '#3B82F6', confirmed: '#22C55E', check_in: '#8B5CF6', completed: '#6B7280', canceled: '#EF4444' }
const statusType = (s) => ({ pending: 'warning', paid: '', confirmed: 'success', check_in: 'info', completed: 'info', canceled: 'danger' }[s] || '')

const totalOrders = computed(() => {
  if (!dashboard.value.orderStatusDistribution) return 0
  return Object.values(dashboard.value.orderStatusDistribution).reduce((a, b) => a + b, 0)
})

const statusPercent = (count) => {
  const total = totalOrders.value
  return total ? Math.round(count / total * 100) : 0
}

const formatRevenue = (val) => {
  if (!val) return '0'
  const n = Number(val)
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return n.toFixed(0)
}

onMounted(async () => {
  const res = await getDashboard()
  dashboard.value = res.data || {}
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.stat-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 20px; margin-bottom: 24px;
}

.chart-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.card-title { font-weight: $font-weight-semibold; }

// 状态条
.status-bars { padding: 4px 0; }
.status-bar { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; &:last-child { margin-bottom: 0; } }
.status-label { display: flex; align-items: center; gap: 8px; width: 80px; font-size: $font-size-sm; color: $color-text-regular; flex-shrink: 0; }
.status-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.status-progress { flex: 1; height: 8px; background: $color-bg-alt; border-radius: $radius-full; overflow: hidden; }
.status-fill { height: 100%; border-radius: $radius-full; transition: width 800ms ease; min-width: 2px; }
.status-count { width: 30px; text-align: right; font-size: $font-size-sm; font-weight: $font-weight-semibold; color: $color-text-regular; flex-shrink: 0; }
.amount-cell { color: $color-primary; font-weight: $font-weight-semibold; }

// 响应式
@media (max-width: 1024px) {
  .stat-grid { grid-template-columns: repeat(2, 1fr); }
  .chart-row { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .stat-grid { grid-template-columns: 1fr; }
}
</style>
