<template>
  <PageContainer title="房东工作台" subtitle="您的经营数据一览">
    <!-- 统计卡片 -->
    <div class="stat-grid">
      <StatCard label="我的民宿" :value="stats.homestayCount" :icon="OfficeBuilding" color="#22C55E" />
      <StatCard label="今日订单" :value="stats.todayOrders" :icon="Calendar" color="#3B82F6" />
      <StatCard label="待确认" :value="stats.pendingOrders" :icon="Bell" color="#F59E0B" />
      <StatCard label="本月收入" :value="'¥' + stats.monthRevenue" :icon="Money" color="#FF6B35" />
    </div>

    <!-- 快速入口 -->
    <div class="quick-actions">
      <el-button type="primary" @click="$router.push('/host/homestay/add')">
        <el-icon><CirclePlus /></el-icon>添加民宿
      </el-button>
      <el-button @click="$router.push('/host/homestays')">
        <el-icon><OfficeBuilding /></el-icon>管理民宿
      </el-button>
      <el-button @click="$router.push('/host/orders')">
        <el-icon><Document /></el-icon>查看订单
      </el-button>
      <el-button @click="$router.push('/host/revenue')">
        <el-icon><Money /></el-icon>收益报表
      </el-button>
    </div>

    <!-- 最近订单 -->
    <el-card>
      <template #header>
        <div class="order-header">
          <span class="card-title">最近订单</span>
          <router-link to="/host/orders" class="view-all">查看全部 →</router-link>
        </div>
      </template>
      <el-table :data="recentOrders" size="small" style="width:100%" v-if="recentOrders.length">
        <el-table-column prop="orderNo" label="订单号" width="180" show-overflow-tooltip />
        <el-table-column prop="homestayName" label="民宿" show-overflow-tooltip />
        <el-table-column prop="guestName" label="入住人" width="90" />
        <el-table-column prop="checkInDate" label="入住日期" width="110" />
        <el-table-column prop="totalAmount" label="金额" width="90">
          <template #default="{ row }"><span class="amount-cell">¥{{ row.totalAmount }}</span></template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="typeMap[row.status]" size="small" effect="plain">{{ statusMap[row.status] }}</el-tag>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-else description="暂无订单" :image-size="60" />
    </el-card>
  </PageContainer>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { getMyHomestays } from '@/api/homestay'
import { getHostOrders } from '@/api/order'
import { OfficeBuilding, Document, Money, CirclePlus, Calendar, Bell } from '@element-plus/icons-vue'
import StatCard from '@/components/StatCard.vue'
import PageContainer from '@/components/PageContainer.vue'

const stats = reactive({ homestayCount: 0, todayOrders: 0, pendingOrders: 0, monthRevenue: 0 })
const recentOrders = ref([])
const statusMap = { pending: '待支付', paid: '已支付', confirmed: '已确认', check_in: '已入住', completed: '已完成' }
const typeMap = { pending: 'warning', paid: '', confirmed: 'success', check_in: 'info', completed: 'info' }

onMounted(async () => {
  try {
    const [hsRes, orderRes] = await Promise.all([
      getMyHomestays({ page: 1, size: 100 }),
      getHostOrders({ page: 1, size: 50 })
    ])
    stats.homestayCount = hsRes.data?.total || 0
    const orders = orderRes.data?.records || []
    recentOrders.value = orders.slice(0, 10)

    const now = new Date()
    const todayStr = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}.${String(now.getDate()).padStart(2, '0')}`
    stats.todayOrders = orders.filter(o => o.createTime?.startsWith(todayStr)).length
    stats.pendingOrders = orders.filter(o => o.status === 'paid').length

    const monthStr = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}`
    stats.monthRevenue = orders
      .filter(o => o.status === 'completed' && o.createTime?.startsWith(monthStr))
      .reduce((sum, o) => sum + Number(o.totalAmount || 0), 0)
      .toFixed(0)
  } catch (e) {}
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
.quick-actions { display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; }
.order-header { display: flex; justify-content: space-between; align-items: center; }
.card-title { font-weight: $font-weight-semibold; }
.view-all { font-size: $font-size-sm; color: $color-primary; text-decoration: none; &:hover { text-decoration: underline; } }
.amount-cell { color: $color-primary; font-weight: $font-weight-semibold; }

@media (max-width: 768px) { .stat-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px) { .stat-grid { grid-template-columns: 1fr; } .quick-actions { flex-direction: column; } }
</style>
