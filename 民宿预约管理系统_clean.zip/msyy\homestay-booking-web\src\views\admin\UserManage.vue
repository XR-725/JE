<template>
  <div class="admin-page">
    <div class="page-header">
      <h3>{{ title }}</h3>
    </div>
    <el-card>
      <div class="toolbar">
        <el-input v-model="keyword" placeholder="搜索用户名/昵称/手机号" clearable style="width:220px" @change="fetchData" />
        <el-select v-model="roleFilter" placeholder="角色筛选" clearable style="width:140px" @change="fetchData">
          <el-option label="全部" value="" />
          <el-option label="普通用户" value="user" />
          <el-option label="房东" value="host" />
          <el-option label="管理员" value="admin" />
        </el-select>
      </div>

      <el-table :data="list" border stripe style="width:100%;margin-top:16px">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column prop="nickname" label="昵称" width="120" />
        <el-table-column prop="phone" label="手机号" width="130" />
        <el-table-column prop="role" label="角色" width="160">
          <template #default="{ row }">
            <template v-for="(r, idx) in parseRoles(row.role)" :key="idx">
              <el-tag :type="r === 'admin' ? 'danger' : r === 'host' ? 'warning' : ''" size="small" style="margin-right:4px">{{ roleMap[r] || r }}</el-tag>
            </template>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'danger'" size="small">{{ row.status === 1 ? '正常' : '禁用' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="注册时间" width="160" />
        <el-table-column label="操作" min-width="180">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="editRole(row)">改角色</el-button>
            <el-button :type="row.status === 1 ? 'danger' : 'success'" link size="small" @click="toggleStatus(row)">{{ row.status === 1 ? '禁用' : '启用' }}</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap" style="margin-top:16px;text-align:right">
        <el-pagination
          v-model:current-page="page"
          :page-size="size"
          :total="total"
          layout="prev, pager, next, total"
          background
          @current-change="fetchData"
        />
      </div>
    </el-card>

    <el-dialog v-model="roleVisible" title="修改角色" width="420px">
      <p style="margin-bottom:12px;color:#909399;font-size:13px">可多选，用户可同时拥有多个角色</p>
      <el-checkbox-group v-model="editRoleValues">
        <el-checkbox label="user">普通用户</el-checkbox>
        <el-checkbox label="host">房东</el-checkbox>
        <el-checkbox label="admin">管理员</el-checkbox>
      </el-checkbox-group>
      <template #footer>
        <el-button @click="roleVisible = false">取消</el-button>
        <el-button type="primary" :loading="roleLoading" @click="confirmRole">确认</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getUserList, updateUserStatus, updateUserRole } from '@/api/admin'

defineProps({ title: { type: String, default: '用户管理' } })

const list = ref([])
const page = ref(1)
const size = ref(10)
const total = ref(0)
const keyword = ref('')
const roleFilter = ref('')
const roleMap = { admin: '管理员', host: '房东', user: '用户' }

const roleVisible = ref(false)
const editRoleValues = ref(['user'])
const editingUser = ref(null)
const roleLoading = ref(false)

const parseRoles = (role) => {
  if (!role) return ['user']
  return role.split(',').map(s => s.trim()).filter(Boolean)
}

const fetchData = async () => {
  const res = await getUserList({ page: page.value, size: size.value, keyword: keyword.value || undefined, role: roleFilter.value || undefined })
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

const toggleStatus = async (row) => {
  try {
    const action = row.status === 1 ? '禁用' : '启用'
    await ElMessageBox.confirm(`确定${action}该用户？`, '提示', { type: 'warning' })
    await updateUserStatus(row.id, row.status === 1 ? 0 : 1)
    ElMessage.success(`${action}成功`)
    fetchData()
  } catch (e) {}
}

const editRole = (row) => {
  editingUser.value = row
  editRoleValues.value = parseRoles(row.role)
  roleVisible.value = true
}

const confirmRole = async () => {
  if (editRoleValues.value.length === 0) {
    ElMessage.warning('请至少选择一个角色')
    return
  }
  roleLoading.value = true
  try {
    await updateUserRole(editingUser.value.id, editRoleValues.value.join(','))
    ElMessage.success('角色修改成功')
    roleVisible.value = false
    fetchData()
  } catch (e) {} finally { roleLoading.value = false }
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.page-header h3 { margin-bottom: 16px; }
.toolbar { display: flex; gap: 12px; }
</style>
