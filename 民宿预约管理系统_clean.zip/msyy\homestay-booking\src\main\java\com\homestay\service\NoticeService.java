package com.homestay.service;

import com.homestay.entity.Notice;

import java.util.List;

public interface NoticeService {
    List<Notice> getSystemNotices(Integer page, Integer size);
    List<Notice> getAdminNotices(Integer page, Integer size);
    void addNotice(Notice notice);
    void updateNotice(Notice notice);
    void deleteNotice(Long id);
    long getUnreadCount(Long userId);
    void markAsRead(Long noticeId, Long userId);
}
