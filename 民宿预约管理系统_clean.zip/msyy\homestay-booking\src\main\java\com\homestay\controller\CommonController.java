package com.homestay.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.homestay.common.Result;
import com.homestay.entity.Homestay;
import com.homestay.mapper.HomestayMapper;
import com.homestay.mapper.OrdersMapper;
import com.homestay.service.BannerService;
import com.homestay.service.FavoriteService;
import com.homestay.service.NoticeService;
import com.homestay.utils.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CommonController {

    private final FavoriteService favoriteService;
    private final BannerService bannerService;
    private final NoticeService noticeService;
    private final HomestayMapper homestayMapper;
    private final OrdersMapper ordersMapper;

    // Favorite
    @PostMapping("/favorite/{homestayId}")
    public Result<?> addFavorite(@PathVariable Long homestayId) {
        if (SecurityUtils.hasRole("admin")) {
            return Result.error("管理员无需收藏功能");
        }
        favoriteService.addFavorite(SecurityUtils.getCurrentUserId(), homestayId);
        return Result.success("收藏成功");
    }

    @DeleteMapping("/favorite/{homestayId}")
    public Result<?> removeFavorite(@PathVariable Long homestayId) {
        if (SecurityUtils.hasRole("admin")) {
            return Result.error("管理员无需收藏功能");
        }
        favoriteService.removeFavorite(SecurityUtils.getCurrentUserId(), homestayId);
        return Result.success("取消收藏");
    }

    @GetMapping("/favorite/check/{homestayId}")
    public Result<Boolean> checkFavorite(@PathVariable Long homestayId) {
        if (SecurityUtils.hasRole("admin")) {
            return Result.success(false);
        }
        return Result.success(favoriteService.isFavorite(SecurityUtils.getCurrentUserId(), homestayId));
    }

    @GetMapping("/favorite/my")
    public Result<?> myFavorites(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        if (SecurityUtils.hasRole("admin")) {
            return Result.success(java.util.Collections.emptyMap());
        }
        return Result.success(favoriteService.getMyFavorites(SecurityUtils.getCurrentUserId(), page, size));
    }

    // Banner
    @GetMapping("/banner/list")
    public Result<?> banners() {
        return Result.success(bannerService.getBanners());
    }

    // Notice
    @GetMapping("/notice/list")
    public Result<?> notices(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        return Result.success(noticeService.getSystemNotices(page, size));
    }

    @GetMapping("/notice/unread-count")
    public Result<Long> unreadCount() {
        return Result.success(noticeService.getUnreadCount(SecurityUtils.getCurrentUserId()));
    }

    @PutMapping("/notice/read/{id}")
    public Result<?> markAsRead(@PathVariable Long id) {
        noticeService.markAsRead(id, SecurityUtils.getCurrentUserId());
        return Result.success();
    }

    // Stats
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        Map<String, Object> data = new HashMap<>();
        long homestayCount = homestayMapper.selectCount(
                new LambdaQueryWrapper<Homestay>().eq(Homestay::getStatus, 1));
        long cityCount = homestayMapper.selectList(
                new LambdaQueryWrapper<Homestay>().eq(Homestay::getStatus, 1).select(Homestay::getCity))
                .stream().map(Homestay::getCity).distinct().count();
        long orderCount = ordersMapper.selectCount(null);
        data.put("homestayCount", homestayCount);
        data.put("cityCount", cityCount);
        data.put("orderCount", orderCount);
        return Result.success(data);
    }
}
