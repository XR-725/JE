package com.homestay.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("user")
public class User {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String username;
    private String password;
    private String nickname;
    private String phone;
    private String email;
    private String avatar;
    private Integer gender;
    private Integer status;
    private String role;

    /** Parse comma-separated roles */
    public List<String> getRoleList() {
        if (role == null || role.isEmpty()) return Collections.singletonList("user");
        return Arrays.asList(role.split(","));
    }

    /** Check if user has a specific role */
    public boolean hasRole(String r) {
        return getRoleList().contains(r);
    }

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime updateTime;
}
