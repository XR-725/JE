<template>
  <div class="default-layout">
    <!-- 顶部导航栏 -->
    <header class="header" :class="{ 'header--scrolled': isScrolled }">
      <div class="header-inner">
        <!-- Logo -->
        <div class="logo" @click="$router.push('/home')">
          <div class="logo-icon">
            <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16 4L4 14v14h8v-8h8v8h8V14L16 4z" fill="currentColor" opacity="0.9"/>
              <path d="M16 4l12 10v14h-8v-8h-8v8H4V14l12-10z" fill="currentColor" fill-opacity="0.3"/>
            </svg>
          </div>
          <span class="logo-text">民宿预约</span>
        </div>

        <!-- 桌面导航 -->
        <nav class="nav-desktop">
          <router-link to="/home" class="nav-link" exact-active-class="nav-link--active">
            <el-icon><HomeFilled /></el-icon>
            <span>首页</span>
          </router-link>
          <router-link to="/home/homestay/list" class="nav-link" active-class="nav-link--active">
            <el-icon><VideoCamera /></el-icon>
            <span>民宿列表</span>
          </router-link>
        </nav>

        <!-- 右侧操作区 -->
        <div class="header-actions">
          <!-- 移动端菜单按钮 -->
          <button class="mobile-menu-btn" @click="mobileMenuOpen = !mobileMenuOpen" aria-label="菜单">
            <span :class="{ open: mobileMenuOpen }"></span>
          </button>

          <!-- 用户区域 -->
          <template v-if="userStore.isLoggedIn">
            <el-dropdown trigger="click" @command="handleCommand" popper-class="user-dropdown-popper">
              <div class="user-avatar-btn">
                <el-avatar :size="36" :src="userStore.avatar" class="avatar">
                  {{ userStore.nickname?.charAt(0) || 'U' }}
                </el-avatar>
                <span class="username">{{ userStore.nickname }}</span>
                <span v-if="userStore.genderText" class="user-gender">{{ userStore.genderText }}</span>
                <el-icon class="chevron"><ArrowDown /></el-icon>
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <div class="dropdown-user-card">
                    <el-avatar :size="44" :src="userStore.avatar">{{ userStore.nickname?.charAt(0) }}</el-avatar>
                    <div>
                      <p class="dropdown-username">{{ userStore.nickname }}</p>
                      <p class="dropdown-role">{{ roleLabel }}</p>
                    </div>
                  </div>
                  <el-dropdown-item command="profile" divided>
                    <el-icon><User /></el-icon>个人中心
                  </el-dropdown-item>
                  <el-dropdown-item v-if="!userStore.hasRole('admin')" command="orders">
                    <el-icon><Document /></el-icon>我的订单
                  </el-dropdown-item>
                  <el-dropdown-item v-if="!userStore.hasRole('admin')" command="favorites">
                    <el-icon><Star /></el-icon>我的收藏
                  </el-dropdown-item>
                  <el-dropdown-item v-if="userStore.hasRole('host') && !userStore.hasRole('admin')" command="hostCenter" divided>
                    <el-icon><HomeFilled /></el-icon>房东中心
                  </el-dropdown-item>
                  <el-dropdown-item v-if="userStore.hasRole('admin')" command="adminCenter" divided>
                    <el-icon><Setting /></el-icon>管理后台
                  </el-dropdown-item>
                  <el-dropdown-item command="logout" divided>
                    <el-icon><SwitchButton /></el-icon>退出登录
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
          <template v-else>
            <div class="auth-btns">
              <el-button class="btn-login" @click="$router.push('/login')">登录</el-button>
              <el-button class="btn-register" type="primary" @click="$router.push('/register')">注册</el-button>
            </div>
          </template>
        </div>
      </div>
    </header>

    <!-- 移动端抽屉菜单 -->
    <Transition name="drawer">
      <div v-if="mobileMenuOpen" class="mobile-drawer-overlay" @click.self="mobileMenuOpen = false">
        <div class="mobile-drawer">
          <div class="drawer-header">
            <span class="drawer-title">导航菜单</span>
            <button class="drawer-close" @click="mobileMenuOpen = false" aria-label="关闭">
              <el-icon :size="20"><Close /></el-icon>
            </button>
          </div>
          <div class="drawer-body">
            <router-link to="/home" class="drawer-link" @click="mobileMenuOpen = false">
              <el-icon><HomeFilled /></el-icon>首页
            </router-link>
            <router-link to="/home/homestay/list" class="drawer-link" @click="mobileMenuOpen = false">
              <el-icon><VideoCamera /></el-icon>民宿列表
            </router-link>
            <template v-if="!userStore.isLoggedIn">
              <div class="drawer-divider"></div>
              <el-button class="drawer-login-btn" type="primary" @click="$router.push('/login'); mobileMenuOpen = false">登录 / 注册</el-button>
            </template>
          </div>
        </div>
      </div>
    </Transition>

    <!-- 主内容区 - 带路由过渡动画 -->
    <main class="main-content">
      <router-view v-slot="{ Component }">
        <Transition name="page-fade" mode="out-in">
          <component :is="Component" :key="$route.fullPath" />
        </Transition>
      </router-view>
    </main>

    <footer class="footer">
    </footer>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useUserStore } from '@/stores/user'
import { useRouter } from 'vue-router'

const userStore = useUserStore()
const router = useRouter()

const isScrolled = ref(false)
const mobileMenuOpen = ref(false)

const roleLabel = computed(() => {
  const map = { admin: '系统管理员', host: '房东', user: '普通用户' }
  // Show the highest-priority role label for multi-role users
  const roles = userStore.roles
  if (roles.includes('admin')) return map.admin
  if (roles.includes('host')) return map.host
  return map.user || '用户'
})

const handleScroll = () => {
  isScrolled.value = window.scrollY > 10
}

onMounted(() => window.addEventListener('scroll', handleScroll, { passive: true }))
onUnmounted(() => window.removeEventListener('scroll', handleScroll))

const handleCommand = (command) => {
  const routes = {
    profile: '/home/user/profile',
    orders: '/home/order/list',
    favorites: '/home/user/favorites',
    hostCenter: '/host',
    adminCenter: '/admin'
  }
  if (command === 'logout') {
    userStore.logout()
    router.push('/login')
    return
  }
  if (routes[command]) router.push(routes[command])
}
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

// ── 整体布局 ──
.default-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

// ── 顶栏 ──
.header {
  position: sticky;
  top: 0;
  z-index: $z-sticky;
  height: $header-height;
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(16px) saturate(180%);
  -webkit-backdrop-filter: blur(16px) saturate(180%);
  border-bottom: 1px solid transparent;
  transition: all $transition-base;

  &--scrolled {
    border-bottom-color: $color-border;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }
}

.header-inner {
  max-width: $max-width;
  margin: 0 auto;
  height: 100%;
  display: flex;
  align-items: center;
  padding: 0 $spacing-xl;
  gap: $spacing-2xl;
}

// ── Logo ──
.logo {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  color: $color-primary;
  flex-shrink: 0;
  transition: transform $transition-fast;

  &:hover { transform: scale(1.03); }
  &:active { transform: scale(0.98); }

  .logo-icon {
    width: 36px;
    height: 36px;
    background: linear-gradient(135deg, $color-primary, $color-primary-light);
    border-radius: $radius-base;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    padding: 6px;
  }

  .logo-text {
    font-size: $font-size-xl;
    font-weight: $font-weight-bold;
    background: linear-gradient(135deg, $color-primary, $color-primary-dark);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
}

// ── 桌面导航 ──
.nav-desktop {
  display: flex;
  align-items: center;
  gap: $spacing-xs;

  .nav-link {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: $radius-base;
    color: $color-text-regular;
    font-size: $font-size-base;
    font-weight: $font-weight-medium;
    transition: all $transition-fast;
    position: relative;

    &:hover {
      color: $color-primary;
      background: $color-primary-lighter;
    }

    &--active {
      color: $color-primary;
      background: $color-primary-lighter;
      font-weight: $font-weight-semibold;
    }
  }
}

// ── 右侧操作区 ──
.header-actions {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.auth-btns {
  display: flex;
  gap: $spacing-sm;

  .btn-login {
    border-radius: $radius-base;
    font-weight: $font-weight-medium;
  }

  .btn-register {
    border-radius: $radius-base;
    font-weight: $font-weight-medium;
    background: linear-gradient(135deg, $color-primary, $color-primary-light);
    border: none;

    &:hover {
      background: linear-gradient(135deg, $color-primary-dark, $color-primary);
    }
  }
}

// ── 用户头像按钮 ──
.user-avatar-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 4px 12px 4px 4px;
  border-radius: $radius-full;
  cursor: pointer;
  transition: background $transition-fast;
  user-select: none;

  &:hover {
    background: $color-bg-alt;
  }

  .avatar {
    border: 2px solid $color-primary-lighter;
    transition: border-color $transition-fast;
  }

  &:hover .avatar {
    border-color: $color-primary;
  }

  .username {
    font-size: $font-size-base;
    color: $color-text-primary;
    font-weight: $font-weight-medium;
    max-width: 100px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .user-gender {
    font-size: $font-size-xs;
    color: $color-text-secondary;
  }

  .chevron {
    font-size: $font-size-xs;
    color: $color-text-secondary;
    transition: transform $transition-fast;
  }

  &:hover .chevron {
    transform: translateY(2px);
  }
}

// ── 移动端菜单按钮 ──
.mobile-menu-btn {
  display: none;
  width: 36px;
  height: 36px;
  border: none;
  background: none;
  cursor: pointer;
  padding: 8px;
  position: relative;

  span {
    display: block;
    width: 100%;
    height: 2px;
    background: $color-text-primary;
    border-radius: 2px;
    transition: all $transition-base;
    position: relative;

    &::before, &::after {
      content: '';
      position: absolute;
      width: 100%;
      height: 2px;
      background: $color-text-primary;
      border-radius: 2px;
      transition: all $transition-base;
      left: 0;
    }
    &::before { top: -7px; }
    &::after { top: 7px; }

    &.open {
      background: transparent;
      &::before { top: 0; transform: rotate(45deg); }
      &::after { top: 0; transform: rotate(-45deg); }
    }
  }
}

// ── 主内容 ──
.main-content {
  flex: 1;
}

// ── 页面过渡动画 ──
.page-fade-enter-active {
  animation: fadeInUp 0.3s ease-out;
}
.page-fade-leave-active {
  animation: fadeIn 0.15s ease-in reverse;
}

// ── 移动端抽屉 ──
.mobile-drawer-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.4);
  z-index: $z-overlay;
  display: flex;
  justify-content: flex-end;
}

.mobile-drawer {
  width: 280px;
  max-width: 85vw;
  height: 100%;
  background: $color-surface;
  box-shadow: -4px 0 24px rgba(0,0,0,0.12);
  display: flex;
  flex-direction: column;
}

.drawer-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: $spacing-lg $spacing-xl;
  border-bottom: 1px solid $color-border-light;

  .drawer-title {
    font-size: $font-size-lg;
    font-weight: $font-weight-semibold;
  }

  .drawer-close {
    width: 36px;
    height: 36px;
    border: none;
    background: $color-bg-alt;
    border-radius: $radius-base;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background $transition-fast;

    &:hover { background: $color-border; }
  }
}

.drawer-body {
  flex: 1;
  padding: $spacing-base;
  overflow-y: auto;
}

.drawer-link {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  border-radius: $radius-base;
  color: $color-text-primary;
  font-size: $font-size-md;
  font-weight: $font-weight-medium;
  transition: all $transition-fast;

  &:hover {
    background: $color-primary-lighter;
    color: $color-primary;
  }
}

.drawer-divider {
  height: 1px;
  background: $color-border-light;
  margin: $spacing-base 0;
}

.drawer-login-btn {
  width: 100%;
  margin-top: $spacing-sm;
}

.drawer-enter-active { transition: all 0.3s ease-out; }
.drawer-leave-active { transition: all 0.2s ease-in; }
.drawer-enter-from,
.drawer-leave-to { opacity: 0; }
.drawer-enter-from .mobile-drawer,
.drawer-leave-to .mobile-drawer { transform: translateX(100%); }
.drawer-enter-active .mobile-drawer { transition: transform 0.3s $transition-spring; }
.drawer-leave-active .mobile-drawer { transition: transform 0.25s ease-in; }

// ── 页脚 ──
.footer {
  background: $color-dark-bg;
  color: $color-dark-text;
  margin-top: auto;
  padding: $spacing-4xl 0 0;
}

.footer-inner {
  max-width: $max-width;
  margin: 0 auto;
  padding: 0 $spacing-xl;
}

.footer-grid {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: $spacing-3xl;
  padding-bottom: $spacing-3xl;
  border-bottom: 1px solid rgba(255,255,255,0.08);
}

.footer-brand {
  .footer-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: $font-size-lg;
    font-weight: $font-weight-bold;
    color: $color-white;
    margin-bottom: $spacing-base;

    svg {
      width: 28px;
      height: 28px;
      color: $color-primary;
    }
  }

  .footer-desc {
    font-size: $font-size-sm;
    color: $color-dark-text;
    line-height: $line-height-relaxed;
  }
}

.footer-col {
  h4 {
    color: $color-white;
    font-size: $font-size-base;
    font-weight: $font-weight-semibold;
    margin-bottom: $spacing-lg;
  }

  a {
    display: block;
    font-size: $font-size-sm;
    color: $color-dark-text;
    margin-bottom: $spacing-sm;
    transition: color $transition-fast;

    &:hover { color: $color-primary-light; }
  }
}

.footer-bottom {
  padding: $spacing-xl 0;
  text-align: center;
  font-size: $font-size-xs;
  color: rgba(255,255,255,0.3);
}

// ── 用户下拉面板 ──
:deep(.user-dropdown-popper) {
  .dropdown-user-card {
    display: flex;
    align-items: center;
    gap: $spacing-md;
    padding: $spacing-base $spacing-base $spacing-sm;
    margin-bottom: $spacing-xs;
  }
  .dropdown-username {
    font-weight: $font-weight-semibold;
    font-size: $font-size-base;
    margin: 0;
  }
  .dropdown-role {
    font-size: $font-size-xs;
    color: $color-text-secondary;
    margin: 2px 0 0;
  }
}

// ── 响应式 ──
@media (max-width: 768px) {
  .nav-desktop { display: none; }
  .mobile-menu-btn { display: flex; }
  .header-inner { padding: 0 $spacing-base; }

  .user-avatar-btn .username { display: none; }
  .auth-btns .btn-login { display: none; }

  .footer-grid {
    grid-template-columns: 1fr 1fr;
    gap: $spacing-2xl;
  }
  .footer-brand { grid-column: 1 / -1; }
}

@media (max-width: 480px) {
  .footer-grid { grid-template-columns: 1fr; gap: $spacing-xl; }
}
</style>
