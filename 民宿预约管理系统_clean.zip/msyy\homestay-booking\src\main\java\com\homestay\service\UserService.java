package com.homestay.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.dto.LoginDto;
import com.homestay.dto.RegisterDto;
import com.homestay.dto.UpdatePasswordDto;
import com.homestay.dto.UpdateUserDto;
import com.homestay.vo.LoginVO;
import com.homestay.vo.UserVO;

public interface UserService {
    LoginVO login(LoginDto dto);
    void register(RegisterDto dto);
    UserVO getUserById(Long id);
    UserVO getCurrentUser();
    void updateProfile(Long userId, UpdateUserDto dto);
    void updatePassword(Long userId, UpdatePasswordDto dto);
    void updateAvatar(Long userId, String avatarUrl);
    Page<UserVO> getUserList(Integer page, Integer size, String keyword, String role);
    void updateUserStatus(Long userId, Integer status);
    void updateUserRole(Long userId, String role);
}
