package com.homestay.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class RoomDto {
    @NotNull(message = "民宿ID不能为空")
    private Long homestayId;

    @NotBlank(message = "房型名称不能为空")
    private String name;

    private String description;
    private String image;

    @NotNull(message = "价格不能为空")
    private BigDecimal price;

    private Integer totalCount;
    private BigDecimal area;
    private String bedType;
    private Integer maxGuests;
    private Integer hasWifi;
    private Integer hasTv;
    private Integer hasAirConditioner;
    private Integer hasPrivateBathroom;
}
