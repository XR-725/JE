package com.homestay.utils;

import com.homestay.config.SecurityUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class SecurityUtils {

    public static SecurityUser getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof SecurityUser) {
            return (SecurityUser) authentication.getPrincipal();
        }
        return null;
    }

    public static Long getCurrentUserId() {
        SecurityUser user = getCurrentUser();
        return user != null ? user.getUserId() : null;
    }

    public static String getCurrentUserRole() {
        SecurityUser user = getCurrentUser();
        return user != null ? user.getRole() : null;
    }

    public static java.util.List<String> getCurrentUserRoles() {
        SecurityUser user = getCurrentUser();
        return user != null ? user.getRoleList() : java.util.Collections.singletonList("user");
    }

    public static boolean hasRole(String role) {
        SecurityUser user = getCurrentUser();
        return user != null && user.hasRole(role);
    }
}
