package com.homestay.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ReviewDto {
    private Long orderId;

    @NotNull(message = "民宿ID不能为空")
    private Long homestayId;

    private Long roomId;

    @NotNull(message = "评分不能为空")
    private Integer rating;

    private Integer cleanliness;

    private Integer location;

    private Integer service;

    private Integer facilitiesScore;

    private String content;
    private String images;
}
