<template>
  <div class="order-detail-page">
    <div class="page-container">
      <div class="detail-card" v-if="order">
        <div class="status-bar">
          <el-tag :type="statusType(order.status)" size="large">{{ statusText(order.status) }}</el-tag>
          <span class="order-no">订单号: {{ order.orderNo }}</span>
        </div>
        <el-divider />

        <el-steps :active="statusStep(order.status)" align-center>
          <el-step title="下单" />
          <el-step title="支付" />
          <el-step title="确认" />
          <el-step title="入住" />
          <el-step title="完成" />
        </el-steps>

        <el-divider />

        <div class="detail-grid">
          <div class="detail-item">
            <label>民宿名称</label>
            <span>{{ order.homestayName }}</span>
          </div>
          <div class="detail-item">
            <label>房型</label>
            <span>{{ order.roomName }} × {{ order.roomCount }}间</span>
          </div>
          <div class="detail-item">
            <label>入住日期</label>
            <span>{{ order.checkInDate }}</span>
          </div>
          <div class="detail-item">
            <label>退房日期</label>
            <span>{{ order.checkOutDate }} ({{ order.nights }}晚)</span>
          </div>
          <div class="detail-item">
            <label>入住人</label>
            <span>{{ order.guestName }} / {{ order.guestPhone }}</span>
          </div>
          <div class="detail-item">
            <label>支付方式</label>
            <span>{{ order.payMethod || '未支付' }}</span>
          </div>
          <div class="detail-item">
            <label>支付时间</label>
            <span>{{ order.payTime || '-' }}</span>
          </div>
          <div class="detail-item total-item">
            <label>订单金额</label>
            <span class="total-amount">¥{{ order.totalAmount }}</span>
          </div>
        </div>

        <div v-if="order.remark" class="remark">
          <label>备注</label>
          <p>{{ order.remark }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { getOrderDetail } from '@/api/order'

const route = useRoute()
const order = ref(null)

const statusType = (s) => {
  const map = { pending: 'warning', paid: '', confirmed: 'success', check_in: '', completed: 'info', canceled: 'danger' }
  return map[s] || 'info'
}
const statusText = (s) => {
  const map = { pending: '待支付', paid: '已支付', confirmed: '已确认', check_in: '已入住', completed: '已完成', canceled: '已取消' }
  return map[s] || s
}
const statusStep = (s) => {
  const map = { pending: 0, paid: 1, confirmed: 2, check_in: 3, completed: 4 }
  return map[s] !== undefined ? map[s] : 0
}

onMounted(async () => {
  const res = await getOrderDetail(route.params.id)
  order.value = res.data
})
</script>

<style lang="scss" scoped>
.page-container { max-width: 800px; margin: 0 auto; padding: 24px 20px; }
.detail-card { background: #fff; border-radius: 12px; padding: 32px; }
.status-bar { display: flex; align-items: center; gap: 16px;
  .order-no { color: #909399; font-size: 13px; }
}
.detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.detail-item {
  label { display: block; font-size: 13px; color: #909399; margin-bottom: 4px; }
  span { font-size: 15px; color: #303133; }
}
.total-item { grid-column: span 2; border-top: 1px solid #ebeef5; padding-top: 16px; }
.total-amount { font-size: 22px; font-weight: bold; color: #ff6b35; }
.remark { margin-top: 20px;
  label { font-size: 13px; color: #909399; }
  p { color: #606266; margin-top: 4px; }
}
</style>
