package com.homestay.controller;

import com.homestay.common.Result;
import com.homestay.dto.*;
import com.homestay.service.UserService;
import com.homestay.utils.SecurityUtils;
import com.homestay.vo.LoginVO;
import com.homestay.vo.UserVO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @Value("${upload.path}")
    private String uploadPath;

    @PostMapping("/login")
    public Result<LoginVO> login(@Valid @RequestBody LoginDto dto) {
        return Result.success(userService.login(dto));
    }

    @PostMapping("/register")
    public Result<?> register(@Valid @RequestBody RegisterDto dto) {
        userService.register(dto);
        return Result.success("注册成功");
    }

    @GetMapping("/info")
    public Result<UserVO> info() {
        return Result.success(userService.getCurrentUser());
    }

    @PutMapping("/profile")
    public Result<?> updateProfile(@Valid @RequestBody UpdateUserDto dto) {
        userService.updateProfile(SecurityUtils.getCurrentUserId(), dto);
        return Result.success("更新成功");
    }

    @PutMapping("/password")
    public Result<?> updatePassword(@Valid @RequestBody UpdatePasswordDto dto) {
        userService.updatePassword(SecurityUtils.getCurrentUserId(), dto);
        return Result.success("密码修改成功");
    }

    @PostMapping("/avatar")
    public Result<String> uploadAvatar(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return Result.error("文件不能为空");
        }

        String datePath = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        String uploadDir = uploadPath + "/avatars/" + datePath + "/";
        File dir = new File(uploadDir);
        if (!dir.exists()) dir.mkdirs();

        String originalName = file.getOriginalFilename();
        String ext = originalName != null && originalName.contains(".") ? originalName.substring(originalName.lastIndexOf(".")) : ".jpg";
        String fileName = UUID.randomUUID().toString() + ext;
        File dest = new File(uploadDir + fileName);
        file.transferTo(dest);

        String avatarUrl = "/uploads/avatars/" + datePath + "/" + fileName;
        userService.updateAvatar(SecurityUtils.getCurrentUserId(), avatarUrl);
        return Result.success("操作成功", avatarUrl);
    }
}
