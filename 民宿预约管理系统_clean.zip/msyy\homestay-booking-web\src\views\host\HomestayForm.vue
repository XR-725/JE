<template>
  <div class="homestay-form-page">
    <div class="page-header"><h3>{{ isEdit ? '编辑民宿' : '添加民宿' }}</h3></div>
    <el-card>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px" class="form-main">
        <el-form-item label="民宿名称" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="8">
            <el-form-item label="省份"><el-input v-model="form.province" /></el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="城市"><el-input v-model="form.city" /></el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="区/县"><el-input v-model="form.district" /></el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="详细地址"><el-input v-model="form.address" /></el-form-item>
        <el-form-item label="民宿描述">
          <el-input v-model="form.description" type="textarea" :rows="4" />
        </el-form-item>

        <!-- 封面图片上传 -->
        <el-form-item label="封面图片">
          <div class="cover-area">
            <div v-if="form.coverImage" class="cover-preview-wrap">
              <el-image :src="form.coverImage" fit="cover" class="cover-preview" :preview-src-list="[form.coverImage]" />
              <div class="cover-actions">
                <el-button type="danger" plain size="small" @click="form.coverImage = ''">
                  <el-icon><Delete /></el-icon>移除封面
                </el-button>
              </div>
            </div>
            <el-upload
              v-if="!form.coverImage"
              class="cover-uploader"
              :http-request="handleCoverUpload"
              :show-file-list="false"
            >
              <div class="upload-placeholder">
                <el-icon class="upload-icon"><Plus /></el-icon>
                <span>上传封面</span>
              </div>
            </el-upload>
          </div>
          <div class="upload-tip">建议尺寸 800×600，支持 jpg/png/webp，不超过 10MB</div>
        </el-form-item>

        <!-- 多张图片上传 -->
        <el-form-item label="民宿图片">
          <div class="images-grid">
            <div v-for="(url, idx) in imageUrls" :key="url" class="image-thumb">
              <el-image :src="url" fit="cover" :preview-src-list="imageUrls" :initial-index="idx" />
              <div class="image-thumb-actions">
                <el-icon class="remove-btn" @click="removeImage(idx)"><CircleClose /></el-icon>
              </div>
            </div>
            <el-upload
              class="image-uploader"
              :http-request="handleImageUpload"
              :show-file-list="false"
            >
              <div class="upload-placeholder">
                <el-icon class="upload-icon"><Plus /></el-icon>
                <span>上传图片</span>
              </div>
            </el-upload>
          </div>
          <div class="upload-tip">可上传多张图片，支持 jpg/png/webp，单张不超过 10MB</div>
        </el-form-item>

        <el-form-item label="设施服务"><el-input v-model="facilitiesText" placeholder="逗号分隔，如：WiFi,空调,电视" /></el-form-item>
        <el-form-item label="入住时间">
          <el-time-picker v-model="form.checkInTime" format="HH:mm" value-format="HH:mm" placeholder="选择入住时间" />
        </el-form-item>
        <el-form-item label="退房时间">
          <el-time-picker v-model="form.checkOutTime" format="HH:mm" value-format="HH:mm" placeholder="选择退房时间" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="saving" @click="handleSave">
            {{ isEdit ? '保存修改' : '添加民宿' }}
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Plus, Delete, CircleClose } from '@element-plus/icons-vue'
import { addHomestay, updateHomestay, getHomestayDetail } from '@/api/homestay'
import { uploadFile } from '@/api/common'

const route = useRoute()
const router = useRouter()
const isEdit = ref(false)
const saving = ref(false)
const imageUrls = ref([])
const facilitiesText = ref('')

const form = reactive({
  name: '', province: '', city: '', district: '', address: '',
  description: '', coverImage: '', checkInTime: '14:00', checkOutTime: '12:00'
})

const rules = { name: [{ required: true, message: '请输入民宿名称', trigger: 'blur' }] }

// ---- 上传前校验 ----
const beforeUpload = () => {
  return true
}

// ---- 封面上传 ----
const handleCoverUpload = async (options) => {
  const fd = new FormData()
  fd.append('file', options.file)
  try {
    const res = await uploadFile(fd)
    form.coverImage = res.data
    ElMessage.success('封面上传成功')
  } catch {
    // request.js 拦截器已弹窗提示，此处不再重复
  }
}

// ---- 多图上传 ----
const handleImageUpload = async (options) => {
  const fd = new FormData()
  fd.append('file', options.file)
  try {
    const res = await uploadFile(fd)
    imageUrls.value.push(res.data)
    ElMessage.success('图片上传成功')
  } catch {
    // request.js 拦截器已弹窗提示，此处不再重复
  }
}

const removeImage = (idx) => {
  imageUrls.value.splice(idx, 1)
}

// ---- 保存 ----
const handleSave = async () => {
  if (!form.name.trim()) { ElMessage.warning('请输入民宿名称'); return }

  const data = {
    ...form,
    images: imageUrls.value.join(','),
    facilities: facilitiesText.value
  }

  saving.value = true
  try {
    if (isEdit.value) {
      await updateHomestay(route.params.id, data)
    } else {
      const res = await addHomestay(data)
      ElMessage.success(res.message || '提交成功，请等待审核')
    }
    router.push('/host/homestays')
  } catch (e) {
    ElMessage.error(e?.message || '操作失败，请重试')
  } finally { saving.value = false }
}

// ---- 编辑模式回填 ----
onMounted(async () => {
  if (route.params.id) {
    isEdit.value = true
    const res = await getHomestayDetail(route.params.id)
    const d = res.data
    Object.assign(form, d)
    if (d.images) {
      if (typeof d.images === 'string') {
        imageUrls.value = d.images.split(',').filter(Boolean)
      } else if (Array.isArray(d.images)) {
        imageUrls.value = d.images
      }
    }
    if (d.facilities) {
      facilitiesText.value = Array.isArray(d.facilities) ? d.facilities.join(',') : d.facilities
    }
  }
})
</script>

<style lang="scss" scoped>
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; }
.form-main { max-width: 800px; }

// 封面上传
.cover-area { display: flex; flex-direction: column; gap: 8px; }
.cover-preview-wrap {
  position: relative; display: inline-block;
  .cover-preview { width: 200px; height: 150px; border-radius: 8px; display: block; }
  .cover-actions { margin-top: 6px; }
}
.cover-uploader { display: inline-block; }

// 多图上传
.images-grid {
  display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-start;
}
.image-thumb {
  position: relative; width: 120px; height: 120px; border-radius: 8px; overflow: hidden;
  :deep(.el-image) { width: 100%; height: 100%; }
  .image-thumb-actions {
    position: absolute; top: 4px; right: 4px; display: none;
    .remove-btn { font-size: 20px; color: #fff; background: rgba(0,0,0,.45); border-radius: 50%; cursor: pointer; padding: 2px; }
  }
  &:hover .image-thumb-actions { display: block; }
}

// 上传占位
.upload-placeholder {
  width: 120px; height: 120px; border: 1px dashed #d9d9d9; border-radius: 8px;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 6px; cursor: pointer; color: #8c939d; font-size: 12px;
  transition: border-color .2s, color .2s;
  &:hover { border-color: #409eff; color: #409eff; }
  .upload-icon { font-size: 24px; }
}

.upload-tip { font-size: 12px; color: #909399; margin-top: 4px; }
</style>
