package com.homestay.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Slf4j
@Component
@RequiredArgsConstructor
public class DatabaseMigration implements ApplicationRunner {

    private final DataSource dataSource;
    private final PasswordEncoder passwordEncoder;

    private static final List<String> POSITIVE_COMMENTS = Arrays.asList(
        "房间非常干净整洁，床品舒适，睡得很香！",
        "装修风格很喜欢，拍照超出片，推荐！",
        "空间比想象中大，设施齐全，性价比很高。",
        "风景绝佳，落地窗视野开阔，完美的入住体验。",
        "房东热情周到，提供了很多当地旅游建议。",
        "卫生条件一流，细节做得很到位，会再来。",
        "交通便利，周边配套齐全，出行很方便。",
        "安静舒适，隔音效果好，适合放松休息。",
        "房间布置很有格调，处处体现用心。",
        "物超所值，下次来还会选择这里。",
        "入住体验超出预期，各方面都非常满意。",
        "环境优美，空气清新，度假首选。",
        "很有特色的房型，留下了美好的回忆。",
        "设施完善，热水充足，WiFi速度快。",
        "位置绝佳，步行可达景点，非常方便。"
    );

    private final Random random = new Random();

    @Override
    public void run(ApplicationArguments args) {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // ── 系统配置表 ──
            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS `system_config` (" +
                    "`id` BIGINT AUTO_INCREMENT PRIMARY KEY," +
                    "`config_key` VARCHAR(100) NOT NULL COMMENT '配置键'," +
                    "`config_value` TEXT COMMENT '配置值'," +
                    "`description` VARCHAR(200) COMMENT '描述'," +
                    "`category` VARCHAR(50) DEFAULT 'general' COMMENT '分类'," +
                    "`create_time` DATETIME DEFAULT CURRENT_TIMESTAMP," +
                    "`update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP," +
                    "UNIQUE KEY `uk_config_key` (`config_key`)" +
                    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置'");
                log.info("Database migration: system_config table created.");
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains("already exists")) {
                    log.info("Database migration: system_config table already exists.");
                } else {
                    log.warn("Database migration system_config error: {}", e.getMessage());
                }
            }

            // 插入默认配置
            String[][] defaultConfigs = {
                {"site_name", "民宿预约管理系统", "站点名称", "general"},
                {"site_description", "专业的民宿在线预约平台", "站点描述", "general"},
                {"contact_email", "admin@homestay.com", "联系邮箱", "general"},
                {"contact_phone", "400-000-0000", "联系电话", "general"},
                {"commission_rate", "10", "平台佣金比例(%)", "business"},
                {"min_withdraw_amount", "100", "最低提现金额(元)", "business"},
                {"auto_confirm_hours", "24", "自动确认订单(小时)", "business"},
                {"max_homestay_images", "9", "民宿最大图片数", "business"}
            };
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT IGNORE INTO `system_config` (`config_key`, `config_value`, `description`, `category`) VALUES (?, ?, ?, ?)")) {
                for (String[] cfg : defaultConfigs) {
                    ps.setString(1, cfg[0]);
                    ps.setString(2, cfg[1]);
                    ps.setString(3, cfg[2]);
                    ps.setString(4, cfg[3]);
                    ps.addBatch();
                }
                int[] r = ps.executeBatch();
                log.info("Database migration: inserted {} default system configs.", r.length);
            } catch (Exception e) {
                log.warn("Database migration default configs error: {}", e.getMessage());
            }

            // ── 操作日志表 ──
            try {
                stmt.execute("CREATE TABLE IF NOT EXISTS `operation_log` (" +
                    "`id` BIGINT AUTO_INCREMENT PRIMARY KEY," +
                    "`user_id` BIGINT COMMENT '操作用户ID'," +
                    "`username` VARCHAR(50) COMMENT '用户名'," +
                    "`operation` VARCHAR(200) COMMENT '操作描述'," +
                    "`method` VARCHAR(200) COMMENT '请求方法'," +
                    "`params` TEXT COMMENT '请求参数'," +
                    "`ip` VARCHAR(50) COMMENT 'IP地址'," +
                    "`duration` BIGINT DEFAULT 0 COMMENT '耗时(ms)'," +
                    "`success` TINYINT(1) DEFAULT 1 COMMENT '是否成功'," +
                    "`create_time` DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志'");
                log.info("Database migration: operation_log table created.");
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains("already exists")) {
                    log.info("Database migration: operation_log table already exists.");
                } else {
                    log.warn("Database migration operation_log error: {}", e.getMessage());
                }
            }

            // ── 扩展 role 字段长度（支持逗号分隔多角色） ──
            try {
                stmt.execute("ALTER TABLE `user` MODIFY COLUMN `role` VARCHAR(100) DEFAULT 'user' COMMENT '角色(逗号分隔)'");
                log.info("Database migration: user.role column expanded to VARCHAR(100).");
            } catch (Exception e) {
                log.warn("Database migration user.role alter error: {}", e.getMessage());
            }

            // ── 确保管理员用户拥有 admin 角色 ──
            try {
                ResultSet adminRs = stmt.executeQuery(
                    "SELECT id, role FROM `user` WHERE username = 'admin'");
                if (adminRs.next()) {
                    String currentRole = adminRs.getString("role");
                    long adminId = adminRs.getLong("id");
                    if (currentRole == null || !currentRole.contains("admin")) {
                        String newRole = (currentRole == null || currentRole.isEmpty())
                            ? "admin" : currentRole + ",admin";
                        PreparedStatement updatePs = conn.prepareStatement(
                            "UPDATE `user` SET role = ? WHERE id = ?");
                        updatePs.setString(1, newRole);
                        updatePs.setLong(2, adminId);
                        updatePs.executeUpdate();
                        updatePs.close();
                        log.info("Database migration: admin user role updated to '{}'.", newRole);
                    } else {
                        log.info("Database migration: admin user already has admin role.");
                    }
                }
                adminRs.close();
            } catch (Exception e) {
                log.warn("Database migration admin role fix error: {}", e.getMessage());
            }

            // ── 重置管理员密码为 123456 ──
            try {
                ResultSet pwdRs = stmt.executeQuery(
                    "SELECT id, password FROM `user` WHERE username = 'admin'");
                if (pwdRs.next()) {
                    String currentPwd = pwdRs.getString("password");
                    long adminId = pwdRs.getLong("id");
                    String correctHash = passwordEncoder.encode("123456");
                    if (!passwordEncoder.matches("123456", currentPwd)) {
                        PreparedStatement pwdPs = conn.prepareStatement(
                            "UPDATE `user` SET password = ? WHERE id = ?");
                        pwdPs.setString(1, correctHash);
                        pwdPs.setLong(2, adminId);
                        pwdPs.executeUpdate();
                        pwdPs.close();
                        log.info("Database migration: admin password reset to 123456.");
                    } else {
                        log.info("Database migration: admin password is correct.");
                    }
                }
                pwdRs.close();
            } catch (Exception e) {
                log.warn("Database migration admin password reset error: {}", e.getMessage());
            }

            // Add room_id column
            try {
                stmt.execute("ALTER TABLE review ADD COLUMN room_id BIGINT DEFAULT NULL COMMENT '房型ID' AFTER homestay_id");
                log.info("Database migration: room_id column added.");
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains("Duplicate column")) {
                    log.info("Database migration: room_id column already exists.");
                } else {
                    log.warn("Database migration column error: {}", e.getMessage());
                }
            }

            // Find rooms that have no reviews yet
            ResultSet roomRs = stmt.executeQuery(
                "SELECT r.id, r.name, r.homestay_id FROM room r WHERE r.id NOT IN " +
                "(SELECT DISTINCT room_id FROM review WHERE room_id IS NOT NULL)");
            List<Object[]> roomsWithoutReview = new ArrayList<>();
            while (roomRs.next()) {
                roomsWithoutReview.add(new Object[]{
                    roomRs.getLong("id"), roomRs.getLong("homestay_id"), roomRs.getString("name")
                });
            }
            roomRs.close();

            if (roomsWithoutReview.isEmpty()) {
                log.info("Database migration: all rooms already have reviews.");
            } else {
                // Insert 2-3 reviews for each room without reviews
                String insertSql = "INSERT INTO review (user_id, order_id, homestay_id, room_id, rating, cleanliness, location, service, facilities_score, content, status, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)";
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm");
                LocalDateTime baseTime = LocalDateTime.of(2026, 5, 1, 10, 0);
                int orderNo = 200;

                try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
                    for (int i = 0; i < roomsWithoutReview.size(); i++) {
                        Object[] room = roomsWithoutReview.get(i);
                        Long roomId = (Long) room[0];
                        Long homestayId = (Long) room[1];

                        // 2-3 reviews per room
                        int reviewsPerRoom = 2 + random.nextInt(2);
                        for (int j = 0; j < reviewsPerRoom; j++) {
                            int userId = 8 + ((i + j) % 5);      // user 8-12
                            int rating = 4 + random.nextInt(2);  // 4 or 5
                            int clean = 4 + random.nextInt(2);
                            int loc = 4 + random.nextInt(2);
                            int svc = 4 + random.nextInt(2);
                            int fac = 4 + random.nextInt(2);
                            String comment = POSITIVE_COMMENTS.get((i + j) % POSITIVE_COMMENTS.size());
                            String createTime = fmt.format(baseTime.minus(i * 3L, ChronoUnit.DAYS)
                                    .minus(j * 5, ChronoUnit.DAYS).minus(random.nextInt(12), ChronoUnit.HOURS));

                            ps.setInt(1, userId);
                            ps.setInt(2, orderNo + i * 10 + j);
                            ps.setLong(3, homestayId);
                            ps.setLong(4, roomId);
                            ps.setInt(5, rating);
                            ps.setInt(6, clean);
                            ps.setInt(7, loc);
                            ps.setInt(8, svc);
                            ps.setInt(9, fac);
                            ps.setString(10, comment);
                            ps.setString(11, createTime);
                            ps.addBatch();
                        }
                    }
                    int[] results = ps.executeBatch();
                    log.info("Database migration: inserted {} room reviews.", results.length);
                }
            }

            // Update all homestay review_count and rating based on actual review data
            log.info("Database migration: refreshing homestay review counts & ratings...");
            ResultSet hsRs = stmt.executeQuery("SELECT id FROM homestay");
            List<Long> homestayIds = new ArrayList<>();
            while (hsRs.next()) {
                homestayIds.add(hsRs.getLong("id"));
            }
            hsRs.close();

            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE homestay SET review_count = ?, rating = ? WHERE id = ?")) {
                for (Long hsId : homestayIds) {
                    PreparedStatement cntPs = conn.prepareStatement(
                            "SELECT COUNT(*) FROM review WHERE homestay_id = ? AND status = 1");
                    cntPs.setLong(1, hsId);
                    ResultSet cntRs = cntPs.executeQuery();
                    int count = cntRs.next() ? cntRs.getInt(1) : 0;
                    cntRs.close();
                    cntPs.close();

                    PreparedStatement avgPs = conn.prepareStatement(
                            "SELECT AVG(rating) FROM review WHERE homestay_id = ? AND status = 1");
                    avgPs.setLong(1, hsId);
                    ResultSet avgRs = avgPs.executeQuery();
                    double avg = avgRs.next() ? avgRs.getDouble(1) : 5.0;
                    avgRs.close();
                    avgPs.close();
                    double rating = count > 0 ? Math.round(avg * 10.0) / 10.0 : 5.0;

                    ps.setInt(1, count);
                    ps.setDouble(2, rating);
                    ps.setLong(3, hsId);
                    ps.addBatch();
                }
                int[] updated = ps.executeBatch();
                log.info("Database migration: refreshed {} homestay ratings/counts.", updated.length);
            }
        } catch (Exception e) {
            log.warn("Database migration error: {}", e.getMessage());
        }
    }
}
