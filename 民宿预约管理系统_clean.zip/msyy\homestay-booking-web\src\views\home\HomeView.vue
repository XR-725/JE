<template>
  <div class="home-page">
    <!-- ── Hero 横幅 ── -->
    <section class="hero-section">
      <div class="hero-bg">
        <div class="hero-dot-pattern"></div>
        <div class="hero-gradient-orb hero-orb--1"></div>
        <div class="hero-gradient-orb hero-orb--2"></div>
      </div>
      <div class="page-container hero-content">
        <div class="hero-text">
          <h1 class="hero-title">
            发现你的<span class="hero-highlight">理想民宿</span>
          </h1>
          <p class="hero-subtitle">
            精选全国优质民宿，从山水田园到都市雅居，总有一处让你心动
          </p>
          <div class="hero-actions">
            <el-button class="hero-search-btn" size="large" @click="$router.push('/home/homestay/list')">
              <el-icon><Search /></el-icon>
              探索民宿
            </el-button>
          </div>
          <div class="hero-stats">
            <div class="hero-stat">
              <span class="stat-num">{{ stats.homestayCount }}+</span>
              <span class="stat-label">精品民宿</span>
            </div>
            <div class="hero-divider"></div>
            <div class="hero-stat">
              <span class="stat-num">{{ stats.cityCount }}+</span>
              <span class="stat-label">热门城市</span>
            </div>
            <div class="hero-divider"></div>
            <div class="hero-stat">
              <span class="stat-num">{{ stats.orderCount }}+</span>
              <span class="stat-label">满意住客</span>
            </div>
          </div>
        </div>
        <div class="hero-visual">
          <div class="hero-card hero-card--1">
            <div class="mini-card-img skeleton-bg" style="background:linear-gradient(135deg,#FF6B35,#FF8C60)"></div>
            <div class="mini-card-body">
              <div class="skeleton skeleton-text" style="width:70%"></div>
              <div class="skeleton skeleton-text" style="width:40%;margin-top:6px"></div>
            </div>
          </div>
          <div class="hero-card hero-card--2">
            <div class="mini-card-img skeleton-bg" style="background:linear-gradient(135deg,#2D5B63,#4A8B94)"></div>
            <div class="mini-card-body">
              <div class="skeleton skeleton-text" style="width:60%"></div>
              <div class="skeleton skeleton-text" style="width:35%;margin-top:6px"></div>
            </div>
          </div>
          <div class="hero-card hero-card--3">
            <div class="mini-card-img skeleton-bg" style="background:linear-gradient(135deg,#F5A623,#FCC870)"></div>
            <div class="mini-card-body">
              <div class="skeleton skeleton-text" style="width:55%"></div>
              <div class="skeleton skeleton-text" style="width:30%;margin-top:6px"></div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── 轮播Banner (如有) ── -->
    <section v-if="banners.length" class="banner-section">
      <div class="page-container">
        <el-carousel :interval="5000" arrow="always" height="320px" class="banner-carousel" indicator-position="outside">
          <el-carousel-item v-for="b in banners" :key="b.id">
            <div class="banner-item" @click="b.linkUrl && $router.push(b.linkUrl)">
              <el-image :src="b.imageUrl" fit="cover" style="width:100%;height:100%" class="banner-img">
                <template #error>
                  <div class="banner-placeholder">
                    <el-icon :size="48"><Picture /></el-icon>
                  </div>
                </template>
              </el-image>
              <div class="banner-overlay">
                <h3 class="banner-title">{{ b.title }}</h3>
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </div>
    </section>

    <!-- ── 热门推荐 ── -->
    <section class="hot-section">
      <div class="page-container">
        <div class="section-header">
          <h2>热门推荐</h2>
          <router-link to="/home/homestay/list?sortBy=rating" class="more-link">
            查看更多 <el-icon><ArrowRight /></el-icon>
          </router-link>
        </div>

        <!-- 加载骨架屏 -->
        <el-row :gutter="20" v-if="loading">
          <el-col v-for="n in 8" :key="n" :xs="24" :sm="12" :md="8" :lg="6">
            <div class="card-skeleton">
              <div class="skeleton card-skeleton-img"></div>
              <div class="card-skeleton-body">
                <div class="skeleton skeleton-text" style="width:75%"></div>
                <div class="skeleton skeleton-text" style="width:50%;margin-top:8px"></div>
                <div class="skeleton skeleton-text" style="width:40%;margin-top:8px"></div>
              </div>
            </div>
          </el-col>
        </el-row>

        <!-- 卡片网格 -->
        <el-row :gutter="20" v-else-if="hotList.length">
          <el-col v-for="item in hotList" :key="item.id" :xs="24" :sm="12" :md="8" :lg="6">
            <HomestayCard :homestay="item" :is-favorited="!!favoriteStatus[item.id]" />
          </el-col>
        </el-row>

        <!-- 空状态 -->
        <div v-else class="empty-container">
          <div class="empty-icon">
            <el-icon :size="64"><Picture /></el-icon>
          </div>
          <p class="empty-text">暂无推荐民宿，敬请期待</p>
          <el-button type="primary" @click="$router.push('/home/homestay/list')">浏览全部民宿</el-button>
        </div>
      </div>
    </section>

  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { getHotHomestays } from '@/api/homestay'
import { checkFavorite } from '@/api/homestay'
import { getBanners, getStats } from '@/api/common'
import { useUserStore } from '@/stores/user'
import HomestayCard from '@/components/HomestayCard.vue'

const router = useRouter()
const userStore = useUserStore()
const banners = ref([])
const hotList = ref([])
const favoriteStatus = ref({})
const loading = ref(true)

const stats = reactive({
  homestayCount: 0,
  cityCount: 0,
  orderCount: 0
})

const checkFavoritesBatch = async (items) => {
  if (!userStore.isLoggedIn || !items.length) return
  for (const item of items) {
    try {
      const res = await checkFavorite(item.id)
      favoriteStatus.value[item.id] = res.data || false
    } catch (e) { /* ignore */ }
  }
}

onMounted(async () => {
  try {
    const [bannerRes, hotRes, statsRes] = await Promise.all([
      getBanners(),
      getHotHomestays(8),
      getStats()
    ])
    banners.value = bannerRes.data || []
    hotList.value = hotRes.data || []
    if (statsRes.data) {
      stats.homestayCount = statsRes.data.homestayCount || 0
      stats.cityCount = statsRes.data.cityCount || 0
      stats.orderCount = statsRes.data.orderCount || 0
    }
    // Batch check favorite status after list loaded
    await checkFavoritesBatch(hotList.value)
  } catch (e) {
    // 静默降级
  } finally {
    loading.value = false
  }
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

// ── Hero 区域 ──
.hero-section {
  position: relative;
  overflow: hidden;
  background: $color-surface;
  min-height: 480px;
  display: flex;
  align-items: center;
}

.hero-bg {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.hero-dot-pattern {
  position: absolute;
  inset: 0;
  background-image: radial-gradient($color-border 1px, transparent 1px);
  background-size: 32px 32px;
  opacity: 0.4;
}

.hero-gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.15;
}

.hero-orb--1 {
  width: 400px;
  height: 400px;
  background: $color-primary;
  top: -100px;
  right: -100px;
}

.hero-orb--2 {
  width: 300px;
  height: 300px;
  background: $color-secondary;
  bottom: -80px;
  left: -80px;
}

.hero-content {
  display: flex;
  align-items: center;
  gap: $spacing-4xl;
  position: relative;
  z-index: 1;
  padding-top: $spacing-5xl;
  padding-bottom: $spacing-5xl;
}

.hero-text {
  flex: 1;
}

.hero-title {
  font-size: 44px;
  font-weight: $font-weight-bold;
  color: $color-text-primary;
  line-height: 1.2;
  margin: 0 0 $spacing-lg;

  .hero-highlight {
    background: linear-gradient(135deg, $color-primary, $color-primary-dark);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    position: relative;

    &::after {
      content: '';
      position: absolute;
      bottom: 2px;
      left: 0;
      right: 0;
      height: 8px;
      background: $color-primary-lighter;
      border-radius: $radius-full;
      z-index: -1;
    }
  }
}

.hero-subtitle {
  font-size: $font-size-lg;
  color: $color-text-secondary;
  line-height: $line-height-relaxed;
  margin: 0 0 $spacing-2xl;
  max-width: 440px;
}

.hero-actions {
  display: flex;
  gap: $spacing-md;
  margin-bottom: $spacing-3xl;

  .hero-search-btn {
    height: 48px;
    padding: 0 28px;
    font-size: $font-size-md;
    font-weight: $font-weight-semibold;
    border-radius: $radius-base;
    background: linear-gradient(135deg, $color-primary, $color-primary-light);
    border: none;
    color: #fff;

    &:hover {
      background: linear-gradient(135deg, $color-primary-dark, $color-primary);
      transform: translateY(-1px);
      box-shadow: 0 6px 20px rgba($color-primary, 0.35);
    }
  }
}

.hero-stats {
  display: flex;
  align-items: center;
  gap: $spacing-xl;
}

.hero-stat {
  text-align: center;

  .stat-num {
    display: block;
    font-size: $font-size-3xl;
    font-weight: $font-weight-bold;
    color: $color-text-primary;
  }

  .stat-label {
    font-size: $font-size-sm;
    color: $color-text-secondary;
    margin-top: 2px;
  }
}

.hero-divider {
  width: 1px;
  height: 32px;
  background: $color-border;
}

// ── Hero 视觉卡片 ──
.hero-visual {
  flex: 0 0 380px;
  position: relative;
  height: 340px;
  display: none;

  @media (min-width: 1024px) { display: block; }
}

.hero-card {
  position: absolute;
  background: $color-surface;
  border-radius: $radius-lg;
  box-shadow: $shadow-md;
  overflow: hidden;
  width: 200px;
  animation: floatCard 6s ease-in-out infinite;

  .mini-card-img {
    height: 100px;
  }

  .mini-card-body {
    padding: 12px;
  }

  .skeleton-text {
    height: 12px;
    border-radius: 4px;
  }

  &--1 {
    top: 0;
    left: 20px;
    animation-delay: 0s;
    z-index: 3;
  }

  &--2 {
    top: 60px;
    right: 0;
    animation-delay: -2s;
    z-index: 2;
  }

  &--3 {
    bottom: 0;
    left: 80px;
    animation-delay: -4s;
    z-index: 1;
  }
}

@keyframes floatCard {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-12px); }
}

// ── Banner ──
.banner-section {
  padding-bottom: $spacing-xl;
}

.banner-carousel {
  border-radius: $radius-lg;
  overflow: hidden;
}

.banner-item {
  position: relative;
  height: 100%;
  cursor: pointer;

  .banner-img {
    border-radius: $radius-lg;
  }

  .banner-placeholder {
    width: 100%;
    height: 100%;
    background: $color-bg-alt;
    display: flex;
    align-items: center;
    justify-content: center;
    color: $color-text-placeholder;
  }

  .banner-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 60px 32px 24px;
    background: linear-gradient(transparent, rgba(0,0,0,0.5));
  }

  .banner-title {
    color: #fff;
    font-size: $font-size-xl;
    font-weight: $font-weight-bold;
    text-shadow: 0 2px 8px rgba(0,0,0,0.4);
  }
}

// ── 热门推荐 ──
.hot-section {
  padding: $spacing-2xl 0;
}

.card-skeleton {
  background: $color-surface;
  border-radius: $radius-md;
  overflow: hidden;
  margin-bottom: $spacing-xl;

  .card-skeleton-img {
    height: 200px;
    border-radius: 0;
  }

  .card-skeleton-body {
    padding: $spacing-base;
  }

  .skeleton-text {
    height: 14px;
    border-radius: 4px;
  }
}

// ── 响应式 ──
@media (max-width: 1024px) {
  .hero-title { font-size: 32px; }
}

@media (max-width: 768px) {
  .hero-content { flex-direction: column; padding: $spacing-2xl 0; }
  .hero-title { font-size: 28px; }
  .hero-actions { flex-direction: column; }

  .hero-stats {
    justify-content: center;
    gap: $spacing-lg;
  }
}

@media (max-width: 480px) {
  .hero-title { font-size: 24px; }
  .hero-stats { flex-wrap: wrap; }
  .hero-divider:nth-child(2) { display: none; }
}
</style>
