<template>
  <PageContainer title="数据统计" subtitle="平台运营数据深度分析">
    <div v-loading="loading">
      <!-- 月度营收趋势 -->
      <el-card class="chart-card">
        <template #header><span class="card-title">月度营收趋势</span></template>
        <div class="trend-chart">
          <div v-for="item in stats.monthlyTrend" :key="item.month" class="trend-bar-group">
            <div class="trend-bar-wrap">
              <div class="trend-bar" :style="{ height: barHeight(item.revenue) + '%' }">
                <span class="trend-value">¥{{ formatAmount(item.revenue) }}</span>
              </div>
            </div>
            <span class="trend-month">{{ item.month }}</span>
            <span class="trend-count">{{ item.orderCount }}单</span>
          </div>
        </div>
      </el-card>

      <div class="stats-row">
        <!-- 城市分布 -->
        <el-card class="chart-card">
          <template #header><span class="card-title">民宿城市分布 TOP10</span></template>
          <div class="city-list">
            <div v-for="(item, idx) in stats.cityDistribution" :key="item.city" class="city-row">
              <span class="city-rank" :class="{ 'top3': idx < 3 }">{{ idx + 1 }}</span>
              <span class="city-name">{{ item.city }}</span>
              <div class="city-bar-wrap">
                <div class="city-bar" :style="{ width: cityWidth(item.count) + '%' }"></div>
              </div>
              <span class="city-count">{{ item.count }}家</span>
            </div>
            <el-empty v-if="!stats.cityDistribution?.length" description="暂无数据" :image-size="60" />
          </div>
        </el-card>

        <!-- 房东排行 -->
        <el-card class="chart-card">
          <template #header><span class="card-title">房东收入排行 TOP10</span></template>
          <div class="host-list">
            <div v-for="(item, idx) in stats.hostRanking" :key="item.hostId" class="host-row">
              <span class="host-rank" :class="{ 'top3': idx < 3 }">{{ idx + 1 }}</span>
              <el-avatar :size="28" class="host-avatar">{{ item.hostName?.charAt(0) }}</el-avatar>
              <span class="host-name">{{ item.hostName }}</span>
              <span class="host-revenue">¥{{ formatAmount(item.revenue) }}</span>
            </div>
            <el-empty v-if="!stats.hostRanking?.length" description="暂无数据" :image-size="60" />
          </div>
        </el-card>
      </div>
    </div>
  </PageContainer>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getStatistics } from '@/api/admin'
import PageContainer from '@/components/PageContainer.vue'

const stats = ref({})
const loading = ref(false)

const maxRevenue = ref(1)
const maxCityCount = ref(1)

const formatAmount = (val) => {
  if (!val) return '0'
  const n = Number(val)
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return n.toFixed(0)
}

const barHeight = (revenue) => {
  const r = Number(revenue || 0)
  return Math.max(5, (r / maxRevenue.value) * 100)
}

const cityWidth = (count) => {
  return Math.max(5, (count / maxCityCount.value) * 100)
}

onMounted(async () => {
  loading.value = true
  try {
    const res = await getStatistics()
    stats.value = res.data || {}
    if (stats.value.monthlyTrend?.length) {
      maxRevenue.value = Math.max(...stats.value.monthlyTrend.map(i => Number(i.revenue || 0)), 1)
    }
    if (stats.value.cityDistribution?.length) {
      maxCityCount.value = Math.max(...stats.value.cityDistribution.map(i => i.count), 1)
    }
  } finally { loading.value = false }
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.card-title { font-weight: $font-weight-semibold; font-size: $font-size-md; }

.chart-card { margin-bottom: 20px; }

// ── 月度趋势 ──
.trend-chart {
  display: flex; align-items: flex-end; gap: 16px;
  height: 240px; padding: 16px 0;
}

.trend-bar-group {
  flex: 1; display: flex; flex-direction: column; align-items: center;
  height: 100%;
}

.trend-bar-wrap {
  flex: 1; width: 100%; display: flex; align-items: flex-end; justify-content: center;
}

.trend-bar {
  width: 60%; min-height: 4px;
  background: linear-gradient(180deg, $color-primary, $color-primary-light);
  border-radius: 4px 4px 0 0; transition: height 0.6s ease;
  position: relative;
}

.trend-value {
  position: absolute; top: -20px; left: 50%; transform: translateX(-50%);
  font-size: 11px; color: $color-text-secondary; white-space: nowrap;
}

.trend-month { font-size: 12px; color: $color-text-regular; margin-top: 6px; }
.trend-count { font-size: 11px; color: $color-text-secondary; margin-top: 2px; }

// ── 统计双列 ──
.stats-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }

// ── 城市分布 ──
.city-list { display: flex; flex-direction: column; gap: 10px; }
.city-row { display: flex; align-items: center; gap: 10px; }
.city-rank {
  width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 600; background: $color-bg-alt; color: $color-text-secondary; flex-shrink: 0;
  &.top3 { background: $color-primary; color: #fff; }
}
.city-name { width: 60px; font-size: 13px; color: $color-text-primary; flex-shrink: 0; }
.city-bar-wrap { flex: 1; height: 8px; background: $color-bg-alt; border-radius: 4px; overflow: hidden; }
.city-bar { height: 100%; background: linear-gradient(90deg, $color-primary-light, $color-primary); border-radius: 4px; transition: width 0.6s ease; }
.city-count { width: 50px; font-size: 13px; color: $color-text-secondary; text-align: right; flex-shrink: 0; }

// ── 房东排行 ──
.host-list { display: flex; flex-direction: column; gap: 10px; }
.host-row { display: flex; align-items: center; gap: 10px; }
.host-rank {
  width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 600; background: $color-bg-alt; color: $color-text-secondary; flex-shrink: 0;
  &.top3 { background: $color-warning; color: #fff; }
}
.host-avatar { flex-shrink: 0; }
.host-name { flex: 1; font-size: 13px; color: $color-text-primary; }
.host-revenue { font-size: 13px; color: $color-primary; font-weight: $font-weight-semibold; }

// 响应式
@media (max-width: 768px) {
  .stats-row { grid-template-columns: 1fr; }
}
</style>
