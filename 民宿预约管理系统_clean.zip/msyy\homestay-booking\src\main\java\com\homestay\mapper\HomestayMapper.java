package com.homestay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.homestay.entity.Homestay;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface HomestayMapper extends BaseMapper<Homestay> {
}
