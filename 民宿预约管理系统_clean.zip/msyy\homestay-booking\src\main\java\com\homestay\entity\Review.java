package com.homestay.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("review")
public class Review {
    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;
    private Long orderId;
    private Long homestayId;
    private Long roomId;
    private Integer rating;
    private Integer cleanliness;
    private Integer location;
    private Integer service;
    private Integer facilitiesScore;
    private String content;
    private String images;
    private String reply;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime replyTime;

    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;
}
