<template>
  <PageContainer title="系统配置" subtitle="管理平台运行参数">
    <template #toolbar>
      <el-select v-model="categoryFilter" placeholder="配置分类" clearable style="width:150px" @change="fetchData">
        <el-option label="全部分类" value="" />
        <el-option label="通用" value="general" />
        <el-option label="业务" value="business" />
      </el-select>
    </template>

    <el-card v-loading="loading">
      <el-table :data="filteredList" border stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="configKey" label="配置键" width="200">
          <template #default="{ row }">
            <code class="config-key">{{ row.configKey }}</code>
          </template>
        </el-table-column>
        <el-table-column prop="configValue" label="配置值" min-width="200">
          <template #default="{ row }">
            <template v-if="editingId === row.id">
              <el-input v-model="editValue" size="small" style="width:100%" @keyup.enter="saveConfig(row)" />
            </template>
            <template v-else>
              <span class="config-value">{{ row.configValue }}</span>
            </template>
          </template>
        </el-table-column>
        <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
        <el-table-column prop="category" label="分类" width="100">
          <template #default="{ row }">
            <el-tag :type="row.category === 'business' ? 'warning' : ''" size="small">
              {{ row.category === 'business' ? '业务' : '通用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <template v-if="editingId === row.id">
              <el-button type="success" link size="small" @click="saveConfig(row)">保存</el-button>
              <el-button link size="small" @click="editingId = null">取消</el-button>
            </template>
            <template v-else>
              <el-button type="primary" link size="small" @click="startEdit(row)">编辑</el-button>
            </template>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </PageContainer>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getConfigList, updateConfig } from '@/api/admin'
import PageContainer from '@/components/PageContainer.vue'

const list = ref([])
const loading = ref(false)
const categoryFilter = ref('')
const editingId = ref(null)
const editValue = ref('')

const filteredList = computed(() => {
  if (!categoryFilter.value) return list.value
  return list.value.filter(i => i.category === categoryFilter.value)
})

const fetchData = async () => {
  loading.value = true
  try {
    const res = await getConfigList({ category: categoryFilter.value || undefined })
    list.value = res.data || []
  } finally { loading.value = false }
}

const startEdit = (row) => {
  editingId.value = row.id
  editValue.value = row.configValue
}

const saveConfig = async (row) => {
  await updateConfig(row.id, { configValue: editValue.value })
  ElMessage.success('配置更新成功')
  editingId.value = null
  fetchData()
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.config-key {
  background: #f5f7fa; padding: 2px 6px; border-radius: 4px;
  font-size: 13px; color: #606266; font-family: monospace;
}
.config-value {
  font-size: 14px; color: #303133;
}
</style>
