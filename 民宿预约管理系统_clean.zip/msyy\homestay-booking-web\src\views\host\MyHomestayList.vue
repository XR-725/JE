<template>
  <div class="host-page">
    <div class="page-header">
      <h3>我的民宿</h3>
      <el-button type="primary" @click="$router.push('/host/homestay/add')">添加民宿</el-button>
    </div>
    <el-card>
      <el-table :data="list" border stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="name" label="名称" min-width="180" />
        <el-table-column label="封面" width="100">
          <template #default="{ row }"><el-image :src="row.coverImage" fit="cover" style="width:80px;height:50px;border-radius:4px" /></template>
        </el-table-column>
        <el-table-column prop="city" label="城市" width="80" />
        <el-table-column prop="rating" label="评分" width="60" />
        <el-table-column prop="reviewCount" label="评论" width="60" />
        <el-table-column prop="status" label="状态" width="140">
          <template #default="{ row }">
            <div class="status-cell">
              <el-tag :type="row.status === 1 ? 'success' : row.status === 0 ? 'warning' : 'info'" size="small">{{ statMap[row.status] }}</el-tag>
              <span class="status-tip">{{ statDesc[row.status] || '' }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="260">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="$router.push(`/host/homestay/edit/${row.id}`)">编辑</el-button>
            <el-button type="success" link size="small" @click="$router.push(`/host/homestay/${row.id}/rooms`)">房型管理</el-button>
            <el-button type="warning" link size="small" @click="toggleStatus(row)">{{ row.status === 1 ? '下架' : '上架' }}</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getMyHomestays, deleteHomestay, updateHomestayStatus } from '@/api/homestay'

const list = ref([])
const statMap = { 0: '待审核', 1: '已上架', 2: '已下架' }
const statDesc = { 0: '提交成功，等待管理员审核中', 1: '民宿已在平台正常展示', 2: '民宿已从平台隐藏' }

const fetchData = async () => {
  const res = await getMyHomestays({ page: 1, size: 100 })
  list.value = res.data?.records || []
}

const toggleStatus = async (row) => {
  const newStatus = row.status === 1 ? 2 : 1
  await updateHomestayStatus(row.id, newStatus)
  ElMessage.success('操作成功')
  fetchData()
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm('确定删除该民宿？', '提示', { type: 'warning' })
    await deleteHomestay(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (e) {}
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; }
.status-cell { display: flex; flex-direction: column; gap: 4px; }
.status-tip { font-size: 11px; color: #909399; }
</style>
