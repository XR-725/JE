package com.homestay.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class HomestayVO {
    private Long id;
    private String name;
    private Long hostId;
    private String hostName;
    private String hostAvatar;
    private String province;
    private String city;
    private String district;
    private String address;
    private String description;
    private String coverImage;
    private List<String> images;
    private List<String> facilities;
    private String checkInTime;
    private String checkOutTime;
    private Integer status;
    private BigDecimal rating;
    private Integer reviewCount;
    private BigDecimal minPrice;
    private Integer roomCount;
    private List<RoomVO> rooms;
}
