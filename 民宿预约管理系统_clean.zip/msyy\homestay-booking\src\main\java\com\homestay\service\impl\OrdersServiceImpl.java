package com.homestay.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.common.BusinessException;
import com.homestay.dto.CreateOrderDto;
import com.homestay.entity.Homestay;
import com.homestay.entity.Orders;
import com.homestay.entity.Review;
import com.homestay.entity.Room;
import com.homestay.entity.User;
import com.homestay.mapper.HomestayMapper;
import com.homestay.mapper.OrdersMapper;
import com.homestay.mapper.ReviewMapper;
import com.homestay.mapper.RoomMapper;
import com.homestay.mapper.UserMapper;
import com.homestay.service.OrdersService;
import com.homestay.utils.SecurityUtils;
import com.homestay.vo.OrderVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrdersServiceImpl implements OrdersService {

    private final OrdersMapper ordersMapper;
    private final RoomMapper roomMapper;
    private final HomestayMapper homestayMapper;
    private final UserMapper userMapper;
    private final ReviewMapper reviewMapper;

    @Override
    public OrderVO createOrder(CreateOrderDto dto, Long userId) {
        LocalDate checkIn = dto.getCheckInDate();
        LocalDate checkOut = dto.getCheckOutDate();

        if (!checkOut.isAfter(checkIn)) {
            throw new BusinessException("退房日期必须晚于入住日期");
        }
        if (checkIn.isBefore(LocalDate.now())) {
            throw new BusinessException("入住日期不能早于今天");
        }

        Room room = roomMapper.selectById(dto.getRoomId());
        if (room == null || room.getStatus() == 0) {
            throw new BusinessException("房型不存在或已下架");
        }

        Homestay homestay = homestayMapper.selectById(dto.getHomestayId());
        if (homestay == null || homestay.getStatus() != 1) {
            throw new BusinessException("民宿不存在或已下架");
        }

        int nights = (int) ChronoUnit.DAYS.between(checkIn, checkOut);
        int roomCount = dto.getRoomCount() != null ? dto.getRoomCount() : 1;

        if (roomCount <= 0) {
            throw new BusinessException("预订房间数量必须大于0");
        }

        if (!checkRoomAvailable(dto.getRoomId(), checkIn, checkOut, roomCount)) {
            throw new BusinessException("该日期段房间已满，请选择其他日期");
        }
        BigDecimal totalAmount = room.getPrice().multiply(BigDecimal.valueOf(nights)).multiply(BigDecimal.valueOf(roomCount));

        Orders order = new Orders();
        order.setOrderNo(IdUtil.getSnowflakeNextIdStr());
        order.setUserId(userId);
        order.setHomestayId(dto.getHomestayId());
        order.setRoomId(dto.getRoomId());
        order.setRoomCount(roomCount);
        order.setGuestName(dto.getGuestName());
        order.setGuestPhone(dto.getGuestPhone());
        order.setCheckInDate(checkIn);
        order.setCheckOutDate(checkOut);
        order.setNights(nights);
        order.setPricePerNight(room.getPrice());
        order.setTotalAmount(totalAmount);
        order.setStatus("pending");
        order.setRemark(dto.getRemark());

        ordersMapper.insert(order);
        return convertToVO(order);
    }

    @Override
    public OrderVO getOrderDetail(Long orderId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");

        Long currentUserId = SecurityUtils.getCurrentUserId();
        boolean isOwner = order.getUserId().equals(currentUserId);
        boolean isAdmin = SecurityUtils.hasRole("admin");
        boolean isHost = false;
        Homestay homestay = homestayMapper.selectById(order.getHomestayId());
        if (homestay != null && homestay.getHostId().equals(currentUserId)) {
            isHost = true;
        }
        if (!isOwner && !isHost && !isAdmin) {
            throw new BusinessException("无权查看该订单");
        }

        return convertToVO(order);
    }

    @Override
    public Page<OrderVO> getUserOrders(Long userId, Integer page, Integer size, String status) {
        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Orders::getUserId, userId);
        if (StrUtil.isNotBlank(status)) {
            wrapper.eq(Orders::getStatus, status);
        }
        wrapper.orderByDesc(Orders::getCreateTime);
        Page<Orders> orderPage = ordersMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(orderPage, page, size);
    }

    @Override
    public Page<OrderVO> getHostOrders(Long hostId, Integer page, Integer size, String status) {
        List<Homestay> homestays = homestayMapper.selectList(
                new LambdaQueryWrapper<Homestay>().eq(Homestay::getHostId, hostId));
        if (homestays.isEmpty()) {
            return new Page<>(page, size, 0);
        }
        List<Long> homestayIds = homestays.stream().map(Homestay::getId).collect(Collectors.toList());

        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<>();
        wrapper.in(Orders::getHomestayId, homestayIds);
        if (StrUtil.isNotBlank(status)) {
            wrapper.eq(Orders::getStatus, status);
        }
        wrapper.orderByDesc(Orders::getCreateTime);
        Page<Orders> orderPage = ordersMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(orderPage, page, size);
    }

    @Override
    public Page<OrderVO> getAdminOrders(Integer page, Integer size, String keyword, String status,
                                         String startDate, String endDate) {
        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<>();
        if (StrUtil.isNotBlank(keyword)) {
            wrapper.and(w -> w.eq(Orders::getOrderNo, keyword)
                    .or().like(Orders::getGuestName, keyword));
        }
        if (StrUtil.isNotBlank(status)) {
            wrapper.eq(Orders::getStatus, status);
        }
        if (StrUtil.isNotBlank(startDate) && StrUtil.isNotBlank(endDate)) {
            wrapper.between(Orders::getCreateTime, startDate + " 00:00:00", endDate + " 23:59:59");
        }
        wrapper.orderByDesc(Orders::getCreateTime);
        Page<Orders> orderPage = ordersMapper.selectPage(new Page<>(page, size), wrapper);
        return convertPage(orderPage, page, size);
    }

    @Override
    public void payOrder(Long orderId, String payMethod, Long userId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        if (!order.getUserId().equals(userId)) {
            throw new BusinessException("无权操作该订单");
        }
        if (!"pending".equals(order.getStatus())) {
            throw new BusinessException("订单状态异常，无法支付");
        }
        order.setStatus("paid");
        order.setPayMethod(payMethod);
        order.setPayTime(LocalDateTime.now());
        ordersMapper.updateById(order);
    }

    @Override
    public void cancelOrder(Long orderId, Long userId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        if (!order.getUserId().equals(userId)) {
            throw new BusinessException("无权取消该订单");
        }
        if (!"pending".equals(order.getStatus()) && !"paid".equals(order.getStatus())) {
            throw new BusinessException("当前状态不可取消");
        }
        order.setStatus("paid".equals(order.getStatus()) ? "refunded" : "canceled");
        ordersMapper.updateById(order);
    }

    @Override
    public void confirmOrder(Long orderId, Long hostId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        Homestay homestay = homestayMapper.selectById(order.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId)) {
            throw new BusinessException("无权操作该订单");
        }
        if (!"paid".equals(order.getStatus())) {
            throw new BusinessException("订单状态异常，无法确认");
        }
        order.setStatus("confirmed");
        ordersMapper.updateById(order);
    }

    @Override
    public void checkinOrder(Long orderId, Long hostId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        Homestay homestay = homestayMapper.selectById(order.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId)) {
            throw new BusinessException("无权操作该订单");
        }
        if (!"confirmed".equals(order.getStatus())) {
            throw new BusinessException("订单状态异常，无法办理入住");
        }
        order.setStatus("check_in");
        ordersMapper.updateById(order);
    }

    @Override
    public void completeOrder(Long orderId, Long hostId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        Homestay homestay = homestayMapper.selectById(order.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId)) {
            throw new BusinessException("无权操作该订单");
        }
        if (!"check_in".equals(order.getStatus())) {
            throw new BusinessException("订单状态异常，无法完成");
        }
        order.setStatus("completed");
        ordersMapper.updateById(order);
    }

    @Override
    public void adminCancelOrder(Long orderId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        if ("completed".equals(order.getStatus()) || "canceled".equals(order.getStatus()) || "refunded".equals(order.getStatus())) {
            throw new BusinessException("当前状态不可取消");
        }
        order.setStatus("canceled");
        ordersMapper.updateById(order);
    }

    @Override
    public void hostCancelOrder(Long orderId, Long hostId) {
        Orders order = ordersMapper.selectById(orderId);
        if (order == null) throw new BusinessException("订单不存在");
        Homestay homestay = homestayMapper.selectById(order.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId)) {
            throw new BusinessException("无权操作该订单");
        }
        if ("completed".equals(order.getStatus()) || "canceled".equals(order.getStatus()) || "refunded".equals(order.getStatus())) {
            throw new BusinessException("当前状态不可取消");
        }
        order.setStatus("paid".equals(order.getStatus()) ? "refunded" : "canceled");
        ordersMapper.updateById(order);
    }

    @Override
    public boolean checkRoomAvailable(Long roomId, LocalDate checkIn, LocalDate checkOut) {
        return checkRoomAvailable(roomId, checkIn, checkOut, 1);
    }

    /**
     * 检查房间可用性（考虑roomCount）
     */
    public boolean checkRoomAvailable(Long roomId, LocalDate checkIn, LocalDate checkOut, int requestRoomCount) {
        Room room = roomMapper.selectById(roomId);
        if (room == null) return false;
        int totalCount = room.getTotalCount();

        // 查询冲突订单的已预订房间总数
        List<Orders> conflictOrders = ordersMapper.selectList(new LambdaQueryWrapper<Orders>()
                .eq(Orders::getRoomId, roomId)
                .in(Orders::getStatus, "pending", "paid", "confirmed", "check_in")
                .lt(Orders::getCheckInDate, checkOut)
                .gt(Orders::getCheckOutDate, checkIn));

        int bookedCount = conflictOrders.stream()
                .mapToInt(o -> o.getRoomCount() != null ? o.getRoomCount() : 1)
                .sum();
        int availableCount = totalCount - bookedCount;
        return availableCount >= requestRoomCount;
    }

    @Override
    public Map<String, Object> generateRevenueReport(Long hostId, String startDate, String endDate) {
        List<Homestay> homestays = homestayMapper.selectList(
                new LambdaQueryWrapper<Homestay>().eq(Homestay::getHostId, hostId));
        List<Long> homestayIds = homestays.stream().map(Homestay::getId).collect(Collectors.toList());

        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<>();
        wrapper.in(Orders::getHomestayId, homestayIds)
                .eq(Orders::getStatus, "completed");
        if (StrUtil.isNotBlank(startDate) && StrUtil.isNotBlank(endDate)) {
            wrapper.between(Orders::getCreateTime, startDate + " 00:00:00", endDate + " 23:59:59");
        }
        List<Orders> orders = ordersMapper.selectList(wrapper);

        BigDecimal totalRevenue = orders.stream()
                .map(Orders::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, BigDecimal> dailyRevenue = new LinkedHashMap<>();
        for (Orders o : orders) {
            String dateKey = DateUtil.format(o.getCreateTime(), "yyyy.MM.dd");
            dailyRevenue.merge(dateKey, o.getTotalAmount(), BigDecimal::add);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalRevenue", totalRevenue);
        result.put("totalOrders", orders.size());
        result.put("dailyRevenue", dailyRevenue);
        return result;
    }

    @Override
    public List<OrderVO> getReviewableOrders(Long userId, Long homestayId) {
        // 查找用户在该民宿已完成的订单
        LambdaQueryWrapper<Orders> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Orders::getUserId, userId)
                .eq(Orders::getHomestayId, homestayId)
                .eq(Orders::getStatus, "completed")
                .orderByDesc(Orders::getCreateTime);
        List<Orders> orders = ordersMapper.selectList(wrapper);

        // 过滤掉已评价的订单
        return orders.stream()
                .filter(o -> {
                    Long count = reviewMapper.selectCount(
                            new LambdaQueryWrapper<Review>().eq(Review::getOrderId, o.getId()));
                    return count == 0;
                })
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    private OrderVO convertToVO(Orders order) {
        OrderVO vo = new OrderVO();
        BeanUtil.copyProperties(order, vo);

        Homestay homestay = homestayMapper.selectById(order.getHomestayId());
        if (homestay != null) {
            vo.setHomestayName(homestay.getName());
            vo.setHomestayCover(homestay.getCoverImage());
        }

        Room room = roomMapper.selectById(order.getRoomId());
        if (room != null) {
            vo.setRoomName(room.getName());
        }

        User user = userMapper.selectById(order.getUserId());
        if (user != null) {
            vo.setUserName(user.getNickname());
        }

        return vo;
    }

    private Page<OrderVO> convertPage(Page<Orders> orderPage, int page, int size) {
        Page<OrderVO> voPage = new Page<>(page, size, orderPage.getTotal());
        voPage.setRecords(orderPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList()));
        return voPage;
    }
}
