package com.homestay.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("room")
public class Room {
    @TableId(type = IdType.AUTO)
    private Long id;

    private Long homestayId;
    private String name;
    private String description;
    private String image;
    private BigDecimal price;
    private Integer totalCount;
    private BigDecimal area;
    private String bedType;
    private Integer maxGuests;
    private Integer hasWifi;
    private Integer hasTv;
    private Integer hasAirConditioner;
    private Integer hasPrivateBathroom;
    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime updateTime;
}
