<template>
  <div class="stat-card" :class="[`stat-card--${variant}`]">
    <div class="stat-icon" :style="iconStyle">
      <el-icon :size="iconSize"><component :is="icon" /></el-icon>
    </div>
    <div class="stat-body">
      <div class="stat-value">{{ value }}</div>
      <div class="stat-label">{{ label }}</div>
    </div>
    <div v-if="trend !== undefined" class="stat-trend" :class="trendClass">
      <el-icon :size="12"><component :is="trendIcon" /></el-icon>
      <span>{{ Math.abs(trend) }}%</span>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { TrendCharts, Bottom } from '@element-plus/icons-vue'

const props = defineProps({
  label: { type: String, required: true },
  value: { type: [String, Number], required: true },
  icon: { type: [Object, String], required: true },
  color: { type: String, default: '#3B82F6' },
  trend: { type: Number, default: undefined },
  variant: { type: String, default: 'default' },
  iconSize: { type: Number, default: 22 }
})

const iconStyle = computed(() => ({
  background: props.color + '18',
  color: props.color
}))

const trendClass = computed(() => props.trend >= 0 ? 'trend-up' : 'trend-down')
const trendIcon = computed(() => props.trend >= 0 ? TrendCharts : Bottom)
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.stat-card {
  background: $color-surface;
  border-radius: $radius-md;
  padding: 24px;
  display: flex;
  align-items: flex-start;
  gap: 16px;
  border: 1px solid $color-border-light;
  transition: all $transition-base;
  position: relative;
  overflow: hidden;

  &:hover {
    box-shadow: $shadow-base;
    transform: translateY(-2px);
  }
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: $radius-base;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.stat-body {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-width: 0;
}

.stat-value {
  font-size: $font-size-2xl;
  font-weight: $font-weight-bold;
  color: $color-text-primary;
  line-height: 1.2;
}

.stat-label {
  font-size: $font-size-sm;
  color: $color-text-secondary;
  margin-top: 4px;
}

.stat-trend {
  position: absolute;
  top: 16px;
  right: 16px;
  display: flex;
  align-items: center;
  gap: 2px;
  font-size: $font-size-xs;
  font-weight: $font-weight-semibold;
  padding: 2px 8px;
  border-radius: $radius-full;

  &.trend-up {
    color: $color-success;
    background: rgba($color-success, 0.1);
  }
  &.trend-down {
    color: $color-danger;
    background: rgba($color-danger, 0.1);
  }
}
</style>
