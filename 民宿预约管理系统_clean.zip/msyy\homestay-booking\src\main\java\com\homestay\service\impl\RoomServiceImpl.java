package com.homestay.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.homestay.common.BusinessException;
import com.homestay.dto.RoomDto;
import com.homestay.entity.Homestay;
import com.homestay.entity.Room;
import com.homestay.mapper.HomestayMapper;
import com.homestay.mapper.RoomMapper;
import com.homestay.service.RoomService;
import com.homestay.vo.RoomVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomMapper roomMapper;
    private final HomestayMapper homestayMapper;

    @Override
    public List<RoomVO> getRoomsByHomestayId(Long homestayId) {
        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getHomestayId, homestayId).eq(Room::getStatus, 1));
        return rooms.stream().map(r -> {
            RoomVO vo = new RoomVO();
            BeanUtil.copyProperties(r, vo);
            vo.setAvailableCount(r.getTotalCount());
            return vo;
        }).collect(Collectors.toList());
    }

    @Override
    public RoomVO getRoomById(Long id) {
        Room room = roomMapper.selectById(id);
        if (room == null) throw new BusinessException("房型不存在");
        RoomVO vo = new RoomVO();
        BeanUtil.copyProperties(room, vo);
        vo.setAvailableCount(room.getTotalCount());
        return vo;
    }

    @Override
    public void addRoom(RoomDto dto, Long hostId) {
        Homestay homestay = homestayMapper.selectById(dto.getHomestayId());
        if (homestay == null) throw new BusinessException("民宿不存在");
        if (!homestay.getHostId().equals(hostId)) throw new BusinessException("无权操作该民宿");

        Room room = new Room();
        BeanUtil.copyProperties(dto, room);
        roomMapper.insert(room);
    }

    @Override
    public void updateRoom(Long id, RoomDto dto, Long hostId) {
        Room room = roomMapper.selectById(id);
        if (room == null) throw new BusinessException("房型不存在");

        Homestay homestay = homestayMapper.selectById(room.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId))
            throw new BusinessException("无权操作该房型");

        BeanUtil.copyProperties(dto, room, "id", "homestayId", "status");
        roomMapper.updateById(room);
    }

    @Override
    public void deleteRoom(Long id, Long hostId) {
        Room room = roomMapper.selectById(id);
        if (room == null) throw new BusinessException("房型不存在");

        Homestay homestay = homestayMapper.selectById(room.getHomestayId());
        if (homestay == null || !homestay.getHostId().equals(hostId))
            throw new BusinessException("无权操作该房型");

        roomMapper.deleteById(id);
    }

    @Override
    public void updateRoomStatus(Long id, Integer status) {
        Room room = roomMapper.selectById(id);
        if (room == null) throw new BusinessException("房型不存在");
        room.setStatus(status);
        roomMapper.updateById(room);
    }
}
