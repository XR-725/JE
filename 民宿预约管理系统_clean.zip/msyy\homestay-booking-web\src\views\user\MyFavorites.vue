<template>
  <div class="favorites-page">
    <div class="page-container">
      <h2>我的收藏</h2>
      <el-row :gutter="20" v-if="list.length">
        <el-col v-for="item in list" :key="item.id" :xs="24" :sm="12" :md="8">
          <HomestayCard :homestay="item" hide-price :is-favorited="true" />
        </el-col>
      </el-row>
      <el-empty v-else description="暂无收藏" />

      <div class="pagination-wrap" v-if="total > 0">
        <el-pagination
          v-model:current-page="page"
          :page-size="size"
          :total="total"
          layout="prev, pager, next"
          background
          @current-change="fetchFavorites"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getMyFavorites } from '@/api/homestay'
import HomestayCard from '@/components/HomestayCard.vue'

const list = ref([])
const page = ref(1)
const size = ref(12)
const total = ref(0)

const fetchFavorites = async () => {
  const res = await getMyFavorites({ page: page.value, size: size.value })
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

onMounted(fetchFavorites)
</script>

<style lang="scss" scoped>
.page-container { max-width: 1000px; margin: 0 auto; padding: 24px 20px; }
h2 { margin-bottom: 20px; }
.pagination-wrap { text-align: center; margin-top: 24px; }
</style>
