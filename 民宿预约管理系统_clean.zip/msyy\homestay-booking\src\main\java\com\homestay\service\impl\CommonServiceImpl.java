package com.homestay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.homestay.entity.Banner;
import com.homestay.entity.Notice;
import com.homestay.mapper.BannerMapper;
import com.homestay.mapper.NoticeMapper;
import com.homestay.service.BannerService;
import com.homestay.service.NoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CommonServiceImpl implements BannerService, NoticeService {

    private final BannerMapper bannerMapper;
    private final NoticeMapper noticeMapper;

    @Override
    public List<Banner> getBanners() {
        return bannerMapper.selectList(
                new LambdaQueryWrapper<Banner>().eq(Banner::getStatus, 1).orderByAsc(Banner::getSortOrder));
    }

    @Override
    public List<Banner> getBannerList(Integer page, Integer size) {
        return bannerMapper.selectList(
                new LambdaQueryWrapper<Banner>().orderByDesc(Banner::getCreateTime));
    }

    @Override
    public void addBanner(Banner banner) {
        bannerMapper.insert(banner);
    }

    @Override
    public void updateBanner(Banner banner) {
        bannerMapper.updateById(banner);
    }

    @Override
    public void deleteBanner(Long id) {
        bannerMapper.deleteById(id);
    }

    @Override
    public List<Notice> getSystemNotices(Integer page, Integer size) {
        return noticeMapper.selectList(
                new LambdaQueryWrapper<Notice>()
                        .isNull(Notice::getTargetUserId)
                        .eq(Notice::getType, "system")
                        .orderByDesc(Notice::getCreateTime));
    }

    @Override
    public List<Notice> getAdminNotices(Integer page, Integer size) {
        return noticeMapper.selectList(
                new LambdaQueryWrapper<Notice>().orderByDesc(Notice::getCreateTime));
    }

    @Override
    public void addNotice(Notice notice) {
        noticeMapper.insert(notice);
    }

    @Override
    public void updateNotice(Notice notice) {
        noticeMapper.updateById(notice);
    }

    @Override
    public void deleteNotice(Long id) {
        noticeMapper.deleteById(id);
    }

    @Override
    public long getUnreadCount(Long userId) {
        return noticeMapper.selectCount(
                new LambdaQueryWrapper<Notice>()
                        .eq(Notice::getIsRead, 0)
                        .and(w -> w.isNull(Notice::getTargetUserId).or().eq(Notice::getTargetUserId, userId)));
    }

    @Override
    public void markAsRead(Long noticeId, Long userId) {
        Notice notice = noticeMapper.selectById(noticeId);
        if (notice != null && (notice.getTargetUserId() == null || notice.getTargetUserId().equals(userId))) {
            notice.setIsRead(1);
            noticeMapper.updateById(notice);
        }
    }
}
