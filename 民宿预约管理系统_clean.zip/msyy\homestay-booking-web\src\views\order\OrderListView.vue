<template>
  <div class="order-list-page">
    <div class="page-container">
      <h2>我的订单</h2>

      <div class="status-tabs">
        <el-radio-group v-model="statusFilter" @change="fetchOrders">
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button label="pending">待支付</el-radio-button>
          <el-radio-button label="paid">已支付</el-radio-button>
          <el-radio-button label="confirmed">已确认</el-radio-button>
          <el-radio-button label="check_in">已入住</el-radio-button>
          <el-radio-button label="completed">已完成</el-radio-button>
          <el-radio-button label="canceled">已取消</el-radio-button>
        </el-radio-group>
      </div>

      <div v-if="orders.length" class="order-list">
        <div v-for="order in orders" :key="order.id" class="order-card">
          <div class="order-header">
            <span class="order-no">订单号: {{ order.orderNo }}</span>
            <el-tag :type="statusType(order.status)" size="small">{{ statusText(order.status) }}</el-tag>
          </div>
          <div class="order-body" @click="$router.push(`/home/order/${order.id}`)">
            <div class="order-img">
              <el-image :src="order.homestayCover" fit="cover" style="width:120px;height:80px;border-radius:8px">
                <template #error><div class="img-ph"><el-icon :size="24"><Picture /></el-icon></div></template>
              </el-image>
            </div>
            <div class="order-info">
              <h4>{{ order.homestayName }}</h4>
              <p>{{ order.roomName }} · {{ order.roomCount }}间</p>
              <p>{{ order.checkInDate }} 至 {{ order.checkOutDate }} · {{ order.nights }}晚</p>
              <p class="guest-info">入住人: {{ order.guestName }} {{ order.guestPhone }}</p>
            </div>
            <div class="order-price">
              <span class="amount">¥{{ order.totalAmount }}</span>
            </div>
          </div>
          <div class="order-actions">
            <template v-if="order.status === 'pending'">
              <el-button type="primary" size="small" @click="$router.push(`/home/order/pay/${order.id}`)">去支付</el-button>
              <el-button size="small" @click="handleCancel(order.id)">取消订单</el-button>
            </template>
            <template v-else-if="order.status === 'paid'">
              <el-button size="small" @click="handleCancel(order.id)">申请退款</el-button>
            </template>
            <template v-else-if="order.status === 'completed'">
              <el-button type="warning" size="small" @click="openReview(order)">评价</el-button>
            </template>
            <el-button size="small" @click="$router.push(`/home/order/${order.id}`)">查看详情</el-button>
          </div>
        </div>
      </div>
      <el-empty v-else description="暂无订单" />

      <div class="pagination-wrap" v-if="total > 0">
        <el-pagination
          v-model:current-page="page"
          :page-size="size"
          :total="total"
          layout="prev, pager, next"
          background
          @current-change="fetchOrders"
        />
      </div>
    </div>

    <!-- 评价弹窗 -->
    <el-dialog v-model="reviewVisible" title="写评价" width="500px" destroy-on-close>
      <div v-if="reviewOrder">
        <div class="review-target">评价民宿: {{ reviewOrder.homestayName }}</div>
        <el-form label-width="80px">
          <el-form-item label="综合评分">
            <el-rate v-model="reviewForm.rating" />
          </el-form-item>
          <el-form-item label="清洁卫生">
            <el-rate v-model="reviewForm.cleanliness" />
          </el-form-item>
          <el-form-item label="地理位置">
            <el-rate v-model="reviewForm.location" />
          </el-form-item>
          <el-form-item label="服务态度">
            <el-rate v-model="reviewForm.service" />
          </el-form-item>
          <el-form-item label="设施条件">
            <el-rate v-model="reviewForm.facilitiesScore" />
          </el-form-item>
          <el-form-item label="评价内容">
            <el-input v-model="reviewForm.content" type="textarea" :rows="3" />
          </el-form-item>
        </el-form>
      </div>
      <template #footer>
        <el-button @click="reviewVisible = false">取消</el-button>
        <el-button type="primary" :loading="reviewing" @click="submitReview">提交评价</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getUserOrders, cancelOrder } from '@/api/order'
import { addReview } from '@/api/review'

const router = useRouter()
const orders = ref([])
const page = ref(1)
const size = ref(10)
const total = ref(0)
const statusFilter = ref('')

const reviewVisible = ref(false)
const reviewOrder = ref(null)
const reviewing = ref(false)
const reviewForm = reactive({
  rating: 5, cleanliness: 5, location: 5, service: 5, facilitiesScore: 5, content: ''
})

const statusType = (s) => {
  const map = { pending: 'warning', paid: '', confirmed: 'success', check_in: '', completed: 'info', canceled: 'danger', refunded: 'danger' }
  return map[s] || 'info'
}

const statusText = (s) => {
  const map = { pending: '待支付', paid: '已支付', confirmed: '已确认', check_in: '已入住', completed: '已完成', canceled: '已取消', refunded: '已退款' }
  return map[s] || s
}

const fetchOrders = async () => {
  const res = await getUserOrders({ page: page.value, size: size.value, status: statusFilter.value || undefined })
  orders.value = res.data.records || []
  total.value = res.data.total || 0
}

const handleCancel = async (id) => {
  try {
    await ElMessageBox.confirm('确定要取消该订单吗？', '提示', { type: 'warning' })
    await cancelOrder(id)
    ElMessage.success('取消成功')
    fetchOrders()
  } catch (e) {}
}

const openReview = (order) => {
  reviewOrder.value = order
  reviewForm.rating = 5
  reviewForm.cleanliness = 5
  reviewForm.location = 5
  reviewForm.service = 5
  reviewForm.facilitiesScore = 5
  reviewForm.content = ''
  reviewVisible.value = true
}

const submitReview = async () => {
  if (!reviewForm.rating) { ElMessage.warning('请评分'); return }
  reviewing.value = true
  try {
    await addReview({
      orderId: reviewOrder.value.id,
      homestayId: reviewOrder.value.homestayId,
      ...reviewForm
    })
    ElMessage.success('评价成功')
    reviewVisible.value = false
    fetchOrders()
  } catch (e) {} finally { reviewing.value = false }
}

onMounted(fetchOrders)
</script>

<style lang="scss" scoped>
.page-container { max-width: 1000px; margin: 0 auto; padding: 24px 20px; }
h2 { margin-bottom: 20px; }
.status-tabs { margin-bottom: 20px; }
.order-card {
  background: #fff; border-radius: 12px; padding: 16px 20px; margin-bottom: 16px;
  .order-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;
    .order-no { font-size: 13px; color: #909399; }
  }
  .order-body { display: flex; gap: 16px; cursor: pointer; margin-bottom: 12px; }
  .order-info { flex: 1;
    h4 { margin: 0 0 6px; font-size: 15px; }
    p { margin: 0 0 3px; font-size: 13px; color: #606266; }
    .guest-info { color: #909399; }
  }
  .order-price { .amount { font-size: 18px; font-weight: bold; color: #ff6b35; } }
  .order-actions { display: flex; justify-content: flex-end; gap: 8px; }
}
.img-ph { width:120px;height:80px;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#ccc;border-radius:8px; }
.pagination-wrap { text-align: center; margin-top: 24px; }
.review-target { font-weight: 500; margin-bottom: 16px; color: #303133; }
</style>
