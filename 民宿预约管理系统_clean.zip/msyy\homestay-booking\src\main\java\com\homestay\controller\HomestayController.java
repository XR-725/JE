package com.homestay.controller;

import com.homestay.common.Result;
import com.homestay.dto.HomestayDto;
import com.homestay.service.HomestayService;
import com.homestay.utils.SecurityUtils;
import com.homestay.vo.HomestayVO;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/homestay")
@RequiredArgsConstructor
public class HomestayController {

    private final HomestayService homestayService;

    @GetMapping("/list")
    public Result<?> list(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "12") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) Integer minRating,
            @RequestParam(required = false, defaultValue = "default") String sortBy) {
        return Result.success(homestayService.getHomestayList(page, size, keyword, city, minPrice, maxPrice, minRating, sortBy));
    }

    @GetMapping("/detail/{id}")
    public Result<HomestayVO> detail(@PathVariable Long id) {
        return Result.success(homestayService.getHomestayDetail(id));
    }

    @GetMapping("/hot")
    public Result<?> hot(@RequestParam(defaultValue = "6") Integer limit) {
        return Result.success(homestayService.getHotHomestays(limit));
    }

    @GetMapping("/recommend")
    public Result<?> recommend(@RequestParam(defaultValue = "4") Integer limit) {
        return Result.success(homestayService.getRecommendHomestays(limit));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> add(@Valid @RequestBody HomestayDto dto) {
        homestayService.addHomestay(dto, SecurityUtils.getCurrentUserId());
        return Result.success("发布成功，请等待管理员审核，审核通过后将在平台展示");
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> update(@PathVariable Long id, @Valid @RequestBody HomestayDto dto) {
        homestayService.updateHomestay(id, dto, SecurityUtils.getCurrentUserId());
        return Result.success("更新成功");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> delete(@PathVariable Long id) {
        homestayService.deleteHomestay(id, SecurityUtils.getCurrentUserId());
        return Result.success("删除成功");
    }

    @GetMapping("/my")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> myHomestays(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        return Result.success(homestayService.getMyHomestays(SecurityUtils.getCurrentUserId(), page, size));
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<?> updateStatus(@PathVariable Long id, @RequestParam Integer status) {
        homestayService.updateHomestayStatus(id, status);
        String msg = status == 1 ? "民宿已上架，将在平台展示" : "民宿已下架";
        return Result.success(msg);
    }
}
