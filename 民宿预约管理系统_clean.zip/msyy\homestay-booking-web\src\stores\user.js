import { defineStore } from 'pinia'
import { login as loginApi, getUserInfo as getUserInfoApi } from '@/api/user'
import { ElMessage } from 'element-plus'

export const useUserStore = defineStore('user', {
  state: () => ({
    token: localStorage.getItem('token') || '',
    userInfo: JSON.parse(localStorage.getItem('userInfo') || 'null')
  }),

  getters: {
    isLoggedIn: (state) => !!state.token,
    username: (state) => state.userInfo?.username || '',
    nickname: (state) => state.userInfo?.nickname || state.userInfo?.username || '',
    avatar: (state) => {
      const url = state.userInfo?.avatar || ''
      if (!url) return ''
      // 添加时间戳防止浏览器缓存旧头像
      const sep = url.includes('?') ? '&' : '?'
      return url + sep + 't=' + (state.userInfo?._avatarTs || Date.now())
    },
    role: (state) => state.userInfo?.role || 'user',
    gender: (state) => state.userInfo?.gender ?? 0,
    genderText: (state) => {
      const g = state.userInfo?.gender
      if (g === 1) return '男'
      if (g === 2) return '女'
      return ''
    },
    roles: (state) => {
      const r = state.userInfo?.role || 'user'
      return r.split(',').map(s => s.trim()).filter(Boolean)
    },
    hasRole: (state) => {
      return (role) => {
        const r = state.userInfo?.role || 'user'
        return r.split(',').map(s => s.trim()).includes(role)
      }
    }
  },

  actions: {
    async login(loginData) {
      const res = await loginApi(loginData)
      this.token = res.data.token
      this.userInfo = res.data.userInfo
      localStorage.setItem('token', res.data.token)
      localStorage.setItem('userInfo', JSON.stringify(res.data.userInfo))
      ElMessage.success('登录成功')
      return res.data
    },

    async fetchUserInfo() {
      const res = await getUserInfoApi()
      this.userInfo = { ...res.data, _avatarTs: Date.now() }
      localStorage.setItem('userInfo', JSON.stringify(this.userInfo))
    },

    logout() {
      this.token = ''
      this.userInfo = null
      localStorage.removeItem('token')
      localStorage.removeItem('userInfo')
      ElMessage.success('已退出登录')
    }
  }
})
