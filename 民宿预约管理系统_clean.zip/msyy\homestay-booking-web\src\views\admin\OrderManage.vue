<template>
  <div class="admin-page">
    <div class="page-header"><h3>{{ title }}</h3></div>
    <el-card>
      <!-- 筛选栏 -->
      <div class="toolbar">
        <el-input v-model="keyword" placeholder="搜索订单号/入住人" clearable style="width:200px" @change="onSearch" />
        <el-select v-model="statusFilter" placeholder="订单状态" clearable style="width:130px" @change="onSearch">
          <el-option v-for="(label, key) in statusMap" :key="key" :label="label" :value="key" />
        </el-select>
        <el-radio-group v-model="groupBy" size="small" @change="regroup">
          <el-radio-button label="">平铺</el-radio-button>
          <el-radio-button label="homestay">按民宿</el-radio-button>
        </el-radio-group>
      </div>

      <!-- 平铺模式 -->
      <el-table v-if="!groupBy" :data="list" border stripe style="width:100%;margin-top:16px">
        <el-table-column prop="orderNo" label="订单号" width="170" show-overflow-tooltip />
        <el-table-column prop="homestayName" label="民宿" width="150" show-overflow-tooltip />
        <el-table-column prop="roomName" label="房型" width="120" show-overflow-tooltip />
        <el-table-column prop="userName" label="用户" width="100" />
        <el-table-column prop="guestName" label="入住人" width="90" />
        <el-table-column prop="checkInDate" label="入住" width="100" />
        <el-table-column prop="checkOutDate" label="退房" width="100" />
        <el-table-column prop="totalAmount" label="金额" width="80">
          <template #default="{ row }"><span class="amount">¥{{ row.totalAmount }}</span></template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }"><el-tag :type="typeMap[row.status]" size="small">{{ statusMap[row.status] }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" width="155" />
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button v-if="canCancel(row.status)" type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 按民宿分组模式 -->
      <div v-else class="grouped-list" style="margin-top:16px">
        <div v-for="group in groupedData" :key="group.name" class="homestay-group">
          <div class="group-header" @click="group.expanded = !group.expanded">
            <div class="group-left">
              <el-icon class="expand-icon" :class="{ rotated: group.expanded }"><ArrowRight /></el-icon>
              <span class="group-name">{{ group.name }}</span>
            </div>
            <div class="group-stats">
              <span>{{ group.orders.length }} 单</span>
              <span class="group-total">合计 ¥{{ group.total }}</span>
            </div>
          </div>
          <div v-show="group.expanded" class="group-body">
            <el-table :data="group.orders" size="small" border stripe>
              <el-table-column prop="orderNo" label="订单号" width="170" show-overflow-tooltip />
              <el-table-column prop="roomName" label="房型" width="120" show-overflow-tooltip />
              <el-table-column prop="userName" label="用户" width="100" />
              <el-table-column prop="guestName" label="入住人" width="90" />
              <el-table-column prop="checkInDate" label="入住" width="100" />
              <el-table-column prop="checkOutDate" label="退房" width="100" />
              <el-table-column prop="totalAmount" label="金额" width="80">
                <template #default="{ row }"><span class="amount">¥{{ row.totalAmount }}</span></template>
              </el-table-column>
              <el-table-column prop="status" label="状态" width="80">
                <template #default="{ row }"><el-tag :type="typeMap[row.status]" size="small">{{ statusMap[row.status] }}</el-tag></template>
              </el-table-column>
              <el-table-column prop="createTime" label="创建时间" width="155" />
              <el-table-column label="操作" width="100">
                <template #default="{ row }">
                  <el-button v-if="canCancel(row.status)" type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <el-empty v-if="groupedData.length === 0" description="暂无订单" />
      </div>

      <div style="text-align:right;margin-top:16px">
        <el-pagination v-model:current-page="page" :page-size="size" :total="total" layout="prev, pager, next, total" background @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ArrowRight } from '@element-plus/icons-vue'
import { getAdminOrders, adminCancelOrder } from '@/api/admin'

defineProps({ title: { type: String, default: '订单管理' } })

const list = ref([])
const page = ref(1)
const size = ref(20)
const total = ref(0)
const keyword = ref('')
const statusFilter = ref('')
const groupBy = ref('')

const statusMap = { pending: '待支付', paid: '已支付', confirmed: '已确认', check_in: '已入住', completed: '已完成', canceled: '已取消' }
const typeMap = { pending: 'warning', paid: '', confirmed: 'success', check_in: '', completed: 'info', canceled: 'danger' }

const canCancel = (s) => ['pending', 'paid', 'confirmed', 'check_in'].includes(s)

// 按民宿分组
const groupedData = computed(() => {
  if (groupBy.value !== 'homestay') return []
  const map = {}
  list.value.forEach(order => {
    const key = order.homestayName || '未知民宿'
    if (!map[key]) map[key] = { name: key, orders: [], total: 0, expanded: true }
    map[key].orders.push(order)
    map[key].total += Number(order.totalAmount) || 0
  })
  return Object.values(map).sort((a, b) => b.total - a.total)
})

const regroup = () => {
  if (groupBy.value) {
    // 分组模式下需要更多数据，增大每页条数
    size.value = 100
  } else {
    size.value = 20
  }
  fetchData()
}

const onSearch = () => { page.value = 1; fetchData() }

const fetchData = async () => {
  const params = { page: page.value, size: size.value }
  if (keyword.value) params.keyword = keyword.value
  if (statusFilter.value) params.status = statusFilter.value
  const res = await getAdminOrders(params)
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

const handleCancel = async (row) => {
  try {
    await ElMessageBox.confirm('确定取消该订单？', '提示', { type: 'warning' })
    await adminCancelOrder(row.id)
    ElMessage.success('取消成功')
    fetchData()
  } catch (e) {}
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.toolbar { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
.amount { color: #409eff; font-weight: 600; }

.grouped-list { display: flex; flex-direction: column; gap: 12px; }

.homestay-group {
  border: 1px solid #ebeef5;
  border-radius: 8px;
  overflow: hidden;
}

.group-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: #f5f7fa;
  cursor: pointer;
  user-select: none;
  transition: background .2s;

  &:hover { background: #ecf0f5; }
}

.group-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.expand-icon {
  transition: transform .2s;
  font-size: 14px;
  color: #909399;

  &.rotated { transform: rotate(90deg); }
}

.group-name {
  font-weight: 600;
  font-size: 14px;
  color: #303133;
}

.group-stats {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #606266;
}

.group-total {
  color: #e6a23c;
  font-weight: 600;
}

.group-body {
  padding: 0;
}
</style>
