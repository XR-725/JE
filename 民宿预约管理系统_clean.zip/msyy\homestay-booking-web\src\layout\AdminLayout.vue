<template>
  <div class="admin-layout">
    <!-- 侧边栏 -->
    <aside class="sidebar" :class="{ 'sidebar--collapsed': collapsed }">
      <div class="sidebar-brand" @click="$router.push('/admin')">
        <div class="brand-icon admin-brand-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
        </div>
        <Transition name="fade-text">
          <span v-if="!collapsed" class="brand-text">管理后台</span>
        </Transition>
      </div>

      <!-- 角色标识 -->
      <div class="role-badge" v-if="!collapsed">
        <el-tag type="danger" effect="dark" size="small" round>系统管理员</el-tag>
      </div>

      <nav class="sidebar-nav">
        <!-- 系统管理 -->
        <div class="nav-group">
          <div v-if="!collapsed" class="nav-group-title">系统管理</div>
          <router-link to="/admin" class="nav-item" exact-active-class="nav-item--active">
            <el-icon :size="20"><DataAnalysis /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">仪表盘</span></Transition>
          </router-link>
          <router-link to="/admin/users" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><User /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">用户管理</span></Transition>
          </router-link>
          <router-link to="/admin/config" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><Setting /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">系统配置</span></Transition>
          </router-link>
          <router-link to="/admin/logs" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><Tickets /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">操作日志</span></Transition>
          </router-link>
        </div>

        <!-- 业务审核 -->
        <div class="nav-group">
          <div v-if="!collapsed" class="nav-group-title">业务审核</div>
          <router-link to="/admin/homestays" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><OfficeBuilding /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">民宿审核</span></Transition>
          </router-link>
          <router-link to="/admin/orders" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><Document /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">订单管理</span></Transition>
          </router-link>
          <router-link to="/admin/reviews" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><ChatDotSquare /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">评价管理</span></Transition>
          </router-link>
        </div>

        <!-- 运营管理 -->
        <div class="nav-group">
          <div v-if="!collapsed" class="nav-group-title">运营管理</div>
          <router-link to="/admin/banners" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><Picture /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">Banner管理</span></Transition>
          </router-link>
          <router-link to="/admin/notices" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><Bell /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">公告管理</span></Transition>
          </router-link>
          <router-link to="/admin/statistics" class="nav-item" active-class="nav-item--active">
            <el-icon :size="20"><TrendCharts /></el-icon>
            <Transition name="fade-text"><span v-if="!collapsed">数据统计</span></Transition>
          </router-link>
        </div>
      </nav>

      <div class="sidebar-footer">
        <button class="collapse-btn" @click="collapsed = !collapsed" :aria-label="collapsed ? '展开菜单' : '折叠菜单'">
          <el-icon :size="18"><Fold v-if="!collapsed" /><Expand v-else /></el-icon>
        </button>
      </div>
    </aside>

    <!-- 主区域 -->
    <div class="main-area">
      <header class="topbar">
        <div class="topbar-left">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/admin' }">管理后台</el-breadcrumb-item>
            <el-breadcrumb-item v-if="$route.meta.title !== '管理后台'">{{ $route.meta.title }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="topbar-right">
          <el-button size="small" text @click="$router.push('/home')">
            <el-icon><HomeFilled /></el-icon>返回首页
          </el-button>
          <el-dropdown trigger="click">
            <div class="topbar-user">
              <el-avatar :size="32" :src="userStore.avatar">{{ userStore.nickname?.charAt(0) }}</el-avatar>
              <span class="topbar-username">{{ userStore.nickname }}</span>
              <el-tag type="danger" size="small" effect="plain">管理员</el-tag>
              <span v-if="userStore.genderText" class="topbar-gender">{{ userStore.genderText }}</span>
              <el-icon class="topbar-chevron"><ArrowDown /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="$router.push('/home/user/profile')">
                  <el-icon><User /></el-icon>个人中心
                </el-dropdown-item>
                <el-dropdown-item v-if="userStore.hasRole('host') && !userStore.hasRole('admin')" @click="$router.push('/host')" divided>
                  <el-icon><HomeFilled /></el-icon>房东中心
                </el-dropdown-item>
                <el-dropdown-item @click="handleLogout" divided>
                  <el-icon><SwitchButton /></el-icon>退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <main class="content">
        <router-view v-slot="{ Component }">
          <Transition name="page-fade" mode="out-in">
            <component :is="Component" :key="$route.fullPath" />
          </Transition>
        </router-view>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { Fold, Expand, ChatDotSquare, TrendCharts } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()
const collapsed = ref(false)

const handleLogout = () => {
  userStore.logout()
  router.push('/login')
}
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.admin-layout { display: flex; height: 100vh; overflow: hidden; }

// ── 侧边栏 ──
.sidebar {
  width: $sidebar-width;
  background: linear-gradient(180deg, #1a1f2e 0%, #0f1219 100%);
  display: flex; flex-direction: column;
  transition: width $transition-base;
  flex-shrink: 0; z-index: 10;
  &--collapsed { width: 64px; }
}

.sidebar-brand {
  height: 64px; display: flex; align-items: center;
  padding: 0 16px; gap: 12px; cursor: pointer;
  border-bottom: 1px solid rgba(255,255,255,0.06);
  overflow: hidden; white-space: nowrap;

  .admin-brand-icon {
    width: 36px; height: 36px;
    background: linear-gradient(135deg, #EF4444, #F87171);
    border-radius: $radius-base;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; color: #fff; padding: 6px;
  }
  .brand-text { font-size: $font-size-lg; font-weight: $font-weight-bold; color: #fff; }
}

.role-badge {
  padding: 8px 16px 0; display: flex; justify-content: center;
}

.sidebar-nav { flex: 1; padding: 8px 8px; overflow-y: auto; overflow-x: hidden; }

.nav-group { margin-bottom: 8px; }
.nav-group-title {
  padding: 12px 16px 6px; font-size: $font-size-xs; color: rgba(255,255,255,0.35);
  text-transform: uppercase; letter-spacing: 1px; font-weight: $font-weight-semibold;
}

.nav-item {
  display: flex; align-items: center; gap: 12px;
  padding: 10px 16px; border-radius: $radius-base;
  color: $color-dark-text; font-size: $font-size-base; font-weight: $font-weight-medium;
  transition: all $transition-fast; margin-bottom: 2px;
  text-decoration: none; white-space: nowrap; overflow: hidden;
  position: relative;

  &:hover { background: rgba(255,255,255,0.08); color: #fff; }

  &--active {
    background: rgba(#EF4444, 0.15); color: #F87171; font-weight: $font-weight-semibold;
    &::before {
      content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%);
      width: 3px; height: 24px; background: #EF4444; border-radius: 0 3px 3px 0;
    }
  }
}

.sidebar-footer { padding: 12px; border-top: 1px solid rgba(255,255,255,0.06); }
.collapse-btn {
  width: 100%; height: 36px; border: none;
  background: rgba(255,255,255,0.06); color: $color-dark-text;
  border-radius: $radius-base; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all $transition-fast;
  &:hover { background: rgba(255,255,255,0.12); color: #fff; }
}

// ── 主区域 ──
.main-area { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.topbar {
  height: 64px; background: $color-surface;
  border-bottom: 1px solid $color-border-light;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 24px; flex-shrink: 0;
}
.topbar-left { display: flex; align-items: center; :deep(.el-breadcrumb__item) { font-size: $font-size-base; } }
.topbar-right { display: flex; align-items: center; gap: 16px; }
.topbar-user {
  display: flex; align-items: center; gap: 8px; cursor: pointer;
  padding: 4px 8px; border-radius: $radius-base;
  transition: background $transition-fast; user-select: none;
  &:hover { background: $color-bg-alt; }
  .topbar-username { font-size: $font-size-base; color: $color-text-primary; font-weight: $font-weight-medium; }
  .topbar-gender { font-size: $font-size-xs; color: $color-text-secondary; }
  .topbar-chevron { font-size: $font-size-xs; color: $color-text-secondary; }
}
.content { flex: 1; overflow-y: auto; background: $color-bg; padding: 24px; }

// 动画
.fade-text-enter-active, .fade-text-leave-active { transition: opacity $transition-fast; }
.fade-text-enter-from, .fade-text-leave-to { opacity: 0; }
.page-fade-enter-active { animation: fadeInUp 0.25s ease-out; }
.page-fade-leave-active { animation: fadeIn 0.12s ease-in reverse; }

// 响应式
@media (max-width: 768px) {
  .sidebar { position: fixed; left: 0; top: 0; bottom: 0; z-index: $z-overlay; box-shadow: $shadow-lg;
    &--collapsed { transform: translateX(-100%); }
  }
  .content { padding: 16px; }
  .topbar { padding: 0 16px; }
}
</style>
