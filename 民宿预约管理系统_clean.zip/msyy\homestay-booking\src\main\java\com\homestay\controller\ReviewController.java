package com.homestay.controller;

import com.homestay.common.Result;
import com.homestay.dto.ReviewDto;
import com.homestay.service.ReviewService;
import com.homestay.utils.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping("/api/review")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping
    public Result<?> add(@Valid @RequestBody ReviewDto dto) {
        if (SecurityUtils.hasRole("admin")) {
            return Result.error("管理员无需评价功能");
        }
        reviewService.addReview(dto, SecurityUtils.getCurrentUserId());
        return Result.success("评价成功");
    }

    @GetMapping("/homestay/{homestayId}")
    public Result<?> listByHomestay(
            @PathVariable Long homestayId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        return Result.success(reviewService.getReviewsByHomestayId(homestayId, page, size));
    }

    @GetMapping("/stats/{homestayId}")
    public Result<?> stats(@PathVariable Long homestayId) {
        return Result.success(reviewService.getReviewStats(homestayId));
    }

    @GetMapping("/room/{roomId}")
    public Result<?> listByRoom(
            @PathVariable Long roomId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        return Result.success(reviewService.getReviewsByRoomId(roomId, page, size));
    }

    @GetMapping("/room/stats/{roomId}")
    public Result<?> roomStats(@PathVariable Long roomId) {
        return Result.success(reviewService.getRoomReviewStats(roomId));
    }

    @GetMapping("/my")
    public Result<?> myReviews(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        if (SecurityUtils.hasRole("admin")) {
            return Result.success(java.util.Collections.emptyMap());
        }
        return Result.success(reviewService.getMyReviews(SecurityUtils.getCurrentUserId(), page, size));
    }

    @PutMapping("/{id}/reply")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> reply(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String reply = body.get("reply");
        reviewService.replyReview(id, SecurityUtils.getCurrentUserId(), reply);
        return Result.success("回复成功");
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        reviewService.deleteReview(id, SecurityUtils.getCurrentUserId());
        return Result.success("删除成功");
    }
}
