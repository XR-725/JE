<template>
  <div class="my-reviews-page">
    <div class="page-container">
      <h2>我的评价</h2>
      <div v-if="list.length">
        <div v-for="r in list" :key="r.id" class="review-card">
          <div class="review-header">
            <span class="homestay-name">{{ r.homestayName }}</span>
            <el-rate :model-value="r.rating" disabled size="small" />
          </div>
          <p class="review-content">{{ r.content || '未填写评价内容' }}</p>
          <div class="review-footer">
            <span class="review-time">{{ r.createTime }}</span>
            <el-button type="danger" link size="small" @click="handleDelete(r.id)">删除</el-button>
          </div>
        </div>
      </div>
      <el-empty v-else description="暂无评价" />

      <div class="pagination-wrap" v-if="total > 0">
        <el-pagination
          v-model:current-page="page"
          :page-size="size"
          :total="total"
          layout="prev, pager, next"
          background
          @current-change="fetchList"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getMyReviews, deleteReview } from '@/api/review'

const list = ref([])
const page = ref(1)
const size = ref(10)
const total = ref(0)

const fetchList = async () => {
  const res = await getMyReviews({ page: page.value, size: size.value })
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

const handleDelete = async (id) => {
  try {
    await ElMessageBox.confirm('确定删除该评价？', '提示', { type: 'warning' })
    await deleteReview(id)
    ElMessage.success('删除成功')
    fetchList()
  } catch (e) {}
}

onMounted(fetchList)
</script>

<style lang="scss" scoped>
.page-container { max-width: 800px; margin: 0 auto; padding: 24px 20px; }
h2 { margin-bottom: 20px; }
.review-card {
  background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 12px;
  .review-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
  .homestay-name { font-weight: 500; }
  .review-content { color: #606266; line-height: 1.6; margin-bottom: 8px; }
  .review-footer { display: flex; align-items: center; justify-content: space-between; }
  .review-time { font-size: 12px; color: #c0c4cc; }
}
.pagination-wrap { text-align: center; margin-top: 24px; }
</style>
