<template>
  <div class="not-found">
    <div class="nf-content">
      <div class="nf-visual">
        <div class="nf-illustration">
          <svg viewBox="0 0 200 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M60 100 L20 60 L40 30 L80 50 L110 20 L140 40 L180 10" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="nf-path"/>
            <circle cx="100" cy="30" r="8" fill="currentColor" class="nf-dot nf-dot-1"/>
            <circle cx="140" cy="40" r="6" fill="currentColor" class="nf-dot nf-dot-2"/>
            <circle cx="60" cy="100" r="16" fill="currentColor" class="nf-house"/>
            <path d="M50 95 L60 82 L70 95" stroke="currentColor" stroke-width="2" class="nf-roof"/>
          </svg>
        </div>
        <h1 class="nf-code">404</h1>
      </div>
      <h2 class="nf-title">页面走丢了</h2>
      <p class="nf-desc">抱歉，你访问的页面不存在或已被移除。也许你可以从首页重新开始探索。</p>
      <div class="nf-actions">
        <el-button type="primary" size="large" @click="$router.push('/home')">
          <el-icon><HomeFilled /></el-icon>返回首页
        </el-button>
        <el-button size="large" @click="$router.back()">
          <el-icon><ArrowLeft /></el-icon>返回上页
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.not-found {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: $color-bg;
  padding: 24px;
}

.nf-content {
  text-align: center;
  max-width: 400px;
}

.nf-visual {
  position: relative;
  margin-bottom: 24px;
}

.nf-illustration {
  color: $color-border;
  margin: 0 auto 8px;
  width: 200px;

  svg {
    width: 100%;
    height: auto;
  }
}

.nf-dot {
  opacity: 0.5;
  animation: float 3s ease-in-out infinite;

  &-2 { animation-delay: -1.5s; }
}

.nf-house {
  opacity: 0.7;
}

@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-6px); }
}

.nf-code {
  font-size: 96px;
  font-weight: $font-weight-bold;
  background: linear-gradient(135deg, $color-primary, $color-primary-light);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  line-height: 1;
  margin: 0;
}

.nf-title {
  font-size: $font-size-2xl;
  font-weight: $font-weight-bold;
  color: $color-text-primary;
  margin: 0 0 12px;
}

.nf-desc {
  font-size: $font-size-base;
  color: $color-text-secondary;
  line-height: $line-height-relaxed;
  margin: 0 0 28px;
}

.nf-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
  flex-wrap: wrap;
}
</style>
