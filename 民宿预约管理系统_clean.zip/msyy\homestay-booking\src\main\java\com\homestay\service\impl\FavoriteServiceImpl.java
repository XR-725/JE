package com.homestay.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.common.BusinessException;
import com.homestay.entity.Favorite;
import com.homestay.entity.Homestay;
import com.homestay.mapper.FavoriteMapper;
import com.homestay.mapper.HomestayMapper;
import com.homestay.service.FavoriteService;
import com.homestay.vo.HomestayVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FavoriteServiceImpl implements FavoriteService {

    private final FavoriteMapper favoriteMapper;
    private final HomestayMapper homestayMapper;

    @Override
    public void addFavorite(Long userId, Long homestayId) {
        Long count = favoriteMapper.selectCount(
                new LambdaQueryWrapper<Favorite>()
                        .eq(Favorite::getUserId, userId)
                        .eq(Favorite::getHomestayId, homestayId));
        if (count > 0) {
            throw new BusinessException("已收藏该民宿");
        }
        Favorite fav = new Favorite();
        fav.setUserId(userId);
        fav.setHomestayId(homestayId);
        favoriteMapper.insert(fav);
    }

    @Override
    public void removeFavorite(Long userId, Long homestayId) {
        favoriteMapper.delete(new LambdaQueryWrapper<Favorite>()
                .eq(Favorite::getUserId, userId)
                .eq(Favorite::getHomestayId, homestayId));
    }

    @Override
    public boolean isFavorite(Long userId, Long homestayId) {
        return favoriteMapper.selectCount(
                new LambdaQueryWrapper<Favorite>()
                        .eq(Favorite::getUserId, userId)
                        .eq(Favorite::getHomestayId, homestayId)) > 0;
    }

    @Override
    public Page<HomestayVO> getMyFavorites(Long userId, Integer page, Integer size) {
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId).orderByDesc(Favorite::getCreateTime);
        Page<Favorite> favPage = favoriteMapper.selectPage(new Page<>(page, size), wrapper);

        Page<HomestayVO> voPage = new Page<>(page, size, favPage.getTotal());
        voPage.setRecords(favPage.getRecords().stream().map(fav -> {
            Homestay h = homestayMapper.selectById(fav.getHomestayId());
            if (h == null) return null;
            HomestayVO vo = new HomestayVO();
            BeanUtil.copyProperties(h, vo, "images", "facilities");
            return vo;
        }).filter(java.util.Objects::nonNull).collect(Collectors.toList()));
        return voPage;
    }
}
