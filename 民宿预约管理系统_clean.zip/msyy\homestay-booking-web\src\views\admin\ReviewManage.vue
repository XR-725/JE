<template>
  <div class="admin-page">
    <div class="page-header"><h3>{{ title }}</h3></div>
    <el-card>
      <el-table :data="list" border stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="userName" label="用户" width="100" />
        <el-table-column prop="homestayName" label="民宿" width="150" />
        <el-table-column prop="rating" label="评分" width="60" />
        <el-table-column prop="content" label="内容" min-width="200" show-overflow-tooltip />
        <el-table-column prop="createTime" label="时间" width="160" />
        <el-table-column label="操作" width="80">
          <template #default="{ row }">
            <el-popconfirm title="确定删除该评价？" @confirm="handleDelete(row.id)">
              <template #reference><el-button type="danger" link size="small">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <div style="text-align:right;margin-top:16px">
        <el-pagination v-model:current-page="page" :page-size="size" :total="total" layout="prev, pager, next" background @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getAdminReviews, adminDeleteReview } from '@/api/admin'

defineProps({ title: { type: String, default: '评价管理' } })

const list = ref([])
const page = ref(1)
const size = ref(10)
const total = ref(0)

const fetchData = async () => {
  const res = await getAdminReviews({ page: page.value, size: size.value })
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

const handleDelete = async (id) => {
  await adminDeleteReview(id)
  ElMessage.success('删除成功')
  fetchData()
}

onMounted(fetchData)
</script>
