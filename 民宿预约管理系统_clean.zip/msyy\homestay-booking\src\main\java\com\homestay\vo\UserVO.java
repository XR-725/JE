package com.homestay.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserVO {
    private Long id;
    private String username;
    private String nickname;
    private String phone;
    private String email;
    private String avatar;
    private Integer gender;
    private String role;
    private Integer status;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;
}
