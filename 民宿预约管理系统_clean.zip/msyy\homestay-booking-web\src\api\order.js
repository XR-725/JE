import request from '@/utils/request'

export const getUserOrders = (params) => request.get('/order/user/list', { params })
export const getOrderDetail = (id) => request.get(`/order/${id}`)
export const createOrder = (data) => request.post('/order', data)
export const payOrder = (id, payMethod) => request.put(`/order/${id}/pay`, { payMethod })
export const cancelOrder = (id) => request.put(`/order/${id}/cancel`)
export const hostCancelOrder = (id) => request.put(`/order/${id}/host-cancel`)
export const checkAvailable = (params) => request.get('/order/check-available', { params })
export const getHostOrders = (params) => request.get('/order/host/list', { params })
export const confirmOrder = (id) => request.put(`/order/${id}/confirm`)
export const checkinOrder = (id) => request.put(`/order/${id}/checkin`)
export const completeOrder = (id) => request.put(`/order/${id}/complete`)
