<template>
  <article
    class="homestay-card card-hover"
    @click="$router.push(`/home/homestay/${homestay.id}`)"
    role="article"
    :aria-label="`民宿: ${homestay.name}`"
    tabindex="0"
    @keydown.enter="$router.push(`/home/homestay/${homestay.id}`)"
  >
    <!-- 图片区域 -->
    <div class="card-media">
      <el-image
        :src="homestay.coverImage"
        fit="cover"
        class="card-img"
        lazy
        :preview-src-list="[]"
      >
        <template #placeholder>
          <div class="card-img-skeleton skeleton"></div>
        </template>
        <template #error>
          <div class="card-img-fallback">
            <el-icon :size="36"><Picture /></el-icon>
          </div>
        </template>
      </el-image>

      <!-- 图片渐变遮罩 -->
      <div class="card-img-gradient"></div>

      <!-- 收藏按钮 -->
      <button
        v-if="!userStore.hasRole('admin')"
        class="fav-btn"
        :class="{ 'fav-btn--active': favActive }"
        @click.stop="toggleFav"
        :aria-label="favActive ? '取消收藏' : '添加收藏'"
      >
        <el-icon :size="18">
          <StarFilled v-if="favActive" />
          <Star v-else />
        </el-icon>
      </button>

      <!-- 价格标签 -->
      <div class="price-tag" v-if="!hidePrice">
        <span class="price-value">¥{{ homestay.minPrice || 0 }}</span>
        <span class="price-unit">/晚起</span>
      </div>

      <!-- 状态标签 -->
      <span v-if="homestay.status === 0 || homestay.status === '0'" class="status-badge status-badge--pending">审核中</span>
    </div>

    <!-- 内容区域 -->
    <div class="card-body">
      <h3 class="card-title text-truncate">{{ homestay.name }}</h3>

      <div class="card-location">
        <el-icon class="loc-icon"><Location /></el-icon>
        <span class="text-truncate">{{ homestay.city }} · {{ homestay.address?.substring(0, 20) }}</span>
      </div>

      <div class="card-footer">
        <div class="card-rating" v-if="homestay.rating && Number(homestay.rating) > 0">
          <el-rate
            :model-value="Number(homestay.rating)"
            disabled
            size="small"
            :colors="['#FF6B35', '#FF6B35', '#FF6B35']"
            :void-color="'#E5E7EB'"
          />
          <span class="rating-score">{{ homestay.rating }}</span>
          <span class="rating-count">{{ homestay.reviewCount || 0 }}条</span>
        </div>
        <div class="card-rating" v-else>
          <span class="no-rating">暂无评分</span>
        </div>
      </div>
    </div>
  </article>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { addFavorite, removeFavorite } from '@/api/homestay'

const props = defineProps({
  homestay: { type: Object, required: true },
  hidePrice: { type: Boolean, default: false },
  isFavorited: { type: Boolean, default: false }
})

const userStore = useUserStore()
const favActive = ref(props.isFavorited)

// Watch prop changes to stay in sync with parent
watch(() => props.isFavorited, (val) => {
  favActive.value = val
})

const toggleFav = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录后再收藏')
    return
  }
  try {
    if (favActive.value) {
      await removeFavorite(props.homestay.id)
      favActive.value = false
      ElMessage.success('已取消收藏')
    } else {
      await addFavorite(props.homestay.id)
      favActive.value = true
      ElMessage.success('已收藏')
    }
  } catch (e) {}
}
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.homestay-card {
  background: $color-surface;
  border-radius: $radius-lg;
  overflow: hidden;
  border: 1px solid $color-border-light;
  margin-bottom: $spacing-xl;
  transition: all $transition-base;
  outline: none;

  &:focus-visible {
    box-shadow: 0 0 0 3px rgba($color-primary, 0.3);
  }
}

// ── 图片区域 ──
.card-media {
  height: 200px;
  position: relative;
  overflow: hidden;

  .card-img {
    width: 100%;
    height: 100%;
    transition: transform 0.6s ease;
  }

  .homestay-card:hover & .card-img {
    transform: scale(1.06);
  }

  .card-img-skeleton {
    width: 100%;
    height: 100%;
    border-radius: 0;
  }

  .card-img-fallback {
    width: 100%;
    height: 100%;
    background: $color-bg-alt;
    display: flex;
    align-items: center;
    justify-content: center;
    color: $color-text-placeholder;
  }

  .card-img-gradient {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(transparent, rgba(0,0,0,0.3));
    pointer-events: none;
  }
}

// ── 收藏按钮 ──
.fav-btn {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 38px;
  height: 38px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(8px);
  border: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 2;
  color: $color-text-secondary;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: all $transition-spring;

  &:hover {
    background: #fff;
    color: $color-primary;
    transform: scale(1.12);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  }

  &--active {
    color: $color-primary;
    background: #fff;
  }
}

// ── 价格标签 ──
.price-tag {
  position: absolute;
  bottom: 12px;
  right: 12px;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(8px);
  color: #fff;
  padding: 5px 14px;
  border-radius: $radius-full;
  line-height: 1.2;

  .price-value {
    font-size: $font-size-lg;
    font-weight: $font-weight-bold;
  }

  .price-unit {
    font-size: $font-size-xs;
    opacity: 0.8;
    margin-left: 2px;
  }
}

// ── 状态徽章 ──
.status-badge {
  position: absolute;
  top: 12px;
  left: 12px;
  padding: 4px 12px;
  border-radius: $radius-full;
  font-size: $font-size-xs;
  font-weight: $font-weight-semibold;
  z-index: 2;

  &--pending {
    background: rgba($color-warning, 0.9);
    color: #fff;
  }
}

// ── 内容 ──
.card-body {
  padding: $spacing-base $spacing-base $spacing-lg;
}

.card-title {
  font-size: $font-size-md;
  font-weight: $font-weight-semibold;
  color: $color-text-primary;
  margin: 0 0 $spacing-sm;
}

.card-location {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: $font-size-sm;
  color: $color-text-secondary;
  margin-bottom: $spacing-md;

  .loc-icon {
    flex-shrink: 0;
    font-size: $font-size-sm;
  }
}

.card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.card-rating {
  display: flex;
  align-items: center;
  gap: 6px;

  .rating-score {
    font-size: $font-size-base;
    font-weight: $font-weight-bold;
    color: $color-primary;
  }

  .rating-count {
    font-size: $font-size-xs;
    color: $color-text-secondary;
  }

  .no-rating {
    font-size: $font-size-sm;
    color: $color-text-placeholder;
  }
}
</style>
