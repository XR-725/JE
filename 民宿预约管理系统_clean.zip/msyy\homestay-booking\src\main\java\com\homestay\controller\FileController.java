package com.homestay.controller;

import com.homestay.common.Result;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/file")
public class FileController {

    @Value("${upload.path}")
    private String uploadPath;

    private String getFileExtension(String filename) {
        if (filename == null) return "";
        int dotIndex = filename.lastIndexOf(".");
        return dotIndex >= 0 ? filename.substring(dotIndex).toLowerCase() : "";
    }

    @PostMapping("/upload")
    public Result<String> upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return Result.error("文件不能为空");
        }

        String originalName = file.getOriginalFilename();
        String ext = getFileExtension(originalName);
        if (ext.isEmpty()) ext = ".dat";

        String datePath = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        String dirPath = uploadPath + "/" + datePath;
        File dir = new File(dirPath);
        if (!dir.exists()) dir.mkdirs();

        String fileName = UUID.randomUUID().toString() + ext;
        File dest = new File(dirPath + "/" + fileName);
        file.transferTo(dest);

        String url = "/uploads/" + datePath + "/" + fileName;
        return Result.success("上传成功", url);
    }

    @PostMapping("/uploads")
    public Result<List<String>> uploads(@RequestParam("files") MultipartFile[] files) throws IOException {
        if (files == null || files.length == 0) {
            return Result.error("文件不能为空");
        }

        List<String> urls = new ArrayList<>();
        for (MultipartFile file : files) {
            String originalName = file.getOriginalFilename();
            String ext = getFileExtension(originalName);
            if (ext.isEmpty()) ext = ".dat";

            String datePath = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            String dirPath = uploadPath + "/" + datePath;
            File dir = new File(dirPath);
            if (!dir.exists()) dir.mkdirs();

            String fileName = UUID.randomUUID().toString() + ext;
            File dest = new File(dirPath + "/" + fileName);
            file.transferTo(dest);

            urls.add("/uploads/" + datePath + "/" + fileName);
        }
        return Result.success(urls);
    }
}
