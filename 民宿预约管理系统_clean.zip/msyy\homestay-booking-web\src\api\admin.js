import request from '@/utils/request'

// ── 仪表盘 ──
export const getDashboard = () => request.get('/admin/dashboard')

// ── 用户管理 ──
export const getUserList = (params) => request.get('/admin/users', { params })
export const updateUserStatus = (id, status) => request.put(`/admin/users/${id}/status`, { status })
export const updateUserRole = (id, role) => request.put(`/admin/users/${id}/role`, { role })

// ── 民宿审核 ──
export const getAdminHomestays = (params) => request.get('/admin/homestays', { params })
export const auditHomestay = (id, status) => request.put(`/admin/homestays/${id}/audit`, { status })

// ── 订单管理 ──
export const getAdminOrders = (params) => request.get('/admin/orders', { params })
export const adminCancelOrder = (id) => request.put(`/admin/orders/${id}/cancel`)

// ── 评价管理 ──
export const getAdminReviews = (params) => request.get('/admin/reviews', { params })
export const adminDeleteReview = (id) => request.delete(`/admin/reviews/${id}`)

// ── Banner管理 ──
export const getAdminBanners = (params) => request.get('/admin/banners', { params })
export const addBanner = (data) => request.post('/admin/banners', data)
export const updateBanner = (id, data) => request.put(`/admin/banners/${id}`, data)
export const deleteBanner = (id) => request.delete(`/admin/banners/${id}`)

// ── 公告管理 ──
export const getAdminNotices = (params) => request.get('/admin/notices', { params })
export const addNotice = (data) => request.post('/admin/notices', data)
export const updateNotice = (id, data) => request.put(`/admin/notices/${id}`, data)
export const deleteNotice = (id) => request.delete(`/admin/notices/${id}`)

// ── 系统配置 ──
export const getConfigList = (params) => request.get('/admin/config', { params })
export const updateConfig = (id, data) => request.put(`/admin/config/${id}`, data)

// ── 操作日志 ──
export const getOperationLogs = (params) => request.get('/admin/logs', { params })

// ── 数据统计 ──
export const getStatistics = () => request.get('/admin/statistics')
