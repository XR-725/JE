<template>
  <div class="room-manage-page">
    <div class="page-header">
      <div>
        <el-button link type="primary" @click="$router.push('/host/homestays')">
          <el-icon><ArrowLeft /></el-icon>返回民宿列表
        </el-button>
        <h3>房型管理 — {{ homestayName }}</h3>
      </div>
      <el-button type="primary" @click="openAdd">添加房型</el-button>
    </div>

    <el-card>
      <el-table :data="list" border stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="图片" width="90">
          <template #default="{ row }">
            <el-image v-if="row.image" :src="row.image" fit="cover" style="width:70px;height:50px;border-radius:4px" />
            <span v-else class="no-image">无图片</span>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="房型名称" min-width="120" />
        <el-table-column prop="price" label="价格/晚" width="100">
          <template #default="{ row }">¥{{ row.price }}</template>
        </el-table-column>
        <el-table-column prop="bedType" label="床型" width="90" />
        <el-table-column prop="maxGuests" label="可住" width="60">
          <template #default="{ row }">{{ row.maxGuests }}人</template>
        </el-table-column>
        <el-table-column prop="totalCount" label="数量" width="60" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'info'" size="small">{{ row.status === 1 ? '上架' : '下架' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openEdit(row)">编辑</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!list.length" description="暂无房型，请添加" style="margin-top:16px" />
    </el-card>

    <!-- 添加/编辑房型弹窗 -->
    <el-dialog v-model="visible" :title="isEdit ? '编辑房型' : '添加房型'" width="560px" destroy-on-close>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="房型名称" prop="name">
          <el-input v-model="form.name" placeholder="如：豪华大床房" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="价格/晚" prop="price">
              <el-input-number v-model="form.price" :min="0" :precision="2" style="width:100%" placeholder="如：299.00" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="数量" prop="totalCount">
              <el-input-number v-model="form.totalCount" :min="1" :max="99" style="width:100%" placeholder="可售房数" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="床型">
              <el-select v-model="form.bedType" placeholder="选择床型" style="width:100%">
                <el-option label="大床 (1.8m)" value="大床 (1.8m)" />
                <el-option label="大床 (1.5m)" value="大床 (1.5m)" />
                <el-option label="双床" value="双床" />
                <el-option label="单人床" value="单人床" />
                <el-option label="上下铺" value="上下铺" />
                <el-option label="榻榻米" value="榻榻米" />
                <el-option label="圆床" value="圆床" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="最大入住">
              <el-input-number v-model="form.maxGuests" :min="1" :max="20" style="width:100%" placeholder="人数" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="面积(m²)">
          <el-input-number v-model="form.area" :min="0" :precision="1" style="width:100%" placeholder="如：25.0" />
        </el-form-item>
        <el-form-item label="房型描述">
          <el-input v-model="form.description" type="textarea" :rows="2" placeholder="如：带独立阳台，海景视野" />
        </el-form-item>

        <!-- 图片上传 -->
        <el-form-item label="房型图片">
          <div class="room-image-area">
            <div v-if="form.image" class="room-image-preview">
              <el-image :src="form.image" fit="cover" style="width:140px;height:100px;border-radius:6px" />
              <el-button type="danger" plain size="small" style="margin-top:6px" @click="form.image = ''">移除</el-button>
            </div>
            <el-upload
              v-if="!form.image"
              :http-request="handleImageUpload"
              :show-file-list="false"
            >
              <div class="room-upload-btn">
                <el-icon><Plus /></el-icon>上传
              </div>
            </el-upload>
          </div>
        </el-form-item>

        <!-- 设施 -->
        <el-form-item label="配套设施">
          <div class="facility-checks">
            <el-checkbox v-model="form.hasWifi" :true-value="1" :false-value="0">WiFi</el-checkbox>
            <el-checkbox v-model="form.hasTv" :true-value="1" :false-value="0">电视</el-checkbox>
            <el-checkbox v-model="form.hasAirConditioner" :true-value="1" :false-value="0">空调</el-checkbox>
            <el-checkbox v-model="form.hasPrivateBathroom" :true-value="1" :false-value="0">独立卫浴</el-checkbox>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="visible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">{{ isEdit ? '保存' : '添加' }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ArrowLeft, Plus } from '@element-plus/icons-vue'
import { getRooms, addRoom, updateRoom, deleteRoom, getHomestayDetail } from '@/api/homestay'
import { uploadFile } from '@/api/common'

const route = useRoute()
const homestayId = Number(route.params.id)
const homestayName = ref('')
const list = ref([])
const visible = ref(false)
const isEdit = ref(false)
const saving = ref(false)
const editingId = ref(null)
const formRef = ref(null)

const defaultForm = () => ({
  name: '', price: null, totalCount: 1, bedType: '', maxGuests: 2,
  area: null, description: '', image: '',
  hasWifi: 0, hasTv: 0, hasAirConditioner: 0, hasPrivateBathroom: 0
})

const form = reactive(defaultForm())

const rules = {
  name: [{ required: true, message: '请输入房型名称', trigger: 'blur' }],
  price: [{ required: true, message: '请输入价格', trigger: 'blur' }],
  totalCount: [{ required: true, message: '请输入数量', trigger: 'blur' }]
}

// 加载民宿名称
const loadHomestay = async () => {
  try {
    const res = await getHomestayDetail(homestayId)
    homestayName.value = res.data?.name || ''
  } catch {}
}

// 加载房型列表
const fetchRooms = async () => {
  try {
    const res = await getRooms(homestayId)
    list.value = res.data || []
  } catch {}
}

// 打开添加弹窗
const openAdd = () => {
  isEdit.value = false
  editingId.value = null
  Object.assign(form, defaultForm())
  visible.value = true
}

// 打开编辑弹窗
const openEdit = (row) => {
  isEdit.value = true
  editingId.value = row.id
  Object.assign(form, {
    name: row.name,
    price: row.price,
    totalCount: row.totalCount,
    bedType: row.bedType || '',
    maxGuests: row.maxGuests,
    area: row.area,
    description: row.description || '',
    image: row.image || '',
    hasWifi: row.hasWifi ?? 0,
    hasTv: row.hasTv ?? 0,
    hasAirConditioner: row.hasAirConditioner ?? 0,
    hasPrivateBathroom: row.hasPrivateBathroom ?? 0
  })
  visible.value = true
}

// 图片上传
const handleImageUpload = async (options) => {
  const fd = new FormData()
  fd.append('file', options.file)
  try {
    const res = await uploadFile(fd)
    form.image = res.data
    ElMessage.success('上传成功')
  } catch {}
}

// 保存房型
const handleSave = async () => {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return

  saving.value = true
  try {
    const data = { ...form, homestayId }
    if (isEdit.value) {
      await updateRoom(editingId.value, data)
      ElMessage.success('房型已更新')
    } else {
      await addRoom(data)
      ElMessage.success('房型已添加')
    }
    visible.value = false
    fetchRooms()
  } catch (e) {
    ElMessage.error(e?.message || '操作失败')
  } finally {
    saving.value = false
  }
}

// 删除房型
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除房型「${row.name}」？`, '提示', { type: 'warning' })
    await deleteRoom(row.id)
    ElMessage.success('已删除')
    fetchRooms()
  } catch {}
}

onMounted(async () => {
  await loadHomestay()
  fetchRooms()
})
</script>

<style lang="scss" scoped>
.page-header {
  display: flex; justify-content: space-between; align-items: flex-start;
  margin-bottom: 16px;
  h3 { margin: 4px 0 0; }
}

.no-image { font-size: 12px; color: #909399; }

.room-image-area { display: flex; flex-direction: column; gap: 8px; }
.room-image-preview { display: flex; flex-direction: column; align-items: flex-start; }

.room-upload-btn {
  width: 140px; height: 100px;
  border: 1px dashed #d9d9d9; border-radius: 6px;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 4px; cursor: pointer; color: #8c939d; font-size: 12px;
  transition: border-color .2s, color .2s;
  &:hover { border-color: #409eff; color: #409eff; }
}

.facility-checks {
  display: flex; flex-wrap: wrap; gap: 16px;
}
</style>
