package com.homestay.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.dto.HomestayDto;
import com.homestay.vo.HomestayVO;

import java.math.BigDecimal;
import java.util.List;

public interface HomestayService {
    Page<HomestayVO> getHomestayList(Integer page, Integer size, String keyword, String city,
                                      BigDecimal minPrice, BigDecimal maxPrice, Integer minRating, String sortBy);
    HomestayVO getHomestayDetail(Long id);
    void addHomestay(HomestayDto dto, Long hostId);
    void updateHomestay(Long id, HomestayDto dto, Long hostId);
    void updateHomestayStatus(Long id, Integer status);
    void deleteHomestay(Long id, Long hostId);
    Page<HomestayVO> getMyHomestays(Long hostId, Integer page, Integer size);
    List<HomestayVO> getHotHomestays(Integer limit);
    List<HomestayVO> getRecommendHomestays(Integer limit);
}
