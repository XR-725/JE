import request from '@/utils/request'

export const getHomestayList = (params) => request.get('/homestay/list', { params })
export const getHomestayDetail = (id) => request.get(`/homestay/detail/${id}`)
export const getHotHomestays = (limit) => request.get('/homestay/hot', { params: { limit } })
export const getRecommendHomestays = (limit) => request.get('/homestay/recommend', { params: { limit } })
export const addHomestay = (data) => request.post('/homestay', data)
export const updateHomestay = (id, data) => request.put(`/homestay/${id}`, data)
export const updateHomestayStatus = (id, status) => request.put(`/homestay/${id}/status`, null, { params: { status } })
export const deleteHomestay = (id) => request.delete(`/homestay/${id}`)
export const getMyHomestays = (params) => request.get('/homestay/my', { params })

export const getRooms = (homestayId) => request.get(`/room/list/${homestayId}`)
export const getRoomDetail = (id) => request.get(`/room/${id}`)
export const addRoom = (data) => request.post('/room', data)
export const updateRoom = (id, data) => request.put(`/room/${id}`, data)
export const deleteRoom = (id) => request.delete(`/room/${id}`)

export const checkFavorite = (homestayId) => request.get(`/favorite/check/${homestayId}`)
export const addFavorite = (homestayId) => request.post(`/favorite/${homestayId}`)
export const removeFavorite = (homestayId) => request.delete(`/favorite/${homestayId}`)
export const getMyFavorites = (params) => request.get('/favorite/my', { params })

export const getReviews = (homestayId, params) => request.get(`/review/homestay/${homestayId}`, { params })
export const getReviewStats = (homestayId) => request.get(`/review/stats/${homestayId}`)

export const getRoomReviews = (roomId, params) => request.get(`/review/room/${roomId}`, { params })
export const getRoomReviewStats = (roomId) => request.get(`/review/room/stats/${roomId}`)

export const getReviewableOrders = (homestayId) => request.get(`/order/reviewable/${homestayId}`)
