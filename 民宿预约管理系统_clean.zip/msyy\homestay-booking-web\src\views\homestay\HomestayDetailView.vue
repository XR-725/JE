<template>
  <div class="detail-page">
    <div class="page-container">
      <div class="gallery-section">
        <div class="main-image" @mouseenter="showArrows = true" @mouseleave="showArrows = false">
          <el-image :src="currentDisplayImage" fit="cover" style="width:100%;height:420px" class="main-img">
            <template #error><div class="img-placeholder"><el-icon :size="48"><Picture /></el-icon></div></template>
          </el-image>
          <div class="nav-arrows" v-if="showArrows && detail.images?.length > 1">
            <div class="arrow arrow-left" @click.stop="prevImage">
              <el-icon :size="24"><ArrowLeft /></el-icon>
            </div>
            <div class="arrow arrow-right" @click.stop="nextImage">
              <el-icon :size="24"><ArrowRight /></el-icon>
            </div>
          </div>
          <div class="image-counter" v-if="detail.images?.length > 1">{{ currentImg + 1 }} / {{ detail.images.length }}</div>
        </div>
        <div class="thumb-list" v-if="detail.images?.length">
          <div v-for="(img, idx) in detail.images" :key="idx" class="thumb-item" :class="{ active: currentImg === idx }" @click="currentImg = idx">
            <el-image :src="img" fit="cover" style="width:100%;height:100%" />
          </div>
        </div>
      </div>

      <div class="content-layout">
        <div class="main-info">
          <div class="info-header">
            <h1>{{ detail.name }}</h1>
            <div class="meta">
              <div class="rating-display">
                <el-rate :model-value="Number(detail.rating) || 5" disabled text-color="#ff9900" />
                <span class="rating-score">{{ detail.rating }}</span>
                <span class="review-num">{{ detail.reviewCount }}条评价</span>
              </div>
              <el-button v-if="!userStore.hasRole('admin')" :type="isFav ? 'danger' : 'default'" circle @click="toggleFavorite">
                <el-icon><StarFilled v-if="isFav" /><Star v-else /></el-icon>
              </el-button>
            </div>
          </div>

          <div class="address-line">
            <el-icon><Location /></el-icon>
            {{ detail.province }} {{ detail.city }} {{ detail.district }} {{ detail.address }}
          </div>

          <el-divider />

          <div class="desc-section">
            <h3>民宿描述</h3>
            <p>{{ detail.description }}</p>
          </div>

          <div class="facilities-section" v-if="detail.facilities?.length">
            <h3>设施服务</h3>
            <div class="facility-tags">
              <el-tag v-for="f in detail.facilities" :key="f" type="success" effect="plain">{{ f }}</el-tag>
            </div>
          </div>

          <div class="check-time">
            <h3>入住/退房时间</h3>
            <p>入住: {{ detail.checkInTime || '14:00' }} | 退房: {{ detail.checkOutTime || '12:00' }}</p>
          </div>

          <div class="host-card" v-if="detail.hostName">
            <h3>房东信息</h3>
            <div class="host-info">
              <el-avatar :size="48" :src="detail.hostAvatar" />
              <div>
                <p class="host-name">{{ detail.hostName }}</p>
                <p class="host-desc">超赞房东</p>
              </div>
            </div>
          </div>

          <el-divider />

          <div class="reviews-section">
            <div class="section-header">
              <h3>房客评价</h3>
              <div class="review-stats-action">
                <div class="review-stats" v-if="stats">
                  <span>总评分 {{ stats.averageRating?.toFixed(1) }}</span>
                  <span>· {{ detail.reviewCount || stats?.totalReviews }}条评价</span>
                </div>
                <el-button v-if="!userStore.hasRole('admin')" type="primary" size="small" @click="openWriteReview">写评价</el-button>
              </div>
            </div>

            <div class="stats-detail" v-if="stats">
              <div class="stat-item" v-for="item in statItems" :key="item.key">
                <span class="stat-label">{{ item.label }}</span>
                <el-progress :percentage="stats[item.key] * 20" :stroke-width="6" :show-text="false" />
                <span class="stat-value">{{ stats[item.key]?.toFixed(1) }}</span>
              </div>
            </div>

            <div v-if="reviews.length" class="review-list">
              <div v-for="r in reviews" :key="r.id" class="review-card">
                <div class="review-user">
                  <el-avatar :size="36" :src="r.userAvatar" />
                  <div>
                    <p class="rv-username">{{ r.userName }}</p>
                    <el-rate :model-value="r.rating" disabled size="small" />
                  </div>
                </div>
                <p class="rv-content">{{ r.content }}</p>
                <div class="rv-images" v-if="r.images?.length">
                  <el-image v-for="(img, i) in r.images" :key="i" :src="img" fit="cover" class="rv-img" />
                </div>
                <div v-if="r.reply" class="rv-reply">
                  <strong>房东回复：</strong>{{ r.reply }}
                </div>
                <span class="rv-time">{{ r.createTime }}</span>
              </div>
            </div>
            <el-empty v-else description="暂无评价" />
          </div>
        </div>

        <div class="sidebar">
          <div class="booking-card">
            <div class="booking-price">
              <span class="price-val">¥{{ detail.minPrice || 0 }}</span>
              <span class="price-unit">/晚</span>
            </div>
            <div class="rooms-section">
              <h4>房型选择</h4>
              <div v-for="room in detail.rooms" :key="room.id" class="room-item">
                <div class="room-image" @click="openRoomReviews(room)">
                  <el-image :src="room.image" fit="cover" style="width:80px;height:60px;border-radius:8px;cursor:pointer">
                    <template #error><div class="room-img-ph"><el-icon :size="24"><Picture /></el-icon></div></template>
                  </el-image>
                  <div class="room-img-overlay"><el-icon :size="16"><ChatDotRound /></el-icon></div>
                </div>
                <div class="room-info">
                  <p class="room-name">{{ room.name }}</p>
                  <p class="room-desc">{{ room.bedType }} · {{ room.area }}㎡ · {{ room.maxGuests }}人</p>
                  <p class="room-price">¥{{ room.price }}/晚</p>
                </div>
                <el-button type="primary" size="small" @click="openBooking(room)">预订</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 房间评价弹窗 -->
    <el-dialog v-model="reviewDialogVisible" :title="`${selectedRoom?.name} - 房客评价`" width="680px" destroy-on-close>
      <div v-loading="reviewLoading">
        <template v-if="reviewError">
          <el-result icon="error" title="加载失败" :sub-title="reviewError" />
        </template>
        <template v-else-if="roomReviews.length">
          <div class="section-header">
            <h3>房客评价</h3>
            <div class="review-stats" v-if="roomStats">
              <span>总评分 {{ roomStats.averageRating?.toFixed(1) }}</span>
              <span>· {{ roomStats.totalReviews }}条评价</span>
            </div>
          </div>
          <div class="review-list">
            <div v-for="r in roomReviews" :key="r.id" class="review-card">
              <div class="review-user">
                <el-avatar :size="36" :src="r.userAvatar" />
                <div>
                  <p class="rv-username">{{ r.userName }}</p>
                  <el-rate :model-value="r.rating" disabled size="small" />
                </div>
              </div>
              <p class="rv-content">{{ r.content }}</p>
              <div class="rv-images" v-if="r.images?.length">
                <el-image v-for="(img, i) in r.images" :key="i" :src="img" fit="cover" class="rv-img" />
              </div>
              <div v-if="r.reply" class="rv-reply">
                <strong>房东回复：</strong>{{ r.reply }}
              </div>
              <span class="rv-time">{{ r.createTime }}</span>
            </div>
          </div>
        </template>
        <el-empty v-else description="该房型暂无评价" />
      </div>
    </el-dialog>

    <BookingDialog ref="bookingDialogRef" :homestay="detail" @success="fetchDetail" />

    <!-- 写评价弹窗 -->
    <el-dialog v-model="writeReviewVisible" title="写评价" width="560px" destroy-on-close>
      <el-form :model="reviewForm" label-width="80px" :rules="reviewRules" ref="reviewFormRef">
        <el-form-item label="关联订单" prop="orderId" v-if="reviewableOrders.length > 0">
          <el-select v-model="reviewForm.orderId" placeholder="选择已完成的订单" style="width:100%">
            <el-option v-for="o in reviewableOrders" :key="o.id" :label="`${o.roomName} · ${o.checkInDate} ~ ${o.checkOutDate}`" :value="o.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="综合评分" prop="rating">
          <el-rate v-model="reviewForm.rating" show-text :texts="['很差', '较差', '一般', '推荐', '力荐']" />
        </el-form-item>
        <el-form-item label="清洁卫生">
          <el-rate v-model="reviewForm.cleanliness" />
        </el-form-item>
        <el-form-item label="地理位置">
          <el-rate v-model="reviewForm.location" />
        </el-form-item>
        <el-form-item label="服务态度">
          <el-rate v-model="reviewForm.service" />
        </el-form-item>
        <el-form-item label="设施条件">
          <el-rate v-model="reviewForm.facilitiesScore" />
        </el-form-item>
        <el-form-item label="评价内容" prop="content">
          <el-input v-model="reviewForm.content" type="textarea" :rows="4" placeholder="分享您的入住体验..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="writeReviewVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitReview">
          提交评价
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getHomestayDetail, checkFavorite, addFavorite, removeFavorite, getReviews, getReviewStats, getRoomReviews, getRoomReviewStats, getReviewableOrders } from '@/api/homestay'
import { addReview } from '@/api/review'
import { useUserStore } from '@/stores/user'
import BookingDialog from '@/components/BookingDialog.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const detail = ref({})
const currentImg = ref(0)
const showArrows = ref(false)
const isFav = ref(false)
const reviews = ref([])
const stats = ref(null)
const bookingDialogRef = ref()

// 房间评价弹窗
const reviewDialogVisible = ref(false)
const reviewLoading = ref(false)
const reviewError = ref('')
const selectedRoom = ref(null)
const roomReviews = ref([])
const roomStats = ref(null)

const currentDisplayImage = computed(() => {
  if (detail.value.images?.length) {
    return detail.value.images[currentImg.value] || detail.value.coverImage
  }
  return detail.value.coverImage
})

const prevImage = () => {
  if (detail.value.images?.length) {
    currentImg.value = currentImg.value <= 0 ? detail.value.images.length - 1 : currentImg.value - 1
  }
}

const nextImage = () => {
  if (detail.value.images?.length) {
    currentImg.value = currentImg.value >= detail.value.images.length - 1 ? 0 : currentImg.value + 1
  }
}

const statItems = [
  { key: 'averageCleanliness', label: '清洁卫生' },
  { key: 'averageLocation', label: '地理位置' },
  { key: 'averageService', label: '服务态度' },
  { key: 'averageFacilities', label: '设施条件' }
]

const fetchDetail = async () => {
  const id = route.params.id
  const res = await getHomestayDetail(id)
  detail.value = res.data
}

const toggleFavorite = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录')
    router.push('/login')
    return
  }
  try {
    if (isFav.value) {
      await removeFavorite(detail.value.id)
      isFav.value = false
      ElMessage.success('取消收藏')
    } else {
      await addFavorite(detail.value.id)
      isFav.value = true
      ElMessage.success('收藏成功')
    }
  } catch (e) {}
}

const openBooking = (room) => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录')
    router.push('/login')
    return
  }
  bookingDialogRef.value.open(room)
}

const openRoomReviews = async (room) => {
  selectedRoom.value = room
  reviewDialogVisible.value = true
  reviewLoading.value = true
  reviewError.value = ''
  roomReviews.value = []
  roomStats.value = null
  try {
    const [revRes, statRes] = await Promise.all([
      getRoomReviews(room.id, { page: 1, size: 20 }),
      getRoomReviewStats(room.id)
    ])
    roomReviews.value = revRes.data?.records || []
    roomStats.value = statRes.data || null
  } catch (e) {
    reviewError.value = e?.response?.data?.message || e?.message || '数据加载失败'
  } finally {
    reviewLoading.value = false
  }
}

// 写评价
const writeReviewVisible = ref(false)
const submitting = ref(false)
const reviewableOrders = ref([])
const reviewableChecked = ref(false)
const reviewFormRef = ref()
const reviewForm = reactive({
  orderId: null,
  rating: 0,
  cleanliness: 5,
  location: 5,
  service: 5,
  facilitiesScore: 5,
  content: ''
})
const reviewRules = {
  content: [{ required: true, message: '请填写评价内容', trigger: 'blur' }]
}

const openWriteReview = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录')
    router.push('/login')
    return
  }
  writeReviewVisible.value = true
  reviewableChecked.value = false
  reviewableOrders.value = []
  reviewForm.orderId = null
  reviewForm.rating = 0
  reviewForm.cleanliness = 5
  reviewForm.location = 5
  reviewForm.service = 5
  reviewForm.facilitiesScore = 5
  reviewForm.content = ''
  try {
    reviewableOrders.value = await getReviewableOrders(detail.value.id).then(r => r.data || [])
  } finally {
    reviewableChecked.value = true
  }
}

const submitReview = async () => {
  const valid = await reviewFormRef.value.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    const data = {
      orderId: reviewForm.orderId,
      homestayId: detail.value.id,
      rating: reviewForm.rating,
      cleanliness: reviewForm.cleanliness,
      location: reviewForm.location,
      service: reviewForm.service,
      facilitiesScore: reviewForm.facilitiesScore,
      content: reviewForm.content
    }
    await addReview(data)
    ElMessage.success('评价成功')
    writeReviewVisible.value = false
    // 刷新评价列表
    const [revRes, statRes] = await Promise.all([
      getReviews(detail.value.id, { page: 1, size: 10 }),
      getReviewStats(detail.value.id)
    ])
    reviews.value = revRes.data?.records || []
    stats.value = statRes.data || null
  } catch (e) {
    ElMessage.error(e?.response?.data?.message || '评价失败')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  await fetchDetail()
  const id = route.params.id
  const [revRes, statRes] = await Promise.all([
    getReviews(id, { page: 1, size: 10 }),
    getReviewStats(id)
  ])
  reviews.value = revRes.data?.records || []
  stats.value = statRes.data || null

  if (userStore.isLoggedIn) {
    try {
      const favRes = await checkFavorite(id)
      isFav.value = favRes.data || false
    } catch (e) {}
  }
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.detail-page {
  background: $color-bg;
  padding-bottom: 60px;
  min-height: 100vh;
}

.page-container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 28px 24px;
}

// ── 图库 ──
.gallery-section {
  margin-bottom: 28px;
}

.main-image {
  border-radius: $radius-lg;
  overflow: hidden;
  margin-bottom: 12px;
  position: relative;
  cursor: pointer;
  background: $color-bg-alt;
}

.main-img {
  border-radius: $radius-lg;
  transition: transform 0.4s ease;

  .main-image:hover & {
    transform: scale(1.02);
  }
}

.nav-arrows {
  position: absolute;
  inset: 0;
  pointer-events: none;

  .arrow {
    pointer-events: auto;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 44px;
    height: 44px;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(8px);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 2;
    transition: all $transition-base;
    box-shadow: $shadow-sm;

    &:hover {
      background: #fff;
      box-shadow: $shadow-md;
      transform: translateY(-50%) scale(1.05);
    }

    &.arrow-left  { left: 16px; }
    &.arrow-right { right: 16px; }
  }
}

.image-counter {
  position: absolute;
  bottom: 16px;
  right: 20px;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(4px);
  color: #fff;
  font-size: $font-size-sm;
  padding: 4px 12px;
  border-radius: $radius-full;
  z-index: 2;
}

.thumb-list {
  display: flex;
  gap: 10px;

  .thumb-item {
    width: 88px;
    height: 60px;
    border-radius: $radius-base;
    overflow: hidden;
    cursor: pointer;
    opacity: 0.55;
    transition: all $transition-base;
    border: 2px solid transparent;

    &.active, &:hover {
      opacity: 1;
      border-color: $color-primary;
      box-shadow: 0 0 0 3px rgba($color-primary, 0.12);
    }
  }
}

// ── 内容布局 ──
.content-layout {
  display: flex;
  gap: 28px;
  align-items: flex-start;

  .main-info {
    flex: 1;
    min-width: 0;
    background: $color-surface;
    border-radius: $radius-lg;
    padding: 28px;
    border: 1px solid $color-border-light;
  }

  .sidebar {
    width: 360px;
    flex-shrink: 0;
    position: sticky;
    top: 88px;
  }
}

// ── 信息头部 ──
.info-header {
  margin-bottom: 20px;

  h1 {
    font-size: $font-size-3xl;
    color: $color-text-primary;
    margin: 0 0 14px;
    font-weight: $font-weight-bold;
  }

  .meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .rating-display {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .rating-score {
    font-size: $font-size-xl;
    font-weight: $font-weight-bold;
    color: $color-primary;
  }

  .review-num {
    color: $color-text-secondary;
    font-size: $font-size-base;
  }
}

.address-line {
  display: flex;
  align-items: center;
  gap: 6px;
  color: $color-text-regular;
  font-size: $font-size-base;
  margin-bottom: 16px;
  padding: 10px 14px;
  background: $color-bg-alt;
  border-radius: $radius-base;
}

// ── 分区 ──
.desc-section, .facilities-section, .check-time, .host-card {
  margin-bottom: 24px;

  h3 {
    font-size: $font-size-lg;
    color: $color-text-primary;
    margin: 0 0 12px;
    font-weight: $font-weight-semibold;
  }

  p {
    color: $color-text-regular;
    line-height: 1.8;
    font-size: $font-size-base;
  }
}

.facility-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.host-info {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
  background: $color-bg-alt;
  border-radius: $radius-base;

  .host-name {
    font-weight: $font-weight-semibold;
    font-size: $font-size-base;
    margin: 0;
  }

  .host-desc {
    color: $color-text-secondary;
    font-size: $font-size-sm;
    margin: 4px 0 0;
  }
}

// ── 评价区 ──
.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;

  h3 {
    font-size: $font-size-lg;
    font-weight: $font-weight-semibold;
    margin: 0;
  }
}

.review-stats { font-size: $font-size-base; color: $color-text-secondary; }
.review-stats-action { display: flex; align-items: center; gap: 16px; }

.no-reviewable-tip {
  display: flex; align-items: center; gap: 6px;
  color: $color-text-secondary; font-size: $font-size-sm;
}

.review-list { margin-top: 16px; }

.stats-detail {
  margin-bottom: 24px;
  padding: 16px;
  background: $color-bg-alt;
  border-radius: $radius-base;

  .stat-item {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 10px;

    &:last-child { margin-bottom: 0; }

    .stat-label {
      width: 64px;
      font-size: $font-size-sm;
      color: $color-text-regular;
    }

    :deep(.el-progress) { flex: 1; }

    .stat-value {
      width: 32px;
      font-size: $font-size-sm;
      font-weight: $font-weight-semibold;
      color: $color-text-regular;
      text-align: right;
    }
  }
}

.review-card {
  background: $color-bg;
  border-radius: $radius-md;
  padding: 18px;
  margin-bottom: 12px;
  border: 1px solid $color-border-light;

  .review-user {
    display: flex; align-items: center; gap: 10px; margin-bottom: 12px;
  }

  .rv-username { font-weight: $font-weight-semibold; margin: 0 0 4px; }
  .rv-content { color: $color-text-primary; line-height: 1.7; margin-bottom: 12px; }
  .rv-images { display: flex; gap: 8px; margin-bottom: 12px; }
  .rv-img { width: 100px; height: 80px; border-radius: $radius-base; object-fit: cover; }
  .rv-reply {
    background: $color-primary-lighter; padding: 12px; border-radius: $radius-base;
    font-size: $font-size-sm; margin-bottom: 10px; border-left: 3px solid $color-primary;
  }
  .rv-time { font-size: $font-size-xs; color: $color-text-placeholder; }
}

// ── 预订卡片 ──
.booking-card {
  background: $color-surface;
  border-radius: $radius-lg;
  padding: 24px;
  box-shadow: $shadow-md;
  border: 1px solid $color-border-light;

  .booking-price {
    margin-bottom: 24px;
    padding-bottom: 20px;
    border-bottom: 1px solid $color-border-light;

    .price-val {
      font-size: 32px;
      font-weight: $font-weight-bold;
      color: $color-primary;
    }

    .price-unit {
      color: $color-text-secondary;
      font-size: $font-size-base;
      margin-left: 4px;
    }
  }
}

.rooms-section h4 {
  font-size: $font-size-lg;
  font-weight: $font-weight-semibold;
  margin-bottom: 16px;
  color: $color-text-primary;
}

.room-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px;
  border: 1px solid $color-border-light;
  border-radius: $radius-base;
  margin-bottom: 10px;
  transition: all $transition-fast;

  &:hover {
    border-color: $color-primary-lighter;
    background: $color-primary-lighter;
  }

  .room-info { flex: 1;
    .room-name { font-weight: $font-weight-semibold; margin: 0 0 4px; font-size: $font-size-base; }
    .room-desc { font-size: $font-size-xs; color: $color-text-secondary; margin: 0 0 2px; }
    .room-price { font-weight: $font-weight-bold; color: $color-primary; margin: 0; font-size: $font-size-base; }
  }
}

.room-img-ph {
  width: 80px; height: 60px;
  background: $color-bg-alt;
  display: flex; align-items: center; justify-content: center;
  color: $color-text-placeholder; border-radius: $radius-base;
}

.room-image {
  position: relative;
  flex-shrink: 0;

  .room-img-overlay {
    position: absolute; inset: 0; border-radius: $radius-base;
    background: rgba(0, 0, 0, 0.35);
    display: flex; align-items: center; justify-content: center;
    color: #fff; opacity: 0; transition: opacity $transition-base;
  }

  &:hover .room-img-overlay { opacity: 1; }
}

.img-placeholder {
  width: 100%; height: 420px;
  background: $color-bg-alt;
  display: flex; align-items: center; justify-content: center;
  color: $color-text-placeholder; border-radius: $radius-lg;
}

// ── 响应式 ──
@media (max-width: 768px) {
  .content-layout {
    flex-direction: column;

    .sidebar { width: 100%; position: static; }
    .main-info { padding: 20px; }
  }

  .main-image .main-img { height: 280px !important; }
  .page-container { padding: 16px; }
}
</style>
