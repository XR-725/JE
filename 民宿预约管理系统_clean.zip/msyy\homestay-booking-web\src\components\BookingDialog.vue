<template>
  <el-dialog v-model="visible" title="确认预订" width="520px" destroy-on-close>
    <div class="booking-dialog" v-if="room">
      <div class="room-summary">
        <el-image :src="room.image" fit="cover" style="width:100%;height:180px;border-radius:12px">
          <template #error><div class="img-ph"><el-icon :size="32"><Picture /></el-icon></div></template>
        </el-image>
        <h4>{{ room.name }}</h4>
        <p class="summary-price">¥{{ room.price }}/晚 · {{ room.bedType }} · {{ room.maxGuests }}人入住</p>
      </div>

      <el-form :model="form" label-width="80px">
        <el-form-item label="入住日期" required>
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="入住日期"
            end-placeholder="退房日期"
            :disabled-date="disabledDate"
            value-format="YYYY.MM.DD"
            @change="onDateChange"
            style="width:100%"
          />
        </el-form-item>

        <el-form-item label="房间数量">
          <el-input-number v-model="form.roomCount" :min="1" :max="room.availableCount || 1" />
          <span class="available-hint">（可订{{ room.availableCount || 1 }}间）</span>
        </el-form-item>

        <el-form-item label="入住人">
          <el-input v-model="form.guestName" placeholder="请输入姓名" />
        </el-form-item>

        <el-form-item label="手机号">
          <el-input v-model="form.guestPhone" placeholder="请输入手机号" />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" placeholder="特殊要求（选填）" />
        </el-form-item>
      </el-form>

      <div class="total-section" v-if="totalAmount">
        <div class="total-row">
          <span>¥{{ room.price }} × {{ nights }}晚 × {{ form.roomCount }}间</span>
        </div>
        <div class="total-amount">
          <span>总价</span>
          <span class="amount">¥{{ totalAmount }}</span>
        </div>
      </div>
    </div>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">立即预订</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { createOrder, checkAvailable } from '@/api/order'

const emit = defineEmits(['success'])
const router = useRouter()

const visible = ref(false)
const room = ref(null)
const homestay = ref(null)
const submitting = ref(false)
const dateRange = ref([])

const form = reactive({
  roomCount: 1,
  guestName: '',
  guestPhone: '',
  remark: ''
})

const nights = computed(() => {
  if (dateRange.value?.length === 2) {
    const d1 = new Date(dateRange.value[0])
    const d2 = new Date(dateRange.value[1])
    return Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24)))
  }
  return 0
})

const totalAmount = computed(() => {
  if (!room.value || !nights.value) return 0
  return room.value.price * nights.value * form.roomCount
})

const disabledDate = (time) => {
  return time.getTime() < Date.now() - 8.64e7
}

const onDateChange = () => {}

const open = (roomData) => {
  room.value = roomData
  form.roomCount = 1
  form.guestName = ''
  form.guestPhone = ''
  form.remark = ''
  dateRange.value = []
  visible.value = true
}

const handleSubmit = async () => {
  if (!dateRange.value?.length) {
    ElMessage.warning('请选择入住和退房日期')
    return
  }
  if (!form.guestName.trim()) {
    ElMessage.warning('请填写入住人姓名')
    return
  }
  if (!form.guestPhone.trim()) {
    ElMessage.warning('请填写手机号')
    return
  }
  const phoneRegex = /^1[3-9]\d{9}$/
  if (!phoneRegex.test(form.guestPhone.trim())) {
    ElMessage.error('请输入正确的手机号')
    return
  }

  submitting.value = true
  try {
    // 提交前校验房间可用性
    const availRes = await checkAvailable({
      roomId: room.value.id,
      checkIn: dateRange.value[0],
      checkOut: dateRange.value[1]
    })
    if (!availRes.data) {
      ElMessage.error('该时段房间已被预订，请选择其他日期')
      submitting.value = false
      return
    }

    const res = await createOrder({
      roomId: room.value.id,
      homestayId: room.value.homestayId,
      roomCount: form.roomCount,
      guestName: form.guestName,
      guestPhone: form.guestPhone,
      checkInDate: dateRange.value[0],
      checkOutDate: dateRange.value[1],
      remark: form.remark
    })
    ElMessage.success('订单创建成功')
    visible.value = false
    router.push(`/home/order/pay/${res.data.id}`)
    emit('success')
  } catch (e) {
    ElMessage.error(e?.message || '预订失败，请重试')
  } finally {
    submitting.value = false
  }
}

defineExpose({ open })
</script>

<style lang="scss" scoped>
.room-summary {
  margin-bottom: 20px;
  h4 { margin: 12px 0 4px; font-size: 16px; }
  .summary-price { color: #909399; font-size: 13px; margin: 0; }
}

.available-hint { font-size: 12px; color: #909399; margin-left: 8px; }

.total-section {
  background: #fdf6f0; padding: 16px; border-radius: 10px; margin-top: 12px;
  .total-row { font-size: 14px; color: #606266; margin-bottom: 8px; }
  .total-amount {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 16px; font-weight: 500;
    .amount { font-size: 24px; font-weight: bold; color: #ff6b35; }
  }
}

.img-ph { width:100%;height:180px;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#ccc;border-radius:12px; }
</style>
