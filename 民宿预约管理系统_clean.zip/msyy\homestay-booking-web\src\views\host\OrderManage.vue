<template>
  <div class="host-page">
    <div class="page-header">
      <h3>订单管理</h3>
      <el-radio-group v-model="statusFilter" size="small" @change="fetchData">
        <el-radio-button label="">全部</el-radio-button>
        <el-radio-button label="pending">待支付</el-radio-button>
        <el-radio-button label="paid">已支付</el-radio-button>
        <el-radio-button label="confirmed">已确认</el-radio-button>
        <el-radio-button label="check_in">已入住</el-radio-button>
        <el-radio-button label="completed">已完成</el-radio-button>
        <el-radio-button label="canceled">已取消</el-radio-button>
        <el-radio-button label="refunded">已退款</el-radio-button>
      </el-radio-group>
    </div>

    <el-card>
      <el-table :data="list" border stripe>
        <el-table-column prop="orderNo" label="订单号" width="170" />
        <el-table-column prop="homestayName" label="民宿" />
        <el-table-column prop="roomName" label="房型" width="120" />
        <el-table-column prop="guestName" label="入住人" width="80" />
        <el-table-column prop="checkInDate" label="入住" width="100" />
        <el-table-column prop="checkOutDate" label="退房" width="100" />
        <el-table-column prop="totalAmount" label="金额" width="80" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }"><el-tag :type="typeMap[row.status]" size="small">{{ statusMap[row.status] }}</el-tag></template>
        </el-table-column>
        <el-table-column label="操作" width="260">
          <template #default="{ row }">
            <template v-if="row.status === 'pending' || row.status === 'paid'">
              <el-button type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
            </template>
            <template v-if="row.status === 'paid'">
              <el-button type="success" link size="small" @click="handleAction(row, 'confirm')">确认</el-button>
            </template>
            <template v-if="row.status === 'confirmed'">
              <el-button type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
              <el-button type="primary" link size="small" @click="handleAction(row, 'checkin')">入住</el-button>
            </template>
            <template v-if="row.status === 'check_in'">
              <el-button type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
              <el-button type="warning" link size="small" @click="handleAction(row, 'complete')">完成</el-button>
            </template>
          </template>
        </el-table-column>
      </el-table>
      <div style="text-align:right;margin-top:16px">
        <el-pagination v-model:current-page="page" :page-size="size" :total="total" layout="prev, pager, next" background @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getHostOrders, confirmOrder, checkinOrder, completeOrder, hostCancelOrder } from '@/api/order'

const list = ref([])
const page = ref(1)
const size = ref(10)
const total = ref(0)
const statusFilter = ref('')
const statusMap = { pending: '待支付', paid: '已支付', confirmed: '已确认', check_in: '已入住', completed: '已完成', canceled: '已取消', refunded: '已退款' }
const typeMap = { pending: 'warning', paid: '', confirmed: 'success', check_in: '', completed: 'info', canceled: 'danger', refunded: 'danger' }

const fetchData = async () => {
  const res = await getHostOrders({ page: page.value, size: size.value, status: statusFilter.value || undefined })
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

const handleAction = async (row, action) => {
  const actions = { confirm: confirmOrder, checkin: checkinOrder, complete: completeOrder }
  const msgs = { confirm: '确认成功', checkin: '入住成功', complete: '订单完成' }
  await actions[action](row.id)
  ElMessage.success(msgs[action])
  fetchData()
}

const handleCancel = async (row) => {
  try {
    await ElMessageBox.confirm(`确定要取消订单 ${row.orderNo} 吗？`, '取消订单', { type: 'warning' })
    await hostCancelOrder(row.id)
    ElMessage.success('取消成功')
    fetchData()
  } catch (e) { /* 取消 */ }
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; }
</style>
