package com.homestay.controller;

import com.homestay.common.Result;
import com.homestay.dto.CreateOrderDto;
import com.homestay.service.OrdersService;
import com.homestay.utils.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/order")
@RequiredArgsConstructor
public class OrdersController {

    private final OrdersService ordersService;

    @PostMapping
    public Result<?> create(@Valid @RequestBody CreateOrderDto dto) {
        return Result.success(ordersService.createOrder(dto, SecurityUtils.getCurrentUserId()));
    }

    @GetMapping("/{id}")
    public Result<?> detail(@PathVariable Long id) {
        return Result.success(ordersService.getOrderDetail(id));
    }

    @GetMapping("/user/list")
    public Result<?> userOrders(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String status) {
        return Result.success(ordersService.getUserOrders(SecurityUtils.getCurrentUserId(), page, size, status));
    }

    @GetMapping("/host/list")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> hostOrders(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String status) {
        return Result.success(ordersService.getHostOrders(SecurityUtils.getCurrentUserId(), page, size, status));
    }

    @GetMapping("/reviewable/{homestayId}")
    public Result<?> reviewable(@PathVariable Long homestayId) {
        return Result.success(ordersService.getReviewableOrders(SecurityUtils.getCurrentUserId(), homestayId));
    }

    @PutMapping("/{id}/pay")
    public Result<?> pay(@PathVariable Long id, @RequestBody(required = false) Map<String, String> body) {
        String payMethod = body != null ? body.getOrDefault("payMethod", "wechat") : "wechat";
        ordersService.payOrder(id, payMethod, SecurityUtils.getCurrentUserId());
        return Result.success("支付成功");
    }

    @PutMapping("/{id}/cancel")
    public Result<?> cancel(@PathVariable Long id) {
        ordersService.cancelOrder(id, SecurityUtils.getCurrentUserId());
        return Result.success("取消成功");
    }

    @PutMapping("/{id}/host-cancel")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> hostCancel(@PathVariable Long id) {
        ordersService.hostCancelOrder(id, SecurityUtils.getCurrentUserId());
        return Result.success("取消成功");
    }

    @PutMapping("/{id}/confirm")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> confirm(@PathVariable Long id) {
        ordersService.confirmOrder(id, SecurityUtils.getCurrentUserId());
        return Result.success("确认成功");
    }

    @PutMapping("/{id}/checkin")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> checkin(@PathVariable Long id) {
        ordersService.checkinOrder(id, SecurityUtils.getCurrentUserId());
        return Result.success("入住成功");
    }

    @PutMapping("/{id}/complete")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> complete(@PathVariable Long id) {
        ordersService.completeOrder(id, SecurityUtils.getCurrentUserId());
        return Result.success("订单已完成");
    }

    @GetMapping("/check-available")
    public Result<?> checkAvailable(
            @RequestParam Long roomId,
            @RequestParam @DateTimeFormat(pattern = "yyyy.MM.dd") LocalDate checkIn,
            @RequestParam @DateTimeFormat(pattern = "yyyy.MM.dd") LocalDate checkOut) {
        return Result.success(ordersService.checkRoomAvailable(roomId, checkIn, checkOut));
    }

    @GetMapping("/host/revenue")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> revenue(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        return Result.success(ordersService.generateRevenueReport(SecurityUtils.getCurrentUserId(), startDate, endDate));
    }
}
