<template>
  <div class="auth-container">
    <!-- 左侧视觉 -->
    <div class="auth-visual">
      <div class="visual-bg">
        <div class="visual-orb visual-orb--1"></div>
        <div class="visual-orb visual-orb--2"></div>
        <div class="visual-orb visual-orb--3"></div>
      </div>
      <div class="visual-content">
        <div class="visual-logo" @click="$router.push('/home')">
          <svg viewBox="0 0 40 40" fill="none"><path d="M20 5L5 17.5v17.5h10v-10h10v10h10V17.5L20 5z" fill="currentColor"/></svg>
          <span>民宿预约</span>
        </div>
        <h2 class="visual-title">发现你的理想民宿</h2>
        <p class="visual-desc">精选全国优质民宿，从山水田园到都市雅居，让每一次旅行都成为美好回忆。</p>
        <div class="visual-features">
          <div class="vf-item"><span class="vf-icon">✓</span> 品质保障</div>
          <div class="vf-item"><span class="vf-icon">✓</span> 真实评价</div>
          <div class="vf-item"><span class="vf-icon">✓</span> 快速预订</div>
        </div>
      </div>
    </div>

    <!-- 右侧表单 -->
    <div class="auth-form">
      <div class="form-wrapper">
        <div class="form-header">
          <h1>欢迎回来</h1>
          <p>登录你的民宿预约账号</p>
        </div>

        <el-form ref="formRef" :model="form" :rules="rules" label-position="top" class="login-form">
          <el-form-item prop="username" label="用户名">
            <el-input
              v-model="form.username"
              placeholder="请输入用户名"
              :prefix-icon="User"
              size="large"
              autocomplete="username"
            />
          </el-form-item>

          <el-form-item prop="password" label="密码">
            <el-input
              v-model="form.password"
              type="password"
              placeholder="请输入密码"
              :prefix-icon="Lock"
              size="large"
              show-password
              autocomplete="current-password"
              @keyup.enter="handleLogin"
            />
          </el-form-item>

          <div class="form-options">
            <el-checkbox v-model="remember">记住密码</el-checkbox>
          </div>

          <el-button
            class="submit-btn"
            size="large"
            :loading="loading"
            @click="handleLogin"
          >
            {{ loading ? '登录中...' : '登 录' }}
          </el-button>
        </el-form>

        <div class="form-footer">
          还没有账号？<router-link to="/register">立即注册</router-link>
        </div>

        <div class="form-divider"><span>或</span></div>

        <el-button class="back-btn" @click="$router.push('/home')">
          <el-icon><ArrowLeft /></el-icon>返回首页
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { User, Lock, ArrowLeft } from '@element-plus/icons-vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const formRef = ref()
const loading = ref(false)
const remember = ref(false)

const form = reactive({
  username: '',
  password: ''
})

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度为3-20个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度为6-20个字符', trigger: 'blur' }
  ]
}

const handleLogin = async () => {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    const data = await userStore.login(form)
    const redirect = route.query.redirect || '/home'
    const roles = (data.userInfo.role || 'user').split(',').map(s => s.trim())
    if (roles.includes('admin')) {
      router.push('/admin')
    } else if (roles.includes('host')) {
      router.push('/host')
    } else {
      router.push(redirect)
    }
  } catch (e) {
    // handled by interceptor
  } finally {
    loading.value = false
  }
}
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.auth-container {
  min-height: 100vh;
  display: flex;
}

// ── 左侧视觉区 ──
.auth-visual {
  flex: 1;
  position: relative;
  overflow: hidden;
  display: none;

  @media (min-width: 768px) { display: flex; align-items: center; }
}

.visual-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(160deg, $color-primary-dark 0%, $color-primary 40%, $color-primary-light 70%, $color-secondary 100%);
}

.visual-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.25;

  &--1 {
    width: 260px; height: 260px;
    background: $color-accent;
    top: 15%; left: 20%;
  }
  &--2 {
    width: 200px; height: 200px;
    background: $color-primary-light;
    bottom: 20%; right: 15%;
  }
  &--3 {
    width: 160px; height: 160px;
    background: $color-secondary-light;
    top: 50%; left: 50%;
  }
}

.visual-content {
  position: relative;
  z-index: 1;
  padding: 60px;
  color: #fff;
}

.visual-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  margin-bottom: 48px;

  svg {
    width: 36px; height: 36px;
    color: #fff;
    opacity: 0.9;
  }

  span {
    font-size: $font-size-xl;
    font-weight: $font-weight-bold;
  }
}

.visual-title {
  font-size: 32px;
  font-weight: $font-weight-bold;
  margin: 0 0 16px;
  line-height: 1.3;
}

.visual-desc {
  font-size: $font-size-md;
  opacity: 0.8;
  line-height: $line-height-relaxed;
  margin: 0 0 32px;
  max-width: 380px;
}

.visual-features {
  display: flex;
  gap: 24px;
}

.vf-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: $font-size-sm;
  opacity: 0.85;

  .vf-icon {
    width: 20px; height: 20px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: bold;
  }
}

// ── 右侧表单区 ──
.auth-form {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: $color-bg;
  padding: 24px;
}

.form-wrapper {
  width: 100%;
  max-width: 400px;
}

.form-header {
  text-align: center;
  margin-bottom: 36px;

  h1 {
    font-size: $font-size-3xl;
    font-weight: $font-weight-bold;
    color: $color-text-primary;
    margin: 0 0 8px;
  }

  p {
    color: $color-text-secondary;
    font-size: $font-size-base;
    margin: 0;
  }
}

.login-form {
  background: $color-surface;
  padding: 32px;
  border-radius: $radius-lg;
  box-shadow: $shadow-sm;
  border: 1px solid $color-border-light;
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.submit-btn {
  width: 100%;
  height: 48px;
  font-size: $font-size-md;
  font-weight: $font-weight-semibold;
  border-radius: $radius-base;
  background: linear-gradient(135deg, $color-primary, $color-primary-light);
  border: none;
  color: #fff;
  margin-top: 4px;
  letter-spacing: 2px;

  &:hover {
    background: linear-gradient(135deg, $color-primary-dark, $color-primary);
    box-shadow: 0 6px 20px rgba($color-primary, 0.35);
    transform: translateY(-1px);
  }
}

.form-footer {
  text-align: center;
  margin-top: 24px;
  font-size: $font-size-base;
  color: $color-text-secondary;

  a {
    color: $color-primary;
    font-weight: $font-weight-semibold;
    margin-left: 4px;
  }
}

.form-divider {
  display: flex;
  align-items: center;
  margin: 24px 0;

  &::before, &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: $color-border;
  }

  span {
    padding: 0 16px;
    font-size: $font-size-sm;
    color: $color-text-placeholder;
  }
}

.back-btn {
  width: 100%;
  height: 44px;
  border-radius: $radius-base;
  font-weight: $font-weight-medium;
  border: 1px solid $color-border;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
</style>
