package com.homestay.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class OrderVO {
    private Long id;
    private String orderNo;
    private Long userId;
    private String userName;
    private Long homestayId;
    private String homestayName;
    private String homestayCover;
    private Long roomId;
    private String roomName;
    private Integer roomCount;
    private String guestName;
    private String guestPhone;

    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate checkInDate;

    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate checkOutDate;

    private Integer nights;
    private BigDecimal pricePerNight;
    private BigDecimal totalAmount;
    private String status;
    private String payMethod;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime payTime;

    private String remark;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;
}
