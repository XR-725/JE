package com.homestay.service;

import com.homestay.entity.Banner;

import java.util.List;

public interface BannerService {
    List<Banner> getBanners();
    List<Banner> getBannerList(Integer page, Integer size);
    void addBanner(Banner banner);
    void updateBanner(Banner banner);
    void deleteBanner(Long id);
}
