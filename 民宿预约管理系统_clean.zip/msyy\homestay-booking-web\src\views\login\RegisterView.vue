<template>
  <div class="auth-container">
    <!-- 左侧视觉 (与登录页对称) -->
    <div class="auth-visual">
      <div class="visual-bg">
        <div class="visual-orb visual-orb--1"></div>
        <div class="visual-orb visual-orb--2"></div>
        <div class="visual-orb visual-orb--3"></div>
      </div>
      <div class="visual-content">
        <div class="visual-logo" @click="$router.push('/home')">
          <svg viewBox="0 0 40 40" fill="none"><path d="M20 5L5 17.5v17.5h10v-10h10v10h10V17.5L20 5z" fill="currentColor"/></svg>
          <span>民宿预约</span>
        </div>
        <h2 class="visual-title">加入我们</h2>
        <p class="visual-desc">注册账号，开启你的民宿之旅。无论是寻找特色住宿，还是分享你的民宿，这里都是最好的起点。</p>
        <div class="visual-features">
          <div class="vf-item"><span class="vf-icon">✓</span> 免费注册</div>
          <div class="vf-item"><span class="vf-icon">✓</span> 海量民宿</div>
          <div class="vf-item"><span class="vf-icon">✓</span> 安全可靠</div>
        </div>
      </div>
    </div>

    <!-- 右侧注册表单 -->
    <div class="auth-form">
      <div class="form-wrapper">
        <div class="form-header">
          <h1>创建账号</h1>
          <p>注册民宿预约管理系统</p>
        </div>

        <div class="form-card">
          <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item prop="username" label="用户名">
                  <el-input v-model="form.username" placeholder="3-20个字符" :prefix-icon="User" size="large" autocomplete="username" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item prop="nickname" label="昵称">
                  <el-input v-model="form.nickname" placeholder="选填" :prefix-icon="User" size="large" />
                </el-form-item>
              </el-col>
            </el-row>

            <el-form-item prop="password" label="密码">
              <el-input v-model="form.password" type="password" placeholder="6-20个字符" :prefix-icon="Lock" size="large" show-password autocomplete="new-password" />
            </el-form-item>

            <el-form-item prop="confirmPassword" label="确认密码">
              <el-input v-model="form.confirmPassword" type="password" placeholder="请再次输入密码" :prefix-icon="Lock" size="large" show-password autocomplete="new-password" />
            </el-form-item>

            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item prop="phone" label="手机号">
                  <el-input v-model="form.phone" placeholder="选填" :prefix-icon="Phone" size="large" autocomplete="tel" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item prop="email" label="邮箱">
                  <el-input v-model="form.email" placeholder="选填" :prefix-icon="Message" size="large" autocomplete="email" />
                </el-form-item>
              </el-col>
            </el-row>

            <el-button
              class="submit-btn"
              size="large"
              :loading="loading"
              @click="handleRegister"
            >
              {{ loading ? '注册中...' : '注 册' }}
            </el-button>
          </el-form>
        </div>

        <div class="form-footer">
          已有账号？<router-link to="/login">立即登录</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { register } from '@/api/user'
import { ElMessage } from 'element-plus'
import { User, Lock, Phone, Message } from '@element-plus/icons-vue'

const router = useRouter()
const formRef = ref()
const loading = ref(false)

const form = reactive({
  username: '',
  password: '',
  confirmPassword: '',
  nickname: '',
  phone: '',
  email: ''
})

const validateConfirm = (rule, value, callback) => {
  if (value !== form.password) {
    callback(new Error('两次输入的密码不一致'))
  } else {
    callback()
  }
}

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度为3-20个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度为6-20个字符', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    { validator: validateConfirm, trigger: 'blur' }
  ]
}

const handleRegister = async () => {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    await register({
      username: form.username,
      password: form.password,
      nickname: form.nickname || form.username,
      phone: form.phone,
      email: form.email
    })
    ElMessage.success('注册成功，请登录')
    router.push('/login')
  } catch (e) {
    // handled by interceptor
  } finally {
    loading.value = false
  }
}
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.auth-container {
  min-height: 100vh;
  display: flex;
}

// ── 左侧视觉区 ──
.auth-visual {
  flex: 1;
  position: relative;
  overflow: hidden;
  display: none;

  @media (min-width: 768px) { display: flex; align-items: center; }
}

.visual-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(160deg, $color-secondary-dark 0%, $color-secondary 40%, $color-secondary-light 70%, $color-primary-dark 100%);
}

.visual-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.25;

  &--1 { width: 260px; height: 260px; background: $color-accent; top: 15%; left: 20%; }
  &--2 { width: 200px; height: 200px; background: $color-primary-light; bottom: 20%; right: 15%; }
  &--3 { width: 160px; height: 160px; background: rgba(255,255,255,0.5); top: 50%; left: 50%; }
}

.visual-content {
  position: relative;
  z-index: 1;
  padding: 60px;
  color: #fff;
}

.visual-logo {
  display: flex; align-items: center; gap: 10px; cursor: pointer; margin-bottom: 48px;
  svg { width: 36px; height: 36px; color: #fff; opacity: 0.9; }
  span { font-size: $font-size-xl; font-weight: $font-weight-bold; }
}

.visual-title { font-size: 32px; font-weight: $font-weight-bold; margin: 0 0 16px; line-height: 1.3; }
.visual-desc { font-size: $font-size-md; opacity: 0.8; line-height: $line-height-relaxed; margin: 0 0 32px; max-width: 380px; }

.visual-features { display: flex; gap: 24px; }
.vf-item { display: flex; align-items: center; gap: 6px; font-size: $font-size-sm; opacity: 0.85;
  .vf-icon { width: 20px; height: 20px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; }
}

// ── 右侧表单区 ──
.auth-form {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: $color-bg;
  padding: 24px;
  overflow-y: auto;
}

.form-wrapper {
  width: 100%;
  max-width: 480px;
}

.form-header {
  text-align: center;
  margin-bottom: 28px;
  h1 { font-size: $font-size-3xl; font-weight: $font-weight-bold; color: $color-text-primary; margin: 0 0 8px; }
  p { color: $color-text-secondary; font-size: $font-size-base; margin: 0; }
}

.form-card {
  background: $color-surface;
  padding: 28px;
  border-radius: $radius-lg;
  box-shadow: $shadow-sm;
  border: 1px solid $color-border-light;
}

.submit-btn {
  width: 100%;
  height: 48px;
  font-size: $font-size-md;
  font-weight: $font-weight-semibold;
  border-radius: $radius-base;
  background: linear-gradient(135deg, $color-primary, $color-primary-light);
  border: none;
  color: #fff;
  margin-top: 4px;
  letter-spacing: 2px;

  &:hover {
    background: linear-gradient(135deg, $color-primary-dark, $color-primary);
    box-shadow: 0 6px 20px rgba($color-primary, 0.35);
    transform: translateY(-1px);
  }
}

.form-footer {
  text-align: center;
  margin-top: 20px;
  font-size: $font-size-base;
  color: $color-text-secondary;

  a { color: $color-primary; font-weight: $font-weight-semibold; margin-left: 4px; }
}
</style>
