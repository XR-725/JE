import request from '@/utils/request'

export const addReview = (data) => request.post('/review', data)
export const getMyReviews = (params) => request.get('/review/my', { params })
export const deleteReview = (id) => request.delete(`/review/${id}`)
export const replyReview = (id, reply) => request.put(`/review/${id}/reply`, { reply })
