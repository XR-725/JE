package com.homestay.service;

import com.homestay.dto.RoomDto;
import com.homestay.vo.RoomVO;

import java.util.List;

public interface RoomService {
    List<RoomVO> getRoomsByHomestayId(Long homestayId);
    RoomVO getRoomById(Long id);
    void addRoom(RoomDto dto, Long hostId);
    void updateRoom(Long id, RoomDto dto, Long hostId);
    void deleteRoom(Long id, Long hostId);
    void updateRoomStatus(Long id, Integer status);
}
