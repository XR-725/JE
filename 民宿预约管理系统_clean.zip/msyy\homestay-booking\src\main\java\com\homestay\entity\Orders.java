package com.homestay.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("orders")
public class Orders {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String orderNo;
    private Long userId;
    private Long homestayId;
    private Long roomId;
    private Integer roomCount;
    private String guestName;
    private String guestPhone;

    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate checkInDate;

    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate checkOutDate;

    private Integer nights;
    private BigDecimal pricePerNight;
    private BigDecimal totalAmount;
    private String status;
    private String payMethod;

    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime payTime;

    private String remark;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime updateTime;
}
