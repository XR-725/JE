package com.homestay.controller;

import com.homestay.common.Result;
import com.homestay.dto.RoomDto;
import com.homestay.service.RoomService;
import com.homestay.utils.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/room")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @GetMapping("/list/{homestayId}")
    public Result<?> list(@PathVariable Long homestayId) {
        return Result.success(roomService.getRoomsByHomestayId(homestayId));
    }

    @GetMapping("/{id}")
    public Result<?> detail(@PathVariable Long id) {
        return Result.success(roomService.getRoomById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> add(@Valid @RequestBody RoomDto dto) {
        roomService.addRoom(dto, SecurityUtils.getCurrentUserId());
        return Result.success("添加成功");
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> update(@PathVariable Long id, @Valid @RequestBody RoomDto dto) {
        roomService.updateRoom(id, dto, SecurityUtils.getCurrentUserId());
        return Result.success("更新成功");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('HOST', 'ADMIN')")
    public Result<?> delete(@PathVariable Long id) {
        roomService.deleteRoom(id, SecurityUtils.getCurrentUserId());
        return Result.success("删除成功");
    }
}
