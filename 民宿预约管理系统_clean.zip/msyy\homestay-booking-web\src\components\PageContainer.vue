<template>
  <div class="page-container">
    <!-- 页头 -->
    <div v-if="title" class="page-header">
      <div class="page-header-left">
        <h3 class="page-title">{{ title }}</h3>
        <span v-if="subtitle" class="page-subtitle">{{ subtitle }}</span>
      </div>
      <div class="page-header-right">
        <slot name="actions" />
      </div>
    </div>

    <!-- 搜索/筛选栏 -->
    <div v-if="$slots.toolbar" class="page-toolbar">
      <slot name="toolbar" />
    </div>

    <!-- 主内容 -->
    <div class="page-body">
      <slot />
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: { type: String, default: '' },
  subtitle: { type: String, default: '' }
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.page-container {
  max-width: $max-width;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: $spacing-lg;
  gap: $spacing-base;
  flex-wrap: wrap;
}

.page-header-left {
  display: flex;
  align-items: baseline;
  gap: $spacing-sm;
}

.page-title {
  font-size: $font-size-xl;
  font-weight: $font-weight-bold;
  color: $color-text-primary;
  margin: 0;
}

.page-subtitle {
  font-size: $font-size-sm;
  color: $color-text-secondary;
}

.page-header-right {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.page-toolbar {
  display: flex;
  gap: $spacing-sm;
  margin-bottom: $spacing-lg;
  flex-wrap: wrap;
  align-items: center;
}

.page-body {
  // Content flows naturally
}
</style>
