package com.homestay.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.vo.HomestayVO;

public interface FavoriteService {
    void addFavorite(Long userId, Long homestayId);
    void removeFavorite(Long userId, Long homestayId);
    boolean isFavorite(Long userId, Long homestayId);
    Page<HomestayVO> getMyFavorites(Long userId, Integer page, Integer size);
}
