<template>
  <div class="profile-page">
    <div class="page-container">
      <el-row :gutter="24">
        <el-col :span="6">
          <el-menu class="side-menu" :default-active="activeMenu" router>
            <el-menu-item index="/home/user/profile">
              <el-icon><User /></el-icon> 个人信息
            </el-menu-item>
            <el-menu-item v-if="!userStore.hasRole('admin')" index="/home/user/favorites">
              <el-icon><Star /></el-icon> 我的收藏
            </el-menu-item>
            <el-menu-item v-if="!userStore.hasRole('admin')" index="/home/user/reviews">
              <el-icon><ChatLineSquare /></el-icon> 我的评价
            </el-menu-item>
            <el-menu-item v-if="!userStore.hasRole('admin')" index="/home/order/list">
              <el-icon><Document /></el-icon> 我的订单
            </el-menu-item>
          </el-menu>
        </el-col>
        <el-col :span="18">
          <div class="content-panel">
            <div class="user-info-section">
              <div class="avatar-section">
                <el-avatar :size="80" :src="userStore.avatar" />
                <el-upload
                  class="avatar-upload"
                  :http-request="handleAvatarUpload"
                  :show-file-list="false"
                >
                  <el-button type="primary" link>更换头像</el-button>
                </el-upload>
              </div>
              <div class="basic-info">
                <h3>{{ userStore.nickname }}</h3>
                <p>用户名: {{ userStore.username }}</p>
                <template v-for="r in userStore.roles" :key="r">
                  <el-tag :type="r === 'admin' ? 'danger' : r === 'host' ? 'warning' : ''" style="margin-right:4px">{{ roleText(r) }}</el-tag>
                </template>
              </div>
            </div>

            <el-divider />

            <el-form :model="form" label-width="100px" class="profile-form">
              <el-form-item label="昵称">
                <el-input v-model="form.nickname" />
              </el-form-item>
              <el-form-item label="手机号">
                <el-input v-model="form.phone" />
              </el-form-item>
              <el-form-item label="邮箱">
                <el-input v-model="form.email" />
              </el-form-item>
              <el-form-item label="性别">
                <el-radio-group v-model="form.gender">
                  <el-radio :label="0">未知</el-radio>
                  <el-radio :label="1">男</el-radio>
                  <el-radio :label="2">女</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" :loading="saving" @click="saveProfile">保存</el-button>
              </el-form-item>
            </el-form>

            <el-divider />

            <h3>修改密码</h3>
            <el-form :model="pwdForm" label-width="100px" class="pwd-form">
              <el-form-item label="原密码">
                <el-input v-model="pwdForm.oldPassword" type="password" show-password />
              </el-form-item>
              <el-form-item label="新密码">
                <el-input v-model="pwdForm.newPassword" type="password" show-password />
              </el-form-item>
              <el-form-item>
                <el-button type="warning" :loading="pwdSaving" @click="savePassword">修改密码</el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { updateProfile, updatePassword, updateAvatar } from '@/api/user'

const route = useRoute()
const userStore = useUserStore()
const saving = ref(false)
const pwdSaving = ref(false)

const activeMenu = computed(() => route.path)

const form = reactive({
  nickname: '',
  phone: '',
  email: '',
  gender: 0
})

const pwdForm = reactive({
  oldPassword: '',
  newPassword: ''
})

const uploadHeaders = computed(() => ({
  Authorization: `Bearer ${userStore.token}`
}))

const roleText = (r) => ({ admin: '管理员', host: '房东', user: '用户' }[r] || '用户')

const beforeAvatarUpload = () => {
  return true
}

const handleAvatarUpload = async ({ file }) => {
  const formData = new FormData()
  formData.append('file', file)
  try {
    await updateAvatar(formData)
    ElMessage.success('头像更新成功')
    await userStore.fetchUserInfo()
  } catch (e) {
    // 错误已由axios拦截器处理
  }
}

const saveProfile = async () => {
  saving.value = true
  try {
    await updateProfile(form)
    ElMessage.success('保存成功')
    userStore.fetchUserInfo()
  } catch (e) {} finally { saving.value = false }
}

const savePassword = async () => {
  if (!pwdForm.oldPassword) { ElMessage.warning('请输入原密码'); return }
  if (!pwdForm.newPassword || pwdForm.newPassword.length < 6) { ElMessage.warning('新密码至少6位'); return }
  pwdSaving.value = true
  try {
    await updatePassword(pwdForm)
    ElMessage.success('密码修改成功')
    pwdForm.oldPassword = ''
    pwdForm.newPassword = ''
  } catch (e) {} finally { pwdSaving.value = false }
}

onMounted(() => {
  if (userStore.userInfo) {
    form.nickname = userStore.userInfo.nickname || ''
    form.phone = userStore.userInfo.phone || ''
    form.email = userStore.userInfo.email || ''
    form.gender = userStore.userInfo.gender || 0
  }
})
</script>

<style lang="scss" scoped>
.page-container { max-width: 1000px; margin: 0 auto; padding: 24px 20px; }
.side-menu { border-right: none; border-radius: 12px; overflow: hidden; }
.content-panel { background: #fff; border-radius: 12px; padding: 32px; min-height: 500px; }
.user-info-section { display: flex; align-items: center; gap: 24px; margin-bottom: 20px; }
.avatar-section { text-align: center; }
.basic-info {
  h3 { margin: 0 0 6px; }
  p { color: #909399; margin: 0 0 8px; }
}
.profile-form, .pwd-form { max-width: 500px; margin-top: 16px; }
</style>
