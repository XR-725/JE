<template>
  <div class="host-page">
    <div class="page-header"><h3>收益报表</h3></div>
    <el-card v-loading="loading">
      <template v-if="error">
        <el-result icon="error" title="加载失败" :sub-title="error">
          <template #extra>
            <el-button type="primary" @click="fetchReport">重新加载</el-button>
          </template>
        </el-result>
      </template>
      <template v-else-if="report">
        <div class="revenue-summary">
          <div class="revenue-card">
            <div class="revenue-label">总收入</div>
            <div class="revenue-value">¥{{ report.totalRevenue || 0 }}</div>
          </div>
          <div class="revenue-card">
            <div class="revenue-label">总订单数</div>
            <div class="revenue-value">{{ report.totalOrders || 0 }}</div>
          </div>
        </div>

        <div class="daily-list" v-if="hasDailyData">
          <h4>每日收入明细</h4>
          <div v-for="(amount, date) in report.dailyRevenue" :key="date" class="daily-row">
            <span>{{ date }}</span>
            <span class="daily-amount">¥{{ amount }}</span>
          </div>
        </div>
        <el-empty v-else description="暂无收益数据" />
      </template>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { getHostRevenue } from '@/api/common'

const report = ref(null)
const loading = ref(false)
const error = ref('')

const hasDailyData = computed(() => {
  return report.value?.dailyRevenue && Object.keys(report.value.dailyRevenue).length > 0
})

const fetchReport = async () => {
  loading.value = true
  error.value = ''
  try {
    const res = await getHostRevenue()
    report.value = res.data || null
    if (!report.value) {
      error.value = '暂无数据'
    }
  } catch (e) {
    error.value = e?.response?.data?.message || e?.message || '数据加载失败，请稍后重试'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchReport()
})
</script>

<style lang="scss" scoped>
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; }

.revenue-summary {
  display: flex; gap: 24px; margin-bottom: 32px;
}

.revenue-card {
  flex: 1; background: linear-gradient(135deg, #ff6b35, #ff8c60); color: #fff;
  padding: 24px; border-radius: 12px;
  .revenue-label { font-size: 14px; opacity: 0.85; margin-bottom: 8px; }
  .revenue-value { font-size: 32px; font-weight: bold; }
}

.daily-list {
  h4 { margin-bottom: 12px; }
}
.daily-row {
  display: flex; justify-content: space-between; padding: 8px 0;
  border-bottom: 1px solid #f0f0f0; font-size: 14px;
  .daily-amount { font-weight: 500; color: #ff6b35; }
}
</style>
