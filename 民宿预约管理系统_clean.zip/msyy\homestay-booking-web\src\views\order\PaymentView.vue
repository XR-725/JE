<template>
  <div class="pay-page">
    <div class="page-container">
      <div class="pay-card" v-if="order">
        <h2>确认支付</h2>
        <div class="order-summary">
          <p><strong>{{ order.homestayName }}</strong> · {{ order.roomName }}</p>
          <p>{{ order.checkInDate }} - {{ order.checkOutDate }} · {{ order.nights }}晚 · {{ order.roomCount }}间</p>
        </div>

        <div class="pay-methods">
          <h3>选择支付方式</h3>
          <div class="method-list">
            <div class="method-item" :class="{ active: payMethod === 'wechat' }" @click="payMethod = 'wechat'">
              <span class="method-icon">💚</span>
              <span>微信支付</span>
            </div>
            <div class="method-item" :class="{ active: payMethod === 'alipay' }" @click="payMethod = 'alipay'">
              <span class="method-icon">💙</span>
              <span>支付宝</span>
            </div>
          </div>
        </div>

        <div class="pay-total">
          <span>支付金额</span>
          <span class="amount">¥{{ order.totalAmount }}</span>
        </div>

        <el-button type="primary" size="large" :loading="paying" class="pay-btn" @click="handlePay">
          确认支付 ¥{{ order.totalAmount }}
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getOrderDetail, payOrder } from '@/api/order'

const route = useRoute()
const router = useRouter()
const order = ref(null)
const payMethod = ref('wechat')
const paying = ref(false)

onMounted(async () => {
  const id = route.params.id
  const res = await getOrderDetail(id)
  order.value = res.data
  if (order.value && order.value.status !== 'pending') {
    ElMessage.warning('该订单当前状态不可支付')
    router.replace(`/home/order/${id}`)
  }
})

const handlePay = async () => {
  paying.value = true
  try {
    await payOrder(route.params.id, payMethod.value)
    ElMessage.success('支付成功')
    router.push('/home/order/list')
  } catch (e) {} finally { paying.value = false }
}
</script>

<style lang="scss" scoped>
.page-container { max-width: 600px; margin: 60px auto; padding: 0 20px; }
.pay-card { background: #fff; border-radius: 12px; padding: 32px; text-align: center; }
h2 { margin-bottom: 20px; }
.order-summary { text-align: left; background: #f5f7fa; padding: 16px; border-radius: 8px; margin-bottom: 24px;
  p { margin: 0 0 6px; color: #606266; }
}
.pay-methods { margin-bottom: 24px; text-align: left;
  h3 { margin-bottom: 12px; font-size: 15px; }
}
.method-list { display: flex; gap: 16px; }
.method-item {
  flex: 1; padding: 16px; border: 2px solid #ebeef5; border-radius: 10px;
  cursor: pointer; text-align: center; transition: all 0.3s;
  &.active { border-color: #ff6b35; background: rgba(#ff6b35, 0.04); }
  .method-icon { display: block; font-size: 28px; margin-bottom: 8px; }
}
.pay-total { display: flex; justify-content: space-between; align-items: center; padding: 16px 0; border-top: 1px solid #ebeef5; margin-bottom: 24px;
  .amount { font-size: 28px; font-weight: bold; color: #ff6b35; }
}
.pay-btn { width: 100%; height: 48px; font-size: 16px; }
</style>
