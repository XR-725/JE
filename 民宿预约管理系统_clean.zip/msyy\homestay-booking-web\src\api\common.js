import request from '@/utils/request'

export const uploadFile = (formData) => request.post('/file/upload', formData)

export const getBanners = () => request.get('/banner/list')

export const getNotices = (params) => request.get('/notice/list', { params })
export const getUnreadCount = () => request.get('/notice/unread-count')
export const markAsRead = (id) => request.put(`/notice/read/${id}`)

export const getHostRevenue = (params) => request.get('/order/host/revenue', { params })

export const getStats = () => request.get('/stats')
