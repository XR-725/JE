﻿-- ============================================
-- 民宿预约管理系统 - 数据库初始化脚本
-- MySQL 5.7.26
-- ============================================

CREATE DATABASE IF NOT EXISTS XRXRXR
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

USE XRXRXR;

-- ============================================
-- 1. 用户表
-- ============================================
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `password` VARCHAR(255) NOT NULL COMMENT 'BCrypt加密密码',
  `nickname` VARCHAR(50) DEFAULT NULL COMMENT '昵称',
  `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  `avatar` VARCHAR(255) DEFAULT NULL COMMENT '头像URL',
  `gender` TINYINT DEFAULT 0 COMMENT '0未知 1男 2女',
  `status` TINYINT DEFAULT 1 COMMENT '0禁用 1正常',
  `role` VARCHAR(100) DEFAULT 'user' COMMENT 'user,host,admin - comma separated',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_status` (`status`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ============================================
-- 2. 民宿表
-- ============================================
DROP TABLE IF EXISTS `homestay`;
CREATE TABLE `homestay` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` VARCHAR(100) NOT NULL COMMENT '民宿名称',
  `host_id` BIGINT NOT NULL COMMENT '房东用户ID',
  `province` VARCHAR(50) DEFAULT NULL COMMENT '省份',
  `city` VARCHAR(50) DEFAULT NULL COMMENT '城市',
  `district` VARCHAR(50) DEFAULT NULL COMMENT '区/县',
  `address` VARCHAR(255) DEFAULT NULL COMMENT '详细地址',
  `description` TEXT COMMENT '民宿描述',
  `cover_image` VARCHAR(255) DEFAULT NULL COMMENT '封面图片',
  `images` TEXT COMMENT '多张图片JSON数组',
  `facilities` VARCHAR(500) DEFAULT NULL COMMENT '设施服务',
  `check_in_time` VARCHAR(20) DEFAULT '14:00' COMMENT '入住时间',
  `check_out_time` VARCHAR(20) DEFAULT '12:00' COMMENT '退房时间',
  `status` TINYINT DEFAULT 0 COMMENT '0待审核 1已上架 2已下架',
  `rating` DECIMAL(2,1) DEFAULT 5.0 COMMENT '评分',
  `review_count` INT DEFAULT 0 COMMENT '评论数',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_city` (`city`),
  KEY `idx_status` (`status`),
  KEY `idx_host` (`host_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='民宿表';

-- ============================================
-- 3. 房间表
-- ============================================
DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `homestay_id` BIGINT NOT NULL COMMENT '民宿ID',
  `name` VARCHAR(100) NOT NULL COMMENT '房间名称',
  `description` VARCHAR(500) DEFAULT NULL COMMENT '房间描述',
  `image` VARCHAR(255) DEFAULT NULL COMMENT '房间图片',
  `price` DECIMAL(10,2) NOT NULL COMMENT '每晚价格',
  `total_count` INT DEFAULT 1 COMMENT '该房型总数量',
  `area` DECIMAL(6,2) DEFAULT NULL COMMENT '面积(平方米)',
  `bed_type` VARCHAR(50) DEFAULT NULL COMMENT '床型',
  `max_guests` INT DEFAULT 2 COMMENT '最大入住人数',
  `has_wifi` TINYINT DEFAULT 1 COMMENT 'WiFi',
  `has_tv` TINYINT DEFAULT 1 COMMENT '电视',
  `has_air_conditioner` TINYINT DEFAULT 1 COMMENT '空调',
  `has_private_bathroom` TINYINT DEFAULT 1 COMMENT '独立卫浴',
  `status` TINYINT DEFAULT 1 COMMENT '0禁用 1正常',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_homestay` (`homestay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间表';

-- ============================================
-- 4. 订单表
-- ============================================
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `order_no` VARCHAR(32) NOT NULL COMMENT '订单编号',
  `user_id` BIGINT NOT NULL COMMENT '下单用户ID',
  `homestay_id` BIGINT NOT NULL COMMENT '民宿ID',
  `room_id` BIGINT NOT NULL COMMENT '房型ID',
  `room_count` INT DEFAULT 1 COMMENT '预订房间数量',
  `guest_name` VARCHAR(50) DEFAULT NULL COMMENT '入住人姓名',
  `guest_phone` VARCHAR(20) DEFAULT NULL COMMENT '入住人手机号',
  `check_in_date` DATE NOT NULL COMMENT '入住日期',
  `check_out_date` DATE NOT NULL COMMENT '退房日期',
  `nights` INT NOT NULL COMMENT '入住晚数',
  `price_per_night` DECIMAL(10,2) DEFAULT NULL COMMENT '每晚单价',
  `total_amount` DECIMAL(10,2) NOT NULL COMMENT '总金额',
  `status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending/paid/confirmed/check_in/completed/canceled/refunded',
  `pay_method` VARCHAR(20) DEFAULT NULL COMMENT '支付方式',
  `pay_time` DATETIME DEFAULT NULL COMMENT '支付时间',
  `remark` VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user` (`user_id`),
  KEY `idx_homestay` (`homestay_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ============================================
-- 5. 评价表
-- ============================================
DROP TABLE IF EXISTS `review`;
CREATE TABLE `review` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `order_id` BIGINT NOT NULL COMMENT '订单ID',
  `homestay_id` BIGINT NOT NULL COMMENT '民宿ID',
  `room_id` BIGINT DEFAULT NULL COMMENT '房型ID',
  `rating` TINYINT NOT NULL COMMENT '综合评分 1-5',
  `cleanliness` TINYINT DEFAULT NULL COMMENT '清洁卫生 1-5',
  `location` TINYINT DEFAULT NULL COMMENT '地理位置 1-5',
  `service` TINYINT DEFAULT NULL COMMENT '服务态度 1-5',
  `facilities_score` TINYINT DEFAULT NULL COMMENT '设施条件 1-5',
  `content` TEXT COMMENT '评价内容',
  `images` VARCHAR(1000) DEFAULT NULL COMMENT '评价图片JSON数组',
  `reply` TEXT COMMENT '房东回复',
  `reply_time` DATETIME DEFAULT NULL COMMENT '回复时间',
  `status` TINYINT DEFAULT 1 COMMENT '0隐藏 1显示',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_homestay` (`homestay_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价表';

-- ============================================
-- 6. 收藏表
-- ============================================
DROP TABLE IF EXISTS `favorite`;
CREATE TABLE `favorite` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `homestay_id` BIGINT NOT NULL COMMENT '民宿ID',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_homestay` (`user_id`, `homestay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收藏表';

-- ============================================
-- 7. 通知/公告表
-- ============================================
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` VARCHAR(200) NOT NULL COMMENT '标题',
  `content` TEXT COMMENT '内容',
  `type` VARCHAR(20) DEFAULT 'system' COMMENT 'system/order',
  `target_user_id` BIGINT DEFAULT NULL COMMENT '目标用户 NULL=全体',
  `is_read` TINYINT DEFAULT 0 COMMENT '0未读 1已读',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表';

-- ============================================
-- 8. 轮播图表
-- ============================================
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` VARCHAR(100) DEFAULT NULL COMMENT '标题',
  `image_url` VARCHAR(255) NOT NULL COMMENT '图片URL',
  `link_url` VARCHAR(255) DEFAULT NULL COMMENT '链接URL',
  `sort_order` INT DEFAULT 0 COMMENT '排序',
  `status` TINYINT DEFAULT 1 COMMENT '0禁用 1启用',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轮播图表';

-- ============================================
-- 测试数据
-- 所有密码明文为: 123456
-- BCrypt密文: $2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi
-- ============================================

-- 管理员
INSERT INTO `user` (`username`, `password`, `nickname`, `phone`, `email`, `role`, `status`) VALUES
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '系统管理员', '13800000000', 'admin@homestay.com', 'admin', 1),
('admin2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '副管理员', '13800000001', 'admin2@homestay.com', 'admin', 1);

-- 房东
INSERT INTO `user` (`username`, `password`, `nickname`, `phone`, `email`, `role`, `status`) VALUES
('host_beijing', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '北京小院主人', '13900000001', 'host1@homestay.com', 'host', 1),
('host_dali', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '大理风花雪月', '13900000002', 'host2@homestay.com', 'host', 1),
('host_hangzhou', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '西湖边的家', '13900000003', 'host3@homestay.com', 'host', 1),
('host_chengdu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '成都慢生活', '13900000004', 'host4@homestay.com', 'host', 1),
('host_xiamen', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '厦门海风民宿', '13900000005', 'host5@homestay.com', 'host', 1);

-- 普通用户
INSERT INTO `user` (`username`, `password`, `nickname`, `phone`, `email`, `role`, `status`) VALUES
('zhangsan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '张三', '13600000001', 'zhangsan@qq.com', 'user', 1),
('lisi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '李四', '13600000002', 'lisi@qq.com', 'user', 1),
('wangwu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '王五', '13600000003', 'wangwu@qq.com', 'user', 1),
('zhaoliu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '赵六', '13600000004', 'zhaoliu@qq.com', 'user', 1),
('sunqi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '孙七', '13600000005', 'sunqi@qq.com', 'user', 1),
('zhouba', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '周八', '13600000006', 'zhouba@qq.com', 'user', 1),
('wujiu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '吴九', '13600000007', 'wujiu@qq.com', 'user', 1),
('zhengshi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '郑十', '13600000008', 'zhengshi@qq.com', 'user', 1),
('liuyi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '刘一', '13600000009', 'liuyi@qq.com', 'user', 1),
('chener', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '陈二', '13600000010', 'chener@qq.com', 'user', 1);

-- ============================================
-- 民宿测试数据 (host_id对应上面房东: 3=host_beijing, 4=host_dali, 5=host_hangzhou, 6=host_chengdu, 7=host_xiamen)
-- ============================================

INSERT INTO `homestay` (`name`, `host_id`, `province`, `city`, `district`, `address`, `description`, `cover_image`, `images`, `facilities`, `check_in_time`, `check_out_time`, `status`, `rating`, `review_count`) VALUES
-- 北京
('老北京胡同小院', 3, '北京市', '北京', '东城区', '南锣鼓巷32号', '位于北京核心胡同区，传统四合院改造，保留老北京味道的同时融入现代舒适设施。步行可达南锣鼓巷、鼓楼、什刹海。', 'https://picsum.photos/seed/homestay1/800/600', '["https://picsum.photos/seed/homestay1a/800/600","https://picsum.photos/seed/homestay1b/800/600","https://picsum.photos/seed/homestay1c/800/600"]', 'WiFi,空调,电视,洗衣机,厨房,暖气,独立卫浴', '14:00', '12:00', 1, 4.8, 126),
('长城脚下度假屋', 3, '北京市', '北京', '怀柔区', '渤海镇慕田峪村12号', '紧邻慕田峪长城，依山而建，每个房间都能欣赏到长城壮丽景色。提供烧烤设施和山景露台。', 'https://picsum.photos/seed/homestay2/800/600', '["https://picsum.photos/seed/homestay2a/800/600","https://picsum.photos/seed/homestay2b/800/600"]', 'WiFi,空调,电视,烧烤架,停车位,山景,露台', '14:00', '12:00', 1, 4.9, 89),
('望京SOHO国际公寓', 3, '北京市', '北京', '朝阳区', '望京街10号望京SOHO T1-2801', '位于望京核心商圈，高层观景公寓，俯瞰整个望京。现代化装修风格，步行可达地铁站。', 'https://picsum.photos/seed/homestay3/800/600', '["https://picsum.photos/seed/homestay3a/800/600","https://picsum.photos/seed/homestay3b/800/600"]', 'WiFi,空调,电视,洗衣机,健身房,停车场,电梯', '14:00', '12:00', 1, 4.6, 215),
('颐和园旁的禅意小院', 3, '北京市', '北京', '海淀区', '颐和园路55号', '距离颐和园步行5分钟，日式禅意风格设计，配有茶室和小型日式庭院，适合修身养性。', 'https://picsum.photos/seed/homestay4/800/600', '["https://picsum.photos/seed/homestay4a/800/600","https://picsum.photos/seed/homestay4b/800/600"]', 'WiFi,空调,茶室,庭院,暖气,独立卫浴', '15:00', '11:00', 1, 4.7, 67),

-- 大理
('洱海月海景民宿', 4, '云南省', '大理', '大理市', '大理古城洱海门往东800米', '直面洱海，180度无遮挡海景。每个房间配备观海阳台，躺在床上就能看洱海日出月升。', 'https://picsum.photos/seed/homestay5/800/600', '["https://picsum.photos/seed/homestay5a/800/600","https://picsum.photos/seed/homestay5b/800/600","https://picsum.photos/seed/homestay5c/800/600"]', 'WiFi,空调,海景阳台,接机服务,停车场,早餐', '14:00', '12:00', 1, 4.9, 308),
('大理古城白族小院', 4, '云南省', '大理', '大理市', '大理古城人民路128号', '位于大理古城人民路，典型的白族三坊一照壁建筑。院内花草繁茂，可以喝茶晒太阳感受大理慢时光。', 'https://picsum.photos/seed/homestay6/800/600', '["https://picsum.photos/seed/homestay6a/800/600","https://picsum.photos/seed/homestay6b/800/600"]', 'WiFi,空调,庭院,茶室,自行车,洗衣机', '14:00', '12:00', 1, 4.7, 189),
('苍山脚下的花园', 4, '云南省', '大理', '大理市', '苍山大道中和村66号', '背靠苍山，面朝洱海。占地2亩的花园民宿，四季鲜花盛开。提供苍山徒步向导服务。', 'https://picsum.photos/seed/homestay7/800/600', '["https://picsum.photos/seed/homestay7a/800/600","https://picsum.photos/seed/homestay7b/800/600"]', 'WiFi,空调,花园,停车场,早餐,接机服务', '14:00', '12:00', 1, 4.8, 142),
('双廊海景度假客栈', 4, '云南省', '大理', '大理市', '双廊镇大建旁村', '位于双廊核心位置，紧邻玉几岛。地中海风格建筑，无边泳池直面洱海，是拍照打卡的绝佳地点。', 'https://picsum.photos/seed/homestay8/800/600', '["https://picsum.photos/seed/homestay8a/800/600","https://picsum.photos/seed/homestay8b/800/600","https://picsum.photos/seed/homestay8c/800/600"]', 'WiFi,泳池,海景,空调,餐厅,停车场,接机服务', '14:00', '12:00', 1, 4.6, 276),

-- 杭州
('灵隐寺旁禅意民宿', 5, '浙江省', '杭州', '西湖区', '灵隐路白乐桥128号', '步行至灵隐寺仅需3分钟，被茶园和竹林环绕。日式榻榻米风格，提供素食早餐和抄经体验。', 'https://picsum.photos/seed/homestay9/800/600', '["https://picsum.photos/seed/homestay9a/800/600","https://picsum.photos/seed/homestay9b/800/600"]', 'WiFi,空调,茶室,素食早餐,庭院,书房', '15:00', '11:00', 1, 4.9, 198),
('西湖边的民国别墅', 5, '浙江省', '杭州', '上城区', '南山路198号', '建于1928年的民国别墅，紧邻西湖。修旧如旧保留了原有建筑风貌，内部设施现代舒适。', 'https://picsum.photos/seed/homestay10/800/600', '["https://picsum.photos/seed/homestay10a/800/600","https://picsum.photos/seed/homestay10b/800/600","https://picsum.photos/seed/homestay10c/800/600"]', 'WiFi,空调,电视,书房,花园,早餐', '14:00', '12:00', 1, 4.8, 156),
('满觉陇山景民宿', 5, '浙江省', '杭州', '西湖区', '满觉陇路15号', '位于满觉陇茶山之中，每年秋季桂花飘香。每个房间都有超大落地窗欣赏山景。', 'https://picsum.photos/seed/homestay11/800/600', '["https://picsum.photos/seed/homestay11a/800/600","https://picsum.photos/seed/homestay11b/800/600"]', 'WiFi,空调,山景阳台,茶室,停车场,早餐', '14:00', '12:00', 1, 4.7, 112),
('西溪湿地木屋', 5, '浙江省', '杭州', '余杭区', '西溪湿地公园旁', '坐落在西溪湿地旁，北欧风原木小屋，周围被绿树环绕。安静私密，适合情侣度假和家庭出游。', 'https://picsum.photos/seed/homestay12/800/600', '["https://picsum.photos/seed/homestay12a/800/600","https://picsum.photos/seed/homestay12b/800/600"]', 'WiFi,空调,厨房,烧烤架,停车位,花园', '14:00', '12:00', 1, 4.5, 87),

-- 成都
('宽窄巷子旁熊猫主题民宿', 6, '四川省', '成都', '青羊区', '宽窄巷子景区旁', '距宽窄巷子步行3分钟，以熊猫为主题的温馨民宿。每个房间都有独特的熊猫元素装饰，深受亲子家庭喜爱。', 'https://picsum.photos/seed/homestay13/800/600', '["https://picsum.photos/seed/homestay13a/800/600","https://picsum.photos/seed/homestay13b/800/600"]', 'WiFi,空调,电视,洗衣机,厨房,亲子设施', '14:00', '12:00', 1, 4.7, 203),
('锦里古街川西民居', 6, '四川省', '成都', '武侯区', '武侯祠大街231号', '紧邻锦里和武侯祠，川西民居风格建筑。提供正宗成都早餐，可以体验最地道的成都市井生活。', 'https://picsum.photos/seed/homestay14/800/600', '["https://picsum.photos/seed/homestay14a/800/600","https://picsum.photos/seed/homestay14b/800/600"]', 'WiFi,空调,电视,庭院,早餐,茶室', '14:00', '12:00', 1, 4.6, 178),
('都江堰山景温泉别墅', 6, '四川省', '成都', '都江堰市', '青城山路168号', '紧邻青城山景区，独立温泉别墅。每个别墅配备私汤温泉池，可以一边泡温泉一边欣赏青城山美景。', 'https://picsum.photos/seed/homestay15/800/600', '["https://picsum.photos/seed/homestay15a/800/600","https://picsum.photos/seed/homestay15b/800/600"]', 'WiFi,温泉,空调,停车场,山景,早餐', '15:00', '11:00', 1, 4.9, 145),
('太古里高空景观房', 6, '四川省', '成都', '锦江区', '红星路三段1号IFS国际金融中心', '位于成都IFS楼上，高空俯瞰太古里全景。现代轻奢装修风格，是购物和城市观光的理想下榻之地。', 'https://picsum.photos/seed/homestay16/800/600', '["https://picsum.photos/seed/homestay16a/800/600","https://picsum.photos/seed/homestay16b/800/600"]', 'WiFi,空调,电视,洗衣机,健身房,泳池,停车场', '14:00', '12:00', 1, 4.5, 234),

-- 厦门
('鼓浪屿老别墅', 7, '福建省', '厦门', '思明区', '鼓浪屿龙头路100号', '位于鼓浪屿核心区域，百年老别墅改造。复古欧式风格，自带花园和露台，推窗可见鼓浪屿红瓦绿树。', 'https://picsum.photos/seed/homestay17/800/600', '["https://picsum.photos/seed/homestay17a/800/600","https://picsum.photos/seed/homestay17b/800/600","https://picsum.photos/seed/homestay17c/800/600"]', 'WiFi,空调,花园,早餐,露台', '14:00', '12:00', 1, 4.8, 312),
('环岛路海景民宿', 7, '福建省', '厦门', '思明区', '环岛路曾厝垵88号', '位于环岛路黄金海岸线，出门就是沙滩。全景落地窗海景房，可以听着海浪声入眠。', 'https://picsum.photos/seed/homestay18/800/600', '["https://picsum.photos/seed/homestay18a/800/600","https://picsum.photos/seed/homestay18b/800/600"]', 'WiFi,空调,海景阳台,自行车,停车场,早餐', '14:00', '12:00', 1, 4.7, 267),
('沙坡尾文艺小屋', 7, '福建省', '厦门', '思明区', '大学路沙坡尾56号', '位于厦门最文艺的沙坡尾街区，充满艺术气息。附近咖啡馆、独立书店、手作工坊林立。', 'https://picsum.photos/seed/homestay19/800/600', '["https://picsum.photos/seed/homestay19a/800/600","https://picsum.photos/seed/homestay19b/800/600"]', 'WiFi,空调,电视,洗衣机,厨房', '14:00', '12:00', 1, 4.5, 156),
('集美学村海景公寓', 7, '福建省', '厦门', '集美区', '集美街道集美学村旁', '毗邻集美学村和龙舟池，嘉庚建筑风格。安静舒适，适合在厦门深度游的旅行者。', 'https://picsum.photos/seed/homestay20/800/600', '["https://picsum.photos/seed/homestay20a/800/600","https://picsum.photos/seed/homestay20b/800/600"]', 'WiFi,空调,电视,停车场', '14:00', '12:00', 1, 4.4, 98);

-- ============================================
-- 房型数据 (每个民宿2-4种房型)
-- ============================================

INSERT INTO `room` (`homestay_id`, `name`, `description`, `image`, `price`, `total_count`, `area`, `bed_type`, `max_guests`, `has_wifi`, `has_tv`, `has_air_conditioner`, `has_private_bathroom`, `status`) VALUES
-- 民宿1: 老北京胡同小院 (4种房型)
(1, '标准大床房', '温馨舒适的标准大床房，中式风格装修，配有1.8m大床', 'https://picsum.photos/seed/room1a/400/300', 288.00, 3, 20.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(1, '豪华套房', '带独立客厅的豪华套房，传统中式家具，提供茶具', 'https://picsum.photos/seed/room1b/400/300', 588.00, 2, 45.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(1, '双床家庭房', '适合家庭出游的双床房，配有两张1.5m床', 'https://picsum.photos/seed/room1c/400/300', 468.00, 2, 35.00, '双床1.5m', 4, 1, 1, 1, 1, 1),
(1, '胡同景观房', '位于二楼可俯瞰胡同景色的房间，清晨可听到鸟鸣', 'https://picsum.photos/seed/room1d/400/300', 388.00, 2, 25.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

-- 民宿2: 长城脚下度假屋 (3种房型)
(2, '山景大床房', '正对慕田峪长城，落地窗设计，足不出户赏长城', 'https://picsum.photos/seed/room2a/400/300', 688.00, 5, 30.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(2, '豪华露台套房', '带私人露台的套房，露台可直接看到长城', 'https://picsum.photos/seed/room2b/400/300', 988.00, 3, 50.00, '大床2.0m', 2, 1, 1, 1, 1, 1),
(2, '家庭连通房', '两间连通的大床房，适合家庭或朋友出行', 'https://picsum.photos/seed/room2c/400/300', 1288.00, 2, 65.00, '大床1.8m+大床1.5m', 6, 1, 1, 1, 1, 1),

-- 民宿3: 望京SOHO国际公寓 (2种房型)
(3, '城市景观大床房', '高层城市景观房，现代简约装修风格', 'https://picsum.photos/seed/room3a/400/300', 388.00, 8, 35.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(3, '商务套房', '带独立办公区的商务套房，适合出差人士', 'https://picsum.photos/seed/room3b/400/300', 588.00, 4, 55.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

-- 民宿4: 颐和园旁的禅意小院 (3种房型)
(4, '榻榻米禅意房', '纯日式榻榻米风格，简约宁静', 'https://picsum.photos/seed/room4a/400/300', 488.00, 3, 22.00, '榻榻米1.8m', 2, 1, 0, 1, 1, 1),
(4, '庭院景观房', '面向禅意庭院的房间，配有小型枯山水', 'https://picsum.photos/seed/room4b/400/300', 688.00, 2, 30.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(4, '茶室套房', '自带小型茶室的套房，提供茶道体验', 'https://picsum.photos/seed/room4c/400/300', 888.00, 2, 48.00, '大床1.8m', 2, 1, 0, 1, 1, 1),

-- 民宿5: 洱海月海景民宿 (4种房型)
(5, '海景大床房', '面朝洱海的大床房，带观海阳台', 'https://picsum.photos/seed/room5a/400/300', 468.00, 6, 28.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(5, '豪华海景套房', '超大空间海景套房，独立客厅+卧室，180度海景', 'https://picsum.photos/seed/room5b/400/300', 888.00, 3, 60.00, '大床2.0m', 2, 1, 1, 1, 1, 1),
(5, '海景家庭房', '亲子海景房，配有儿童小床', 'https://picsum.photos/seed/room5c/400/300', 688.00, 4, 45.00, '大床1.8m+儿童床', 3, 1, 1, 1, 1, 1),
(5, '星空海景阁楼', '顶层阁楼套房，天窗可看星空，阳台看洱海', 'https://picsum.photos/seed/room5d/400/300', 1088.00, 2, 55.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

-- 民宿6: 大理古城白族小院 (2种房型)
(6, '白族标准房', '白族风格装修的标准房间', 'https://picsum.photos/seed/room6a/400/300', 258.00, 4, 20.00, '大床1.5m', 2, 1, 1, 1, 1, 1),
(6, '白族景观套房', '二楼套房，可看古城和苍山', 'https://picsum.photos/seed/room6b/400/300', 398.00, 2, 38.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

-- 民宿7: 苍山脚下的花园 (3种房型)
(7, '花园景观房', '面向花园的房间，大落地窗采光极好', 'https://picsum.photos/seed/room7a/400/300', 368.00, 4, 25.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(7, '花园复式套房', '复式结构套房，楼下客厅楼上卧室', 'https://picsum.photos/seed/room7b/400/300', 668.00, 2, 50.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(7, '独立木屋别墅', '花园深处的独立木屋，私密性好', 'https://picsum.photos/seed/room7c/400/300', 888.00, 1, 60.00, '大床2.0m', 2, 1, 1, 1, 1, 1),

-- 民宿8: 双廊海景度假客栈 (3种房型)
(8, '泳池景观房', '面向无边泳池和洱海的房间', 'https://picsum.photos/seed/room8a/400/300', 588.00, 5, 30.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(8, '亲水泳池套房', '一楼直通泳池的豪华套房', 'https://picsum.photos/seed/room8b/400/300', 988.00, 3, 55.00, '大床2.0m', 2, 1, 1, 1, 1, 1),
(8, '全景海景套房', '顶楼全景套房，360度无死角海景', 'https://picsum.photos/seed/room8c/400/300', 1288.00, 2, 70.00, '大床2.0m', 2, 1, 1, 1, 1, 1),

-- 民宿9: 灵隐寺旁禅意民宿 (2种房型)
(9, '禅修榻榻米房', '日式榻榻米风格，简约禅意空间', 'https://picsum.photos/seed/room9a/400/300', 588.00, 4, 25.00, '榻榻米1.8m', 2, 1, 0, 1, 1, 1),
(9, '竹林景观套房', '正对竹林的套房，带小型禅修空间', 'https://picsum.photos/seed/room9b/400/300', 888.00, 2, 45.00, '大床1.8m', 2, 1, 0, 1, 1, 1),

-- 民宿10: 西湖边的民国别墅 (3种房型)
(10, '民国风标准房', '保留民国风格的精致标准房', 'https://picsum.photos/seed/room10a/400/300', 688.00, 3, 25.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(10, '西湖景观套房', '二楼可看到西湖的套房', 'https://picsum.photos/seed/room10b/400/300', 1288.00, 2, 50.00, '大床2.0m', 2, 1, 1, 1, 1, 1),
(10, '花园阳台房', '带独立阳台和花园景观', 'https://picsum.photos/seed/room10c/400/300', 888.00, 2, 35.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

-- 民宿11-20的房型 (简化)
(11, '山景大床房', '满觉陇山景大床房', 'https://picsum.photos/seed/room11a/400/300', 388.00, 5, 28.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(11, '全景露台房', '带超大露台的全景房', 'https://picsum.photos/seed/room11b/400/300', 688.00, 3, 40.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

(12, '森林木屋', '独立木屋，北欧风格', 'https://picsum.photos/seed/room12a/400/300', 488.00, 4, 35.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(12, '树屋套房', '建在树上的特色树屋', 'https://picsum.photos/seed/room12b/400/300', 788.00, 2, 30.00, '大床1.8m', 2, 1, 0, 1, 1, 1),

(13, '熊猫主题房', '满屋熊猫元素的亲子房', 'https://picsum.photos/seed/room13a/400/300', 338.00, 4, 22.00, '大床1.8m+儿童床', 3, 1, 1, 1, 1, 1),
(13, '熊猫豪华套房', '带熊猫玩偶和主题装饰的套房', 'https://picsum.photos/seed/room13b/400/300', 538.00, 2, 42.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

(14, '川西标准房', '川西民居风格标准间', 'https://picsum.photos/seed/room14a/400/300', 288.00, 5, 20.00, '大床1.5m', 2, 1, 1, 1, 1, 1),
(14, '川西套房', '带独立客厅的川西风格套房', 'https://picsum.photos/seed/room14b/400/300', 488.00, 3, 42.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

(15, '温泉别墅(一居)', '一居室温泉别墅，私人温泉池', 'https://picsum.photos/seed/room15a/400/300', 988.00, 3, 80.00, '大床2.0m', 2, 1, 1, 1, 1, 1),
(15, '温泉别墅(二居)', '两居室温泉别墅，适合家庭', 'https://picsum.photos/seed/room15b/400/300', 1688.00, 2, 120.00, '大床2.0m+双床1.5m', 6, 1, 1, 1, 1, 1),

(16, '城市景观房', 'IFS高空景观大床房', 'https://picsum.photos/seed/room16a/400/300', 588.00, 6, 35.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(16, '行政套房', '高层行政套房，带办公区', 'https://picsum.photos/seed/room16b/400/300', 988.00, 3, 65.00, '大床2.0m', 2, 1, 1, 1, 1, 1),

(17, '鼓浪屿标准房', '复古欧式风格标准间', 'https://picsum.photos/seed/room17a/400/300', 488.00, 4, 22.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(17, '花园露台套房', '带私人花园露台的套房', 'https://picsum.photos/seed/room17b/400/300', 888.00, 2, 48.00, '大床2.0m', 2, 1, 1, 1, 1, 1),

(18, '海景大床房', '环岛路一线海景大床房', 'https://picsum.photos/seed/room18a/400/300', 468.00, 6, 28.00, '大床1.8m', 2, 1, 1, 1, 1, 1),
(18, '豪华海景套房', '180度海景套房', 'https://picsum.photos/seed/room18b/400/300', 868.00, 3, 50.00, '大床2.0m', 2, 1, 1, 1, 1, 1),

(19, '文艺单人房', '精致单人房，文艺范', 'https://picsum.photos/seed/room19a/400/300', 228.00, 3, 15.00, '单人床1.5m', 1, 1, 1, 1, 1, 1),
(19, '文艺大床房', '宽敞文艺风格大床房', 'https://picsum.photos/seed/room19b/400/300', 368.00, 4, 25.00, '大床1.8m', 2, 1, 1, 1, 1, 1),

(20, '标准双床房', '集美学村标准双床房', 'https://picsum.photos/seed/room20a/400/300', 258.00, 4, 22.00, '双床1.5m', 2, 1, 1, 1, 1, 1),
(20, '海景大床房', '集美海景大床房', 'https://picsum.photos/seed/room20b/400/300', 388.00, 3, 28.00, '大床1.8m', 2, 1, 1, 1, 1, 1);

-- ============================================
-- 轮播图测试数据
-- ============================================
INSERT INTO `banner` (`title`, `image_url`, `link_url`, `sort_order`, `status`) VALUES
('探索北京胡同民宿', 'https://picsum.photos/seed/banner1/1200/400', '/homestay/1', 1, 1),
('大理洱海海景民宿', 'https://picsum.photos/seed/banner2/1200/400', '/homestay/5', 2, 1),
('西湖边民国风情', 'https://picsum.photos/seed/banner3/1200/400', '/homestay/10', 3, 1),
('成都慢生活体验', 'https://picsum.photos/seed/banner4/1200/400', '/homestay/13', 4, 1),
('厦门鼓浪屿之旅', 'https://picsum.photos/seed/banner5/1200/400', '/homestay/17', 5, 1);

-- ============================================
-- 系统通知测试数据
-- ============================================
INSERT INTO `notice` (`title`, `content`, `type`, `target_user_id`, `is_read`) VALUES
('欢迎使用民宿预约管理系统', '欢迎来到民宿预约管理系统！在这里您可以发现全国各地的精品民宿，享受独特的旅行体验。', 'system', NULL, 0),
('系统上线公告', '民宿预约管理系统V1.0正式上线！我们为您精选了北京、大理、杭州、成都、厦门等热门旅游城市的精品民宿。', 'system', NULL, 0),
('新增点评功能', '现在您可以在完成入住后对所住民宿进行评价，帮助更多旅行者做出选择！', 'system', NULL, 0);

-- ============================================
-- 评价测试数据 (userId: 8=zhangsan, 9=lisi, 10=wangwu, 11=zhaoliu, 12=sunqi)
-- roomId对应实际房型
-- ============================================
INSERT INTO `review` (`user_id`, `order_id`, `homestay_id`, `room_id`, `rating`, `cleanliness`, `location`, `service`, `facilities_score`, `content`, `status`, `create_time`) VALUES
-- 民宿1 老北京胡同小院 房间评价
(8, 1, 1, 1, 5, 5, 5, 5, 5, '标准大床房非常温馨，中式装修很有味道，床品舒适，卫生一尘不染！', 1, '2026-05-15 10:30:00'),
(9, 2, 1, 2, 5, 5, 4, 5, 5, '豪华套房空间很大，独立客厅适合会客，传统家具很有质感。', 1, '2026-05-10 14:20:00'),
(10, 3, 1, 1, 4, 5, 5, 4, 5, '位置绝佳，出门就是南锣鼓巷，早餐也很可口。房间略小但温馨。', 1, '2026-04-28 09:15:00'),
(11, 4, 1, 4, 5, 5, 5, 5, 4, '胡同景观房太棒了，清晨能听到鸟鸣，仿佛回到了老北京。', 1, '2026-04-20 16:45:00'),

-- 民宿5 洱海月海景民宿 房间评价
(8, 5, 5, 17, 5, 5, 5, 5, 5, '海景大床房直面洱海，躺在床上就能看日出，太震撼了！', 1, '2026-06-01 07:30:00'),
(12, 6, 5, 19, 5, 4, 5, 5, 5, '星空海景阁楼美得不像话，晚上看星星白天看洱海，完美度假。', 1, '2026-05-25 20:10:00'),
(9, 7, 5, 18, 5, 5, 5, 5, 5, '豪华海景套房空间超大，180度海景无死角，还会再来！', 1, '2026-05-18 11:00:00'),

-- 民宿10 西湖边民国别墅 房间评价
(10, 8, 10, 38, 5, 5, 5, 5, 5, '西湖景观套房窗外就是西湖，民国风情浓郁，非常有格调。', 1, '2026-05-30 15:30:00'),
(8, 9, 10, 37, 5, 5, 5, 5, 4, '民国风标准房很有味道，保留了历史建筑的原貌，设施也很现代。', 1, '2026-05-22 12:00:00'),

-- 民宿13 宽窄巷子熊猫主题 房间评价
(11, 10, 13, 45, 5, 5, 5, 5, 5, '熊猫主题房孩子超喜欢！到处都是熊猫元素，亲子游强烈推荐。', 1, '2026-06-02 16:00:00'),
(12, 11, 13, 46, 4, 5, 5, 4, 5, '熊猫豪华套房很精致，宽窄巷子步行可达，位置极佳。', 1, '2026-05-28 13:45:00'),

-- 民宿17 鼓浪屿老别墅 房间评价
(9, 12, 17, 49, 5, 5, 5, 5, 5, '花园露台套房太浪漫了！坐在露台上喝咖啡看鼓浪屿街景。', 1, '2026-05-20 10:00:00'),
(10, 13, 17, 48, 4, 4, 5, 5, 4, '鼓浪屿标准房复古欧式风格独特，就是卫生间稍小。', 1, '2026-05-15 17:20:00');
