import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/', redirect: '/login' },
  {
    path: '/home',
    component: () => import('@/layout/DefaultLayout.vue'),
    children: [
      { path: '', name: 'Home', component: () => import('@/views/home/HomeView.vue'), meta: { title: '首页' } },
      { path: 'homestay/list', name: 'HomestayList', component: () => import('@/views/homestay/HomestayListView.vue'), meta: { title: '民宿列表' } },
      { path: 'homestay/:id', name: 'HomestayDetail', component: () => import('@/views/homestay/HomestayDetailView.vue'), meta: { title: '民宿详情' } },
      { path: 'order/list', name: 'OrderList', component: () => import('@/views/order/OrderListView.vue'), meta: { title: '我的订单', requiresAuth: true } },
      { path: 'order/:id', name: 'OrderDetail', component: () => import('@/views/order/OrderDetailView.vue'), meta: { title: '订单详情', requiresAuth: true } },
      { path: 'order/pay/:id', name: 'Payment', component: () => import('@/views/order/PaymentView.vue'), meta: { title: '支付', requiresAuth: true } },
      { path: 'user/profile', name: 'UserProfile', component: () => import('@/views/user/ProfileView.vue'), meta: { title: '个人中心', requiresAuth: true } },
      { path: 'user/favorites', name: 'MyFavorites', component: () => import('@/views/user/MyFavorites.vue'), meta: { title: '我的收藏', requiresAuth: true } },
      { path: 'user/reviews', name: 'MyReviews', component: () => import('@/views/user/MyReviews.vue'), meta: { title: '我的评价', requiresAuth: true } }
    ]
  },
  { path: '/login', name: 'Login', component: () => import('@/views/login/LoginView.vue'), meta: { title: '登录' } },
  { path: '/register', name: 'Register', component: () => import('@/views/login/RegisterView.vue'), meta: { title: '注册' } },

  // ── 房东中心 ──
  {
    path: '/host',
    component: () => import('@/layout/HostLayout.vue'),
    meta: { requiresAuth: true, role: 'host' },
    children: [
      { path: '', name: 'HostDashboard', component: () => import('@/views/host/HostDashboard.vue'), meta: { title: '房东中心' } },
      { path: 'homestays', name: 'MyHomestays', component: () => import('@/views/host/MyHomestayList.vue'), meta: { title: '我的民宿' } },
      { path: 'homestay/add', name: 'AddHomestay', component: () => import('@/views/host/HomestayForm.vue'), meta: { title: '添加民宿' } },
      { path: 'homestay/edit/:id', name: 'EditHomestay', component: () => import('@/views/host/HomestayForm.vue'), meta: { title: '编辑民宿' } },
      { path: 'homestay/:id/rooms', name: 'RoomManage', component: () => import('@/views/host/RoomManage.vue'), meta: { title: '房型管理' } },
      { path: 'orders', name: 'HostOrders', component: () => import('@/views/host/OrderManage.vue'), meta: { title: '订单管理' } },
      { path: 'revenue', name: 'Revenue', component: () => import('@/views/host/RevenueReport.vue'), meta: { title: '收益报表' } }
    ]
  },

  // ── 管理后台 ──
  {
    path: '/admin',
    component: () => import('@/layout/AdminLayout.vue'),
    meta: { requiresAuth: true, role: 'admin' },
    children: [
      { path: '', name: 'AdminDashboard', component: () => import('@/views/admin/Dashboard.vue'), meta: { title: '管理后台' } },
      { path: 'users', name: 'UserManage', component: () => import('@/views/admin/UserManage.vue'), meta: { title: '用户管理' } },
      { path: 'config', name: 'SystemConfig', component: () => import('@/views/admin/SystemConfig.vue'), meta: { title: '系统配置' } },
      { path: 'logs', name: 'OperationLogs', component: () => import('@/views/admin/OperationLogs.vue'), meta: { title: '操作日志' } },
      { path: 'homestays', name: 'HomestayAudit', component: () => import('@/views/admin/HomestayAudit.vue'), meta: { title: '民宿审核' } },
      { path: 'orders', name: 'AdminOrders', component: () => import('@/views/admin/OrderManage.vue'), meta: { title: '订单管理' } },
      { path: 'reviews', name: 'ReviewManage', component: () => import('@/views/admin/ReviewManage.vue'), meta: { title: '评价管理' } },
      { path: 'banners', name: 'BannerManage', component: () => import('@/views/admin/BannerManage.vue'), meta: { title: 'Banner管理' } },
      { path: 'notices', name: 'NoticeManage', component: () => import('@/views/admin/NoticeManage.vue'), meta: { title: '公告管理' } },
      { path: 'statistics', name: 'Statistics', component: () => import('@/views/admin/Statistics.vue'), meta: { title: '数据统计' } }
    ]
  },

  { path: '/:pathMatch(.*)*', name: 'NotFound', component: () => import('@/views/error/NotFound.vue'), meta: { title: '404' } }
]

const router = createRouter({ history: createWebHistory(), routes, scrollBehavior() { return { top: 0 } } })

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}')

  if (to.meta.requiresAuth && !token) {
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }

  // 管理员禁止访问普通用户功能页（收藏、评价、订单）
  if (token) {
    const roles = (userInfo.role || 'user').split(',').map(s => s.trim())
    const adminBlocked = ['/user/favorites', '/user/reviews', '/order/list', '/order/pay']
    if (roles.includes('admin') && adminBlocked.some(p => to.path.startsWith(p))) {
      next('/admin')
      return
    }
  }

  if ((to.path === '/login' || to.path === '/register') && token) {
    const roles = (userInfo.role || 'user').split(',').map(s => s.trim())
    if (roles.includes('admin')) next('/admin')
    else if (roles.includes('host')) next('/host')
    else next('/home')
    return
  }

  if (to.meta.role) {
    const roles = (userInfo.role || 'user').split(',').map(s => s.trim())
    if (!roles.includes(to.meta.role) && !roles.includes('admin')) {
      next('/home')
      return
    }
  }

  next()
})

export default router
