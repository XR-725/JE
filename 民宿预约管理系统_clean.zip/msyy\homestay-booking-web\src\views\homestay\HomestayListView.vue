<template>
  <div class="list-page">
    <div class="page-container">
      <!-- 搜索横幅 -->
      <div class="search-hero">
        <h1 class="search-hero-title">{{ pageTitle }}</h1>
        <div class="search-bar">
          <el-input
            v-model="searchParams.keyword"
            placeholder="搜索民宿名称、地址..."
            :prefix-icon="Search"
            size="large"
            clearable
            @change="search"
            @clear="search"
            class="search-input"
          />
        </div>
      </div>

      <div class="list-layout">
        <!-- 筛选栏 -->
        <aside class="filter-panel">
          <div class="filter-card">
            <div class="filter-group">
              <h4>城市</h4>
              <el-select v-model="searchParams.city" placeholder="全部城市" clearable @change="search" style="width:100%">
                <el-option v-for="c in cities" :key="c" :label="c" :value="c" />
              </el-select>
            </div>
            <div class="filter-group">
              <h4>排序</h4>
              <div class="sort-options">
                <button
                  v-for="s in sortOptions"
                  :key="s.value"
                  class="sort-btn"
                  :class="{ 'sort-btn--active': searchParams.sortBy === s.value }"
                  @click="searchParams.sortBy = s.value; search()"
                >
                  {{ s.label }}
                </button>
              </div>
            </div>
            <el-button class="filter-reset" @click="resetSearch" text>
              <el-icon><Refresh /></el-icon>重置筛选
            </el-button>
          </div>
        </aside>

        <!-- 列表 -->
        <div class="list-content">
          <!-- 加载骨架屏 -->
          <el-row :gutter="20" v-if="loading">
            <el-col v-for="n in 6" :key="n" :xs="24" :sm="12" :md="8">
              <div class="card-skeleton">
                <div class="skeleton card-skeleton-img"></div>
                <div class="card-skeleton-body">
                  <div class="skeleton skeleton-text" style="width:70%"></div>
                  <div class="skeleton skeleton-text" style="width:50%;margin-top:8px"></div>
                  <div class="skeleton skeleton-text" style="width:40%;margin-top:8px"></div>
                </div>
              </div>
            </el-col>
          </el-row>

          <!-- 结果 -->
          <el-row :gutter="20" v-else-if="list.length">
            <el-col v-for="item in list" :key="item.id" :xs="24" :sm="12" :md="8" :lg="6">
              <HomestayCard :homestay="item" :is-favorited="!!favoriteStatus[item.id]" />
            </el-col>
          </el-row>

          <!-- 空状态 -->
          <div v-else class="empty-state">
            <el-icon :size="56"><Search /></el-icon>
            <h3>暂无符合条件的民宿</h3>
            <p>试试调整筛选条件或搜索关键词</p>
            <el-button type="primary" @click="resetSearch">重置搜索</el-button>
          </div>

          <!-- 分页 -->
          <div class="pagination-wrap" v-if="total > size">
            <el-pagination
              v-model:current-page="page"
              :page-size="size"
              :total="total"
              layout="prev, pager, next, total"
              background
              @current-change="fetchList"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { Search, Refresh } from '@element-plus/icons-vue'
import { getHomestayList, checkFavorite } from '@/api/homestay'
import { useUserStore } from '@/stores/user'
import HomestayCard from '@/components/HomestayCard.vue'

const route = useRoute()
const userStore = useUserStore()
const cities = ref(['北京', '杭州', '大理', '成都', '厦门', '丽江', '三亚', '西安', '苏州', '青岛'])
const list = ref([])
const loading = ref(true)
const page = ref(1)
const size = ref(12)
const total = ref(0)
const favoriteStatus = ref({})

const searchParams = reactive({ keyword: '', city: '', sortBy: 'default' })

const sortOptions = [
  { label: '综合', value: 'default' },
  { label: '价格 ↑', value: 'price_asc' },
  { label: '价格 ↓', value: 'price_desc' },
  { label: '评分', value: 'rating' }
]

const pageTitle = computed(() => {
  const parts = []
  if (searchParams.keyword) parts.push(`"${searchParams.keyword}"`)
  if (searchParams.city) parts.push(searchParams.city)
  return parts.length ? `搜索结果: ${parts.join(' · ')}` : '全部民宿'
})

const search = () => { page.value = 1; fetchList() }

const resetSearch = () => {
  searchParams.keyword = ''
  searchParams.city = ''
  searchParams.sortBy = 'default'
  search()
}

const fetchList = async () => {
  loading.value = true
  try {
    const res = await getHomestayList({
      page: page.value,
      size: size.value,
      keyword: searchParams.keyword || undefined,
      city: searchParams.city || undefined,
      sortBy: searchParams.sortBy
    })
    list.value = res.data.records || []
    total.value = res.data.total || 0
    // Batch check favorite status
    favoriteStatus.value = {}
    if (userStore.isLoggedIn && list.value.length) {
      for (const item of list.value) {
        try {
          const favRes = await checkFavorite(item.id)
          favoriteStatus.value[item.id] = favRes.data || false
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) {
    list.value = []
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  if (route.query.keyword) searchParams.keyword = route.query.keyword
  if (route.query.city) searchParams.city = route.query.city
  if (route.query.sortBy) searchParams.sortBy = route.query.sortBy
  fetchList()
})

watch(() => route.query, () => {
  if (route.query.keyword) searchParams.keyword = route.query.keyword
  if (route.query.city) searchParams.city = route.query.city
  if (route.query.sortBy) searchParams.sortBy = route.query.sortBy
  fetchList()
})
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables' as *;

.list-page {
  background: $color-bg;
  min-height: calc(100vh - #{$header-height} - 200px);
}

.page-container {
  max-width: $max-width;
  margin: 0 auto;
  padding: $spacing-xl $spacing-xl;
}

// ── 搜索横幅 ──
.search-hero {
  background: linear-gradient(135deg, $color-primary-lighter 0%, $color-bg 100%);
  border-radius: $radius-lg;
  padding: $spacing-2xl $spacing-3xl;
  margin-bottom: $spacing-xl;
}

.search-hero-title {
  font-size: $font-size-2xl;
  font-weight: $font-weight-bold;
  color: $color-text-primary;
  margin: 0 0 $spacing-lg;
}

.search-bar {
  max-width: 480px;

  .search-input {
    :deep(.el-input__wrapper) {
      background: $color-surface;
      border-radius: $radius-base;
      box-shadow: $shadow-sm;
    }
  }
}

// ── 列表布局 ──
.list-layout {
  display: flex;
  gap: 24px;
  align-items: flex-start;
}

// ── 筛选面板 ──
.filter-panel {
  width: 220px;
  flex-shrink: 0;
  position: sticky;
  top: 84px;
}

.filter-card {
  background: $color-surface;
  border: 1px solid $color-border-light;
  border-radius: $radius-md;
  padding: $spacing-xl;

  .filter-group {
    margin-bottom: $spacing-xl;

    h4 {
      font-size: $font-size-sm;
      font-weight: $font-weight-semibold;
      color: $color-text-primary;
      margin: 0 0 $spacing-md;
    }
  }
}

.sort-options {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.sort-btn {
  width: 100%;
  padding: 8px 12px;
  border: none;
  background: none;
  border-radius: $radius-sm;
  font-size: $font-size-sm;
  color: $color-text-regular;
  cursor: pointer;
  text-align: left;
  transition: all $transition-fast;

  &:hover {
    background: $color-bg-alt;
    color: $color-primary;
  }

  &--active {
    background: $color-primary-lighter;
    color: $color-primary;
    font-weight: $font-weight-semibold;
  }
}

.filter-reset {
  width: 100%;
  color: $color-text-secondary;
  font-size: $font-size-sm;
}

.list-content {
  flex: 1;
  min-width: 0;
}

// ── 骨架屏 ──
.card-skeleton {
  background: $color-surface;
  border-radius: $radius-md;
  overflow: hidden;
  margin-bottom: $spacing-xl;

  .card-skeleton-img { height: 200px; border-radius: 0; }
  .card-skeleton-body { padding: $spacing-base; }
  .skeleton-text { height: 14px; border-radius: 4px; }
}

// ── 空状态 ──
.empty-state {
  text-align: center;
  padding: 80px 0;
  color: $color-text-secondary;

  h3 { margin: 16px 0 8px; font-size: $font-size-lg; }
  p { margin: 0 0 20px; font-size: $font-size-base; }
}

// ── 分页 ──
.pagination-wrap {
  text-align: center;
  margin-top: $spacing-2xl;
}

// ── 响应式 ──
@media (max-width: 768px) {
  .list-layout { flex-direction: column; }
  .filter-panel { width: 100%; position: static; }
  .filter-card { display: flex; gap: 16px; align-items: center; flex-wrap: wrap;
    .filter-group { margin-bottom: 0; }
  }
  .sort-options { flex-direction: row; }
}
</style>
