<template>
  <div class="admin-page">
    <div class="page-header">
      <h3>{{ title }}</h3>
      <el-button type="primary" @click="openDialog()">新增Banner</el-button>
    </div>
    <el-card>
      <el-table :data="list" border stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="图片" width="160">
          <template #default="{ row }"><el-image :src="row.imageUrl" fit="cover" style="width:140px;height:50px;border-radius:4px" /></template>
        </el-table-column>
        <el-table-column prop="title" label="标题" width="200" />
        <el-table-column prop="sortOrder" label="排序" width="80" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }"><el-tag :type="row.status === 1 ? 'success' : 'info'" size="small">{{ row.status === 1 ? '启用' : '禁用' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openDialog(row)">编辑</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="editingBanner?.id ? '编辑Banner' : '新增Banner'" width="560px">
      <el-form :model="form" label-width="80px">
        <el-form-item label="标题"><el-input v-model="form.title" /></el-form-item>
        <el-form-item label="图片">
          <div class="banner-upload-area">
            <div v-if="form.imageUrl" class="banner-preview-wrap">
              <el-image :src="form.imageUrl" fit="cover" class="banner-preview" :preview-src-list="[form.imageUrl]" />
              <el-button type="danger" plain size="small" @click="form.imageUrl = ''">
                <el-icon><Delete /></el-icon>移除
              </el-button>
            </div>
            <el-upload
              v-else
              class="banner-uploader"
              :http-request="handleBannerUpload"
              :show-file-list="false"
            >
              <div class="upload-placeholder">
                <el-icon class="upload-icon"><Plus /></el-icon>
                <span>上传图片</span>
              </div>
            </el-upload>
          </div>
          <div class="upload-tip">建议尺寸 1920×600，不超过 10MB</div>
        </el-form-item>
        <el-form-item label="排序"><el-input-number v-model="form.sortOrder" :min="0" /></el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.status" :active-value="1" :inactive-value="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus, Delete } from '@element-plus/icons-vue'
import { getAdminBanners, addBanner, updateBanner, deleteBanner } from '@/api/admin'
import { uploadFile } from '@/api/common'

defineProps({ title: { type: String, default: 'Banner管理' } })

const list = ref([])
const dialogVisible = ref(false)
const editingBanner = ref(null)
const saving = ref(false)

const form = reactive({
  title: '', imageUrl: '', sortOrder: 0, status: 1
})

const beforeUpload = () => {
  return true
}

const handleBannerUpload = async (options) => {
  const fd = new FormData()
  fd.append('file', options.file)
  try {
    const res = await uploadFile(fd)
    form.imageUrl = res.data
    ElMessage.success('图片上传成功')
  } catch {
    // request.js 拦截器已弹窗提示，此处不再重复
  }
}

const fetchData = async () => {
  const res = await getAdminBanners()
  list.value = res.data || []
}

const openDialog = (row) => {
  editingBanner.value = row || null
  if (row) Object.assign(form, row)
  else Object.assign(form, { title: '', imageUrl: '', sortOrder: 0, status: 1 })
  dialogVisible.value = true
}

const handleSave = async () => {
  saving.value = true
  try {
    if (editingBanner.value?.id) {
      await updateBanner(editingBanner.value.id, { ...form })
    } else {
      await addBanner({ ...form })
    }
    ElMessage.success('保存成功')
    dialogVisible.value = false
    fetchData()
  } catch (e) {} finally { saving.value = false }
}

const handleDelete = async (id) => {
  await deleteBanner(id)
  ElMessage.success('删除成功')
  fetchData()
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; }

.banner-upload-area { display: flex; flex-direction: column; gap: 8px; }
.banner-preview-wrap {
  display: flex; flex-direction: column; gap: 8px; align-items: flex-start;
  .banner-preview { width: 360px; height: 120px; border-radius: 8px; display: block; }
}

.upload-placeholder {
  width: 360px; height: 120px; border: 1px dashed #d9d9d9; border-radius: 8px;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 6px; cursor: pointer; color: #8c939d; font-size: 13px;
  transition: border-color .2s, color .2s;
  &:hover { border-color: #409eff; color: #409eff; }
  .upload-icon { font-size: 28px; }
}

.upload-tip { font-size: 12px; color: #909399; margin-top: 4px; }
</style>
