<template>
  <div class="admin-page">
    <div class="page-header">
      <h3>{{ title }}</h3>
      <el-button type="primary" @click="openDialog()">发布公告</el-button>
    </div>
    <el-card>
      <el-table :data="list" border stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="title" label="标题" min-width="200" />
        <el-table-column prop="type" label="类型" width="100" />
        <el-table-column prop="createTime" label="发布时间" width="160" />
        <el-table-column prop="content" label="内容" min-width="300" show-overflow-tooltip />
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="openDialog(row)">编辑</el-button>
            <el-button type="danger" link @click="handleDelete(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="editingId ? '编辑公告' : '发布公告'" width="500px">
      <el-form :model="form" label-width="80px">
        <el-form-item label="标题"><el-input v-model="form.title" /></el-form-item>
        <el-form-item label="类型">
          <el-select v-model="form.type">
            <el-option label="系统公告" value="system" />
            <el-option label="订单通知" value="order" />
          </el-select>
        </el-form-item>
        <el-form-item label="内容"><el-input v-model="form.content" type="textarea" :rows="4" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">发布</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getAdminNotices, addNotice, updateNotice, deleteNotice } from '@/api/admin'

defineProps({ title: { type: String, default: '公告管理' } })

const list = ref([])
const dialogVisible = ref(false)
const saving = ref(false)
const editingId = ref(null)

const form = reactive({ title: '', content: '', type: 'system' })

const fetchData = async () => {
  const res = await getAdminNotices()
  list.value = res.data || []
}

const openDialog = (row) => {
  if (row && row.id) {
    editingId.value = row.id
    Object.assign(form, { title: row.title, content: row.content, type: row.type })
  } else {
    editingId.value = null
    Object.assign(form, { title: '', content: '', type: 'system' })
  }
  dialogVisible.value = true
}

const handleSave = async () => {
  saving.value = true
  try {
    if (editingId.value) {
      await updateNotice(editingId.value, { ...form })
      ElMessage.success('更新成功')
    } else {
      await addNotice({ ...form })
      ElMessage.success('发布成功')
    }
    dialogVisible.value = false
    fetchData()
  } catch (e) {} finally { saving.value = false }
}

const handleDelete = async (id) => {
  try {
    await ElMessageBox.confirm('确定要删除该公告吗？', '确认删除', { type: 'warning' })
    await deleteNotice(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (e) {}
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; }
</style>
