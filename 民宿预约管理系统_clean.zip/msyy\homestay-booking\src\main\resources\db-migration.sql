-- 系统配置表
CREATE TABLE IF NOT EXISTS `system_config` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `config_key` VARCHAR(100) NOT NULL COMMENT '配置键',
  `config_value` TEXT COMMENT '配置值',
  `description` VARCHAR(200) COMMENT '描述',
  `category` VARCHAR(50) DEFAULT 'general' COMMENT '分类',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

-- 插入默认配置
INSERT IGNORE INTO `system_config` (`config_key`, `config_value`, `description`, `category`) VALUES
('site_name', '民宿预约管理系统', '站点名称', 'general'),
('site_description', '专业的民宿在线预约平台', '站点描述', 'general'),
('contact_email', 'admin@homestay.com', '联系邮箱', 'general'),
('contact_phone', '400-000-0000', '联系电话', 'general'),
('commission_rate', '10', '平台佣金比例(%)', 'business'),
('min_withdraw_amount', '100', '最低提现金额(元)', 'business'),
('auto_confirm_hours', '24', '自动确认订单(小时)', 'business'),
('max_homestay_images', '9', '民宿最大图片数', 'business');

-- 操作日志表
CREATE TABLE IF NOT EXISTS `operation_log` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` BIGINT COMMENT '操作用户ID',
  `username` VARCHAR(50) COMMENT '用户名',
  `operation` VARCHAR(200) COMMENT '操作描述',
  `method` VARCHAR(200) COMMENT '请求方法',
  `params` TEXT COMMENT '请求参数',
  `ip` VARCHAR(50) COMMENT 'IP地址',
  `duration` BIGINT DEFAULT 0 COMMENT '耗时(ms)',
  `success` TINYINT(1) DEFAULT 1 COMMENT '是否成功',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志';
