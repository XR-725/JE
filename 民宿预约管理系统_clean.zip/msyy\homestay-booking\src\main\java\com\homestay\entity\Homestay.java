package com.homestay.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("homestay")
public class Homestay {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String name;
    private Long hostId;
    private String province;
    private String city;
    private String district;
    private String address;
    private String description;
    private String coverImage;
    private String images;
    private String facilities;
    private String checkInTime;
    private String checkOutTime;
    private Integer status;
    private BigDecimal rating;
    private Integer reviewCount;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy.MM.dd HH:mm")
    private LocalDateTime updateTime;
}
