package com.homestay.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.homestay.dto.CreateOrderDto;
import com.homestay.vo.OrderVO;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface OrdersService {
    OrderVO createOrder(CreateOrderDto dto, Long userId);
    OrderVO getOrderDetail(Long orderId);
    Page<OrderVO> getUserOrders(Long userId, Integer page, Integer size, String status);
    Page<OrderVO> getHostOrders(Long hostId, Integer page, Integer size, String status);
    Page<OrderVO> getAdminOrders(Integer page, Integer size, String keyword, String status, String startDate, String endDate);
    List<OrderVO> getReviewableOrders(Long userId, Long homestayId);
    void payOrder(Long orderId, String payMethod, Long userId);
    void cancelOrder(Long orderId, Long userId);
    void confirmOrder(Long orderId, Long hostId);
    void checkinOrder(Long orderId, Long hostId);
    void completeOrder(Long orderId, Long hostId);
    void adminCancelOrder(Long orderId);
    void hostCancelOrder(Long orderId, Long hostId);
    boolean checkRoomAvailable(Long roomId, LocalDate checkIn, LocalDate checkOut);
    Map<String, Object> generateRevenueReport(Long hostId, String startDate, String endDate);
}
