package com.homestay.dto;

import lombok.Data;

@Data
public class UpdateUserDto {
    private String nickname;
    private String phone;
    private String email;
    private Integer gender;
}
