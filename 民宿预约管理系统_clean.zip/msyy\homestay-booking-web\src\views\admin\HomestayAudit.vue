<template>
  <div class="admin-page">
    <div class="page-header"><h3>{{ title }}</h3></div>
    <el-card>
      <div class="toolbar">
        <el-select v-model="statusFilter" placeholder="状态筛选" clearable @change="fetchData">
          <el-option label="全部" :value="null" />
          <el-option label="待审核" :value="0" />
          <el-option label="已上架" :value="1" />
          <el-option label="已下架" :value="2" />
        </el-select>
      </div>
      <el-table :data="list" border stripe style="width:100%;margin-top:16px">
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="name" label="名称" min-width="180" />
        <el-table-column prop="city" label="城市" width="80" />
        <el-table-column prop="rating" label="评分" width="60" />
        <el-table-column prop="reviewCount" label="评论" width="60" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : row.status === 0 ? 'warning' : 'info'" size="small">{{ statusMap[row.status] }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="发布时间" width="160" />
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button v-if="row.status === 0" type="success" link size="small" @click="audit(row, 1)">通过</el-button>
            <el-button v-if="row.status === 0" type="danger" link size="small" @click="audit(row, 2)">拒绝</el-button>
            <el-button v-if="row.status === 1" type="warning" link size="small" @click="audit(row, 2)">下架</el-button>
            <el-button v-if="row.status === 2" type="success" link size="small" @click="audit(row, 1)">上架</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div style="text-align:right;margin-top:16px">
        <el-pagination v-model:current-page="page" :page-size="size" :total="total" layout="prev, pager, next" background @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getAdminHomestays, auditHomestay } from '@/api/admin'

defineProps({ title: { type: String, default: '民宿审核' } })

const list = ref([])
const page = ref(1)
const size = ref(10)
const total = ref(0)
const statusFilter = ref(null)
const statusMap = { 0: '待审核', 1: '已上架', 2: '已下架' }

const fetchData = async () => {
  const res = await getAdminHomestays({ page: page.value, size: size.value, status: statusFilter.value !== null ? statusFilter.value : undefined })
  list.value = res.data?.records || []
  total.value = res.data?.total || 0
}

const audit = async (row, status) => {
  await auditHomestay(row.id, status)
  ElMessage.success('操作成功')
  fetchData()
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.page-header h3 { margin-bottom: 16px; }
</style>
