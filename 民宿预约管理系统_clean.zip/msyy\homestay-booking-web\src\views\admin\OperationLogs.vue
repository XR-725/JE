<template>
  <PageContainer title="操作日志" subtitle="系统操作审计记录">
    <template #toolbar>
      <el-input v-model="username" placeholder="搜索用户名" clearable style="width:160px" @change="fetchData" />
      <el-input v-model="operation" placeholder="搜索操作" clearable style="width:200px" @change="fetchData" />
      <el-button @click="fetchData" type="primary" plain size="small">查询</el-button>
    </template>

    <el-card v-loading="loading">
      <el-table :data="list" border stripe>
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="username" label="用户" width="120" />
        <el-table-column prop="operation" label="操作" min-width="200" show-overflow-tooltip />
        <el-table-column prop="method" label="请求方法" width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <code class="method-code">{{ row.method }}</code>
          </template>
        </el-table-column>
        <el-table-column prop="ip" label="IP" width="130" />
        <el-table-column prop="duration" label="耗时" width="90">
          <template #default="{ row }">
            <span :class="{ 'slow-query': row.duration > 1000 }">{{ row.duration }}ms</span>
          </template>
        </el-table-column>
        <el-table-column prop="success" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.success ? 'success' : 'danger'" size="small">{{ row.success ? '成功' : '失败' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="时间" width="170" />
      </el-table>

      <div style="text-align:right;margin-top:16px">
        <el-pagination v-model:current-page="page" :page-size="size" :total="total" layout="prev, pager, next, total" background @current-change="fetchData" />
      </div>
    </el-card>
  </PageContainer>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getOperationLogs } from '@/api/admin'
import PageContainer from '@/components/PageContainer.vue'

const list = ref([])
const page = ref(1)
const size = ref(20)
const total = ref(0)
const username = ref('')
const operation = ref('')
const loading = ref(false)

const fetchData = async () => {
  loading.value = true
  try {
    const res = await getOperationLogs({
      page: page.value, size: size.value,
      username: username.value || undefined,
      operation: operation.value || undefined
    })
    list.value = res.data?.records || []
    total.value = res.data?.total || 0
  } finally { loading.value = false }
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.method-code {
  background: #f5f7fa; padding: 2px 6px; border-radius: 4px;
  font-size: 12px; color: #606266; font-family: monospace;
}
.slow-query {
  color: #ef4444; font-weight: 600;
}
</style>
